<?php
declare(strict_types=1);

/*
 * IT Asset & Ticket Management - ONE PAGE (Protected Admin with Softtoken Login)
 * PHP 8+ / MySQL (default) or SQLite / PDO
 *
 * STORAGE:
 *   - MySQL / MariaDB  (driver = 'mysql')  -> aanbevolen voor productie
 *   - SQLite           (driver = 'sqlite') -> fallback / eenvoudige setup
 *
 * MULTI-ADMIN UPDATE
 * ALERTS UPDATE
 * SOFTWARE UPDATE
 * COMPLIANCE UPDATE (GDPR/AVG/BIO):
 *  - Nieuwe tabellen: asset_compliance, asset_security_policy
 *  - Nieuwe views: compliance, compliance-asset
 *  - Agent stuurt compliance/security data mee (incl. source-velden)
 *  - Schermvergrendeling: leest machine policy + HKCU van interactieve
 *    gebruiker (via HKEY_USERS) + fallback agent HKCU
 *
 * BULK RENAME / DUAL NAME UPDATE:
 *  - Nieuwe kolom: functional_name (functionele naam)
 *  - Nieuwe view: bulk-rename (bulk hernoemen van hostname/functional_name)
 *  - Zowel functionele naam als computernaam worden getoond in overzichten
 *  - Agent stuurt zowel hostname (computernaam) als functional_name mee
 *  - ticket_history.ticket_id is NULLABLE voor systeem-events (bulk rename)
 */

session_start();

date_default_timezone_set('Europe/Amsterdam');

const APP_NAME = 'ITSM Control Center (Guest & MFA Protected Admin)';
const LOW_DISK_THRESHOLD_GB = 30;

$CONFIG = require __DIR__ . DIRECTORY_SEPARATOR . 'config.php';

define('ORG_NAME', $CONFIG['branding']['org_name'] ?? 'Voedselbank Almere');
define('ORG_LOGO_URL', $CONFIG['branding']['logo_url'] ?? 'https://www.voedselbankalmere.nl/pics_site/voedselbank-almere-2025.png');
define('ORG_LOGO_URL_ABS', preg_match('~^https?://~i', ORG_LOGO_URL)
    ? ORG_LOGO_URL
    : rtrim((string)($CONFIG['app_base_url'] ?? ''), '/') . '/' . ltrim(ORG_LOGO_URL, '/'));

/**
 * --- TOTP (RFC 6238 / RFC 4226) ---
 */
function totp_base32_decode(string $b32): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $char) {
        $pos = strpos($alphabet, $char);
        if ($pos === false) continue;
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) < 8) continue;
        $bytes .= chr((int)bindec($byte));
    }
    return $bytes;
}

function totp_generate(string $secretBase32, int $timeStep = 30, int $counterOffset = 0, int $digits = 6): string {
    $key = totp_base32_decode($secretBase32);
    $counter = intdiv(time(), $timeStep) + $counterOffset;
    $counterBytes = pack('N*', 0, $counter);
    $hash = hash_hmac('sha1', $counterBytes, $key, true);
    $offset = ord($hash[strlen($hash) - 1]) & 0x0F;
    $truncated = ((ord($hash[$offset]) & 0x7F) << 24)
        | ((ord($hash[$offset + 1]) & 0xFF) << 16)
        | ((ord($hash[$offset + 2]) & 0xFF) << 8)
        | (ord($hash[$offset + 3]) & 0xFF);
    $code = (string)($truncated % (10 ** $digits));
    return str_pad($code, $digits, '0', STR_PAD_LEFT);
}

function totp_verify(string $inputCode, string $secretBase32, int $timeStep = 30, int $digits = 6, int $window = 1): bool {
    $inputCode = trim($inputCode);
    if (!preg_match('/^\d{' . $digits . '}$/', $inputCode)) {
        return false;
    }
    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(totp_generate($secretBase32, $timeStep, $i, $digits), $inputCode)) {
            return true;
        }
    }
    return false;
}

function totp_identify_admin(string $inputCode, array $admins, int $timeStep = 30): ?string {
    $inputCode = trim($inputCode);
    if ($inputCode === '' || !preg_match('/^\d{6}$/', $inputCode)) {
        return null;
    }
    foreach ($admins as $name => $secret) {
        $secret = trim((string)$secret);
        if ($secret === '') continue;
        if (totp_verify($inputCode, $secret, $timeStep)) {
            return (string)$name;
        }
    }
    return null;
}

function admin_first_name(?string $fullName = null): string {
    if ($fullName === null) {
        $fullName = (string)($_SESSION['admin_name'] ?? '');
    }
    $fullName = trim($fullName);
    if ($fullName === '') return 'Beheerder';
    $parts = preg_split('/\s+/', $fullName) ?: [];
    return $parts[0] !== '' ? $parts[0] : $fullName;
}

function admin_full_name(): string {
    $name = trim((string)($_SESSION['admin_name'] ?? ''));
    return $name !== '' ? $name : 'Beheerder';
}

/**
 * --- DATABASE ABSTRACTIE ---
 */
function db_driver(): string {
    global $CONFIG;
    $driver = strtolower((string)($CONFIG['db']['driver'] ?? 'mysql'));
    return in_array($driver, ['mysql', 'sqlite'], true) ? $driver : 'mysql';
}

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    global $CONFIG;
    $driver = db_driver();

    if ($driver === 'mysql') {
        $cfg = $CONFIG['db']['mysql'] ?? [];
        $host     = (string)($cfg['host'] ?? '127.0.0.1');
        $port     = (int)($cfg['port'] ?? 3306);
        $database = (string)($cfg['database'] ?? '');
        $username = (string)($cfg['username'] ?? '');
        $password = (string)($cfg['password'] ?? '');
        $charset  = (string)($cfg['charset'] ?? 'utf8mb4');
        $socket   = (string)($cfg['socket'] ?? '');

        if ($database === '' || $username === '') {
            throw new RuntimeException('MySQL config onvolledig: database en username zijn verplicht in config.php -> db.mysql.');
        }

        $dsn = $socket !== ''
            ? "mysql:unix_socket={$socket};dbname={$database};charset={$charset}"
            : "mysql:host={$host};port={$port};dbname={$database};charset={$charset}";

        $pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);

        try {
            $pdo->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'");
        } catch (Throwable $e) {
            // Niet fataal
        }

        initialize_database_mysql($pdo);
        return $pdo;
    }

    // SQLite
    $sqliteCfg = $CONFIG['db']['sqlite'] ?? [];
    $sqliteFile = $sqliteCfg['file'] ?? (__DIR__ . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'database.sqlite');
    $sqliteDir  = $sqliteCfg['dir']  ?? dirname($sqliteFile);
    if (!is_dir($sqliteDir)) {
        @mkdir($sqliteDir, 0775, true);
    }
    $isFirstRun = !file_exists($sqliteFile);

    $pdo = new PDO('sqlite:' . $sqliteFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');

    initialize_database_sqlite($pdo, $isFirstRun);
    return $pdo;
}

/**
 * --- SCHEMA VOOR MYSQL / MARIADB ---
 */
function initialize_database_mysql(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(190) NOT NULL,
            email VARCHAR(190) NOT NULL DEFAULT '',
            role VARCHAR(50) NOT NULL DEFAULT 'user',
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_users_username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS assets (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_tag VARCHAR(190) NOT NULL,
            hostname VARCHAR(190) NOT NULL DEFAULT '',
            functional_name VARCHAR(190) NOT NULL DEFAULT '',
            username VARCHAR(190) NOT NULL DEFAULT '',
            manufacturer VARCHAR(190) NOT NULL DEFAULT '',
            model VARCHAR(190) NOT NULL DEFAULT '',
            serial_number VARCHAR(190) NOT NULL DEFAULT '',
            bios_version VARCHAR(190) NOT NULL DEFAULT '',
            windows_version VARCHAR(190) NOT NULL DEFAULT '',
            windows_build VARCHAR(50) NOT NULL DEFAULT '',
            cpu VARCHAR(255) NOT NULL DEFAULT '',
            ram_mb INT NOT NULL DEFAULT 0,
            ip_address VARCHAR(50) NOT NULL DEFAULT '',
            mac_address VARCHAR(50) NOT NULL DEFAULT '',
            disk_summary TEXT NULL,
            defender_status VARCHAR(100) NOT NULL DEFAULT '',
            tpm_status VARCHAR(100) NOT NULL DEFAULT '',
            bitlocker_status VARCHAR(100) NOT NULL DEFAULT '',
            location VARCHAR(190) NOT NULL DEFAULT '',
            department VARCHAR(190) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            notes TEXT NULL,
            last_seen DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_assets_asset_tag (asset_tag),
            KEY idx_assets_hostname (hostname),
            KEY idx_assets_functional_name (functional_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // === MIGRATIE: functional_name kolom toevoegen aan bestaande MySQL databases ===
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM assets LIKE 'functional_name'")->fetchAll();
        if (count($cols) === 0) {
            $pdo->exec("ALTER TABLE assets ADD COLUMN functional_name VARCHAR(190) NOT NULL DEFAULT '' AFTER hostname");
            $pdo->exec("ALTER TABLE assets ADD KEY idx_assets_functional_name (functional_name)");
        }
    } catch (Throwable $e) {
        // Niet fataal
    }

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_software (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id INT UNSIGNED NOT NULL,
            name VARCHAR(255) NOT NULL,
            version VARCHAR(100) NOT NULL DEFAULT '',
            publisher VARCHAR(255) NOT NULL DEFAULT '',
            install_date VARCHAR(20) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_asset_software_asset_id (asset_id),
            KEY idx_asset_software_name (name),
            CONSTRAINT fk_asset_software_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_volumes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id INT UNSIGNED NOT NULL,
            drive_letter VARCHAR(10) NOT NULL DEFAULT '',
            label VARCHAR(190) NOT NULL DEFAULT '',
            file_system VARCHAR(20) NOT NULL DEFAULT '',
            size_gb DOUBLE NOT NULL DEFAULT 0,
            free_gb DOUBLE NOT NULL DEFAULT 0,
            free_percent DOUBLE NOT NULL DEFAULT 0,
            is_low TINYINT(1) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_asset_volumes_asset_id (asset_id),
            CONSTRAINT fk_asset_volumes_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_pending_updates (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id INT UNSIGNED NOT NULL,
            title VARCHAR(500) NOT NULL DEFAULT '',
            kb VARCHAR(255) NOT NULL DEFAULT '',
            severity VARCHAR(50) NOT NULL DEFAULT '',
            size_mb DOUBLE NOT NULL DEFAULT 0,
            category VARCHAR(255) NOT NULL DEFAULT '',
            source VARCHAR(50) NOT NULL DEFAULT '',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_asset_pending_updates_asset_id (asset_id),
            CONSTRAINT fk_asset_pending_updates_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_compliance (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id INT UNSIGNED NOT NULL,
            bitlocker_system_protection VARCHAR(50) NOT NULL DEFAULT '',
            bitlocker_source VARCHAR(50) NOT NULL DEFAULT '',
            screen_lock_timeout_minutes INT NOT NULL DEFAULT 0,
            screen_lock_timeout_seconds INT NOT NULL DEFAULT 0,
            screen_lock_source VARCHAR(50) NOT NULL DEFAULT '',
            local_admins_count INT NOT NULL DEFAULT 0,
            local_admins_list TEXT NULL,
            local_admins_source VARCHAR(50) NOT NULL DEFAULT '',
            daily_user_is_admin TINYINT(1) NOT NULL DEFAULT 0,
            guest_account_enabled TINYINT(1) NOT NULL DEFAULT 0,
            guest_account_source VARCHAR(50) NOT NULL DEFAULT '',
            min_password_length INT NOT NULL DEFAULT 0,
            antivirus_enabled TINYINT(1) NOT NULL DEFAULT 0,
            realtime_protection_enabled TINYINT(1) NOT NULL DEFAULT 0,
            antivirus_source VARCHAR(50) NOT NULL DEFAULT '',
            last_update_date VARCHAR(20) NOT NULL DEFAULT '',
            last_update_kb VARCHAR(255) NOT NULL DEFAULT '',
            pending_reboot TINYINT(1) NOT NULL DEFAULT 0,
            firewall_domain TINYINT(1) NOT NULL DEFAULT 0,
            firewall_private TINYINT(1) NOT NULL DEFAULT 0,
            firewall_public TINYINT(1) NOT NULL DEFAULT 0,
            password_complexity TINYINT(1) NOT NULL DEFAULT 0,
            password_policy_source VARCHAR(50) NOT NULL DEFAULT '',
            agent_is_admin TINYINT(1) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_asset_compliance_asset_id (asset_id),
            CONSTRAINT fk_asset_compliance_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_security_policy (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id INT UNSIGNED NOT NULL,
            min_password_length INT NOT NULL DEFAULT 0,
            password_complexity TINYINT(1) NOT NULL DEFAULT 0,
            screen_lock_timeout_minutes INT NOT NULL DEFAULT 0,
            guest_account_enabled TINYINT(1) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_asset_security_policy_asset_id (asset_id),
            CONSTRAINT fk_asset_security_policy_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tickets (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            ticket_number VARCHAR(20) NULL,
            access_token VARCHAR(64) NULL,
            requester_name VARCHAR(190) NOT NULL,
            requester_email VARCHAR(190) NOT NULL,
            user_id INT UNSIGNED NULL,
            asset_id INT UNSIGNED NULL,
            title VARCHAR(255) NOT NULL,
            description MEDIUMTEXT NULL,
            category VARCHAR(100) NOT NULL DEFAULT 'Overige aanvraag',
            status VARCHAR(50) NOT NULL DEFAULT 'Nieuw',
            priority VARCHAR(50) NOT NULL DEFAULT 'Normaal',
            assigned_to INT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            closed_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_tickets_ticket_number (ticket_number),
            UNIQUE KEY uniq_tickets_access_token (access_token),
            KEY idx_tickets_status (status),
            KEY idx_tickets_created_at (created_at),
            KEY idx_tickets_asset_id (asset_id),
            CONSTRAINT fk_tickets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
            CONSTRAINT fk_tickets_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE SET NULL,
            CONSTRAINT fk_tickets_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ticket_replies (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            ticket_id INT UNSIGNED NOT NULL,
            sender_name VARCHAR(190) NOT NULL,
            user_id INT UNSIGNED NULL,
            body MEDIUMTEXT NOT NULL,
            is_internal TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_ticket_replies_ticket_id (ticket_id),
            CONSTRAINT fk_ticket_replies_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
            CONSTRAINT fk_ticket_replies_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ticket_templates (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            category VARCHAR(100) NOT NULL DEFAULT 'Overige aanvraag',
            subject VARCHAR(255) NOT NULL DEFAULT '',
            body MEDIUMTEXT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_ticket_templates_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ticket_reactions (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            body MEDIUMTEXT NOT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_ticket_reactions_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ticket_history (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            ticket_id INT UNSIGNED NULL,
            actor_name VARCHAR(190) NOT NULL,
            action VARCHAR(100) NOT NULL,
            details TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_ticket_history_ticket_id (ticket_id),
            CONSTRAINT fk_ticket_history_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // === MIGRATIE: ticket_history.ticket_id nullable maken voor systeem-events ===
    try {
        $col = $pdo->query("SHOW COLUMNS FROM ticket_history LIKE 'ticket_id'")->fetch();
        if ($col && strtoupper((string)($col['Null'] ?? 'NO')) === 'NO') {
            // Drop FK, wijzig kolom, voeg FK opnieuw toe (nu nullable)
            try {
                $pdo->exec("ALTER TABLE ticket_history DROP FOREIGN KEY fk_ticket_history_ticket");
            } catch (Throwable $e) {
                // FK bestaat mogelijk al niet
            }
            $pdo->exec("ALTER TABLE ticket_history MODIFY ticket_id INT UNSIGNED NULL");
            try {
                $pdo->exec("ALTER TABLE ticket_history ADD CONSTRAINT fk_ticket_history_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE");
            } catch (Throwable $e) {
                // FK toevoegen kan falen als er al een andere FK bestaat; niet fataal
            }
        }
    } catch (Throwable $e) {
        // Niet fataal
    }

    seed_users_if_empty($pdo);
    seed_templates_if_empty($pdo);
    seed_reactions_if_empty($pdo);
}

/**
 * --- SCHEMA VOOR SQLITE (fallback) ---
 */
function initialize_database_sqlite(PDO $pdo, bool $isFirstRun = false): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT DEFAULT '',
            role TEXT NOT NULL DEFAULT 'user',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_tag TEXT NOT NULL UNIQUE,
            hostname TEXT NOT NULL DEFAULT '',
            functional_name TEXT NOT NULL DEFAULT '',
            username TEXT NOT NULL DEFAULT '',
            manufacturer TEXT NOT NULL DEFAULT '',
            model TEXT NOT NULL DEFAULT '',
            serial_number TEXT NOT NULL DEFAULT '',
            bios_version TEXT NOT NULL DEFAULT '',
            windows_version TEXT NOT NULL DEFAULT '',
            windows_build TEXT NOT NULL DEFAULT '',
            cpu TEXT NOT NULL DEFAULT '',
            ram_mb INTEGER NOT NULL DEFAULT 0,
            ip_address TEXT NOT NULL DEFAULT '',
            mac_address TEXT NOT NULL DEFAULT '',
            disk_summary TEXT NOT NULL DEFAULT '',
            defender_status TEXT NOT NULL DEFAULT '',
            tpm_status TEXT NOT NULL DEFAULT '',
            bitlocker_status TEXT NOT NULL DEFAULT '',
            location TEXT NOT NULL DEFAULT '',
            department TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            notes TEXT NOT NULL DEFAULT '',
            last_seen TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_assets_hostname ON assets(hostname);
        CREATE INDEX IF NOT EXISTS idx_assets_functional_name ON assets(functional_name);

        CREATE TABLE IF NOT EXISTS asset_software (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            version TEXT NOT NULL DEFAULT '',
            publisher TEXT NOT NULL DEFAULT '',
            install_date TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_asset_software_asset_id ON asset_software(asset_id);
        CREATE INDEX IF NOT EXISTS idx_asset_software_name ON asset_software(name);

        CREATE TABLE IF NOT EXISTS asset_volumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            drive_letter TEXT NOT NULL DEFAULT '',
            label TEXT NOT NULL DEFAULT '',
            file_system TEXT NOT NULL DEFAULT '',
            size_gb REAL NOT NULL DEFAULT 0,
            free_gb REAL NOT NULL DEFAULT 0,
            free_percent REAL NOT NULL DEFAULT 0,
            is_low INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_asset_volumes_asset_id ON asset_volumes(asset_id);

        CREATE TABLE IF NOT EXISTS asset_pending_updates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT '',
            kb TEXT NOT NULL DEFAULT '',
            severity TEXT NOT NULL DEFAULT '',
            size_mb REAL NOT NULL DEFAULT 0,
            category TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_asset_pending_updates_asset_id ON asset_pending_updates(asset_id);

        CREATE TABLE IF NOT EXISTS asset_compliance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            bitlocker_system_protection TEXT NOT NULL DEFAULT '',
            bitlocker_source TEXT NOT NULL DEFAULT '',
            screen_lock_timeout_minutes INTEGER NOT NULL DEFAULT 0,
            screen_lock_timeout_seconds INTEGER NOT NULL DEFAULT 0,
            screen_lock_source TEXT NOT NULL DEFAULT '',
            local_admins_count INTEGER NOT NULL DEFAULT 0,
            local_admins_list TEXT NOT NULL DEFAULT '',
            local_admins_source TEXT NOT NULL DEFAULT '',
            daily_user_is_admin INTEGER NOT NULL DEFAULT 0,
            guest_account_enabled INTEGER NOT NULL DEFAULT 0,
            guest_account_source TEXT NOT NULL DEFAULT '',
            min_password_length INTEGER NOT NULL DEFAULT 0,
            antivirus_enabled INTEGER NOT NULL DEFAULT 0,
            realtime_protection_enabled INTEGER NOT NULL DEFAULT 0,
            antivirus_source TEXT NOT NULL DEFAULT '',
            last_update_date TEXT NOT NULL DEFAULT '',
            last_update_kb TEXT NOT NULL DEFAULT '',
            pending_reboot INTEGER NOT NULL DEFAULT 0,
            firewall_domain INTEGER NOT NULL DEFAULT 0,
            firewall_private INTEGER NOT NULL DEFAULT 0,
            firewall_public INTEGER NOT NULL DEFAULT 0,
            password_complexity INTEGER NOT NULL DEFAULT 0,
            password_policy_source TEXT NOT NULL DEFAULT '',
            agent_is_admin INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_compliance_asset_id ON asset_compliance(asset_id);

        CREATE TABLE IF NOT EXISTS asset_security_policy (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            min_password_length INTEGER NOT NULL DEFAULT 0,
            password_complexity INTEGER NOT NULL DEFAULT 0,
            screen_lock_timeout_minutes INTEGER NOT NULL DEFAULT 0,
            guest_account_enabled INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_security_policy_asset_id ON asset_security_policy(asset_id);

        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_number TEXT UNIQUE,
            access_token TEXT UNIQUE,
            requester_name TEXT NOT NULL,
            requester_email TEXT NOT NULL,
            user_id INTEGER,
            asset_id INTEGER,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT 'Overige aanvraag',
            status TEXT NOT NULL DEFAULT 'Nieuw',
            priority TEXT NOT NULL DEFAULT 'Normaal',
            assigned_to INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            closed_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL,
            FOREIGN KEY(assigned_to) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS ticket_replies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER NOT NULL,
            sender_name TEXT NOT NULL,
            user_id INTEGER,
            body TEXT NOT NULL,
            is_internal INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS ticket_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL DEFAULT 'Overige aanvraag',
            subject TEXT NOT NULL DEFAULT '',
            body TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS ticket_reactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            body TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS ticket_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER,
            actor_name TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_ticket_history_ticket_id ON ticket_history(ticket_id);
    ");

    /* === MIGRATIE: functional_name kolom voor bestaande SQLite databases === */
    $existingAssetCols = $pdo->query("PRAGMA table_info(assets)")->fetchAll();
    $assetColNames = array_column($existingAssetCols, 'name');
    if (!in_array('functional_name', $assetColNames, true)) {
        $pdo->exec("ALTER TABLE assets ADD COLUMN functional_name TEXT NOT NULL DEFAULT ''");
    }

    /* === MIGRATIE: ticket_history.ticket_id nullable maken voor systeem-events === */
    try {
        $cols = $pdo->query("PRAGMA table_info(ticket_history)")->fetchAll();
        foreach ($cols as $c) {
            if ($c['name'] === 'ticket_id' && (int)$c['notnull'] === 1) {
                // SQLite ondersteunt geen ALTER COLUMN; herschrijf de tabel
                $pdo->exec("PRAGMA foreign_keys = OFF");
                $pdo->exec("ALTER TABLE ticket_history RENAME TO ticket_history_old");
                $pdo->exec("
                    CREATE TABLE ticket_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ticket_id INTEGER,
                        actor_name TEXT NOT NULL,
                        action TEXT NOT NULL,
                        details TEXT NOT NULL DEFAULT '',
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                    )
                ");
                $pdo->exec("INSERT INTO ticket_history(id,ticket_id,actor_name,action,details,created_at)
                            SELECT id,ticket_id,actor_name,action,details,created_at FROM ticket_history_old");
                $pdo->exec("DROP TABLE ticket_history_old");
                $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ticket_history_ticket_id ON ticket_history(ticket_id)");
                $pdo->exec("PRAGMA foreign_keys = ON");
                break;
            }
        }
    } catch (Throwable $e) {
        // Niet fataal
    }

    /* === MIGRATIE: source-kolommen voor bestaande SQLite databases === */
    $existingCols = $pdo->query("PRAGMA table_info(asset_compliance)")->fetchAll();
    $colNames = array_column($existingCols, 'name');

    $newCols = [
        'bitlocker_source'            => "TEXT NOT NULL DEFAULT ''",
        'screen_lock_timeout_seconds' => "INTEGER NOT NULL DEFAULT 0",
        'screen_lock_source'          => "TEXT NOT NULL DEFAULT ''",
        'local_admins_source'         => "TEXT NOT NULL DEFAULT ''",
        'guest_account_source'        => "TEXT NOT NULL DEFAULT ''",
        'password_policy_source'      => "TEXT NOT NULL DEFAULT ''",
        'antivirus_source'            => "TEXT NOT NULL DEFAULT ''",
        'agent_is_admin'              => "INTEGER NOT NULL DEFAULT 0",
    ];
    foreach ($newCols as $col => $def) {
        if (!in_array($col, $colNames, true)) {
            $pdo->exec("ALTER TABLE asset_compliance ADD COLUMN $col $def");
        }
    }

    seed_users_if_empty($pdo);
    if ($isFirstRun) {
        seed_templates_if_empty($pdo);
        seed_reactions_if_empty($pdo);
    }
}

/**
 * --- SEED HELPERS (driver-aware) ---
 */
function seed_users_if_empty(PDO $pdo): void {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count > 0) return;

    $stmt = $pdo->prepare("INSERT INTO users(username,password_hash,full_name,email,role) VALUES(?,?,?,?,?)");
    $stmt->execute([
        'admin',
        password_hash('admin123', PASSWORD_DEFAULT),
        'Administrator (IT Service Desk)',
        'helpdesk@company.local',
        'admin'
    ]);
}

function seed_templates_if_empty(PDO $pdo): void {
    $templates = [
        ['Softtoken opnieuw aanvragen', 'MFA / Authenticatie', 'Softtoken MFA herinrichten', "Naam medewerker:\nGebruikersnaam:\nReden van aanvraag:\n[ ] Nieuwe telefoon\n[ ] Telefoon verloren / defect\n[ ] Token per ongeluk verwijderd\n[ ] Token werkt niet meer\nOpmerkingen:"],
        ['Printer probleem melden', 'Hardware', 'Storing met printer/scanner', "Locatie printer:\nMerk / Model / Naam printer:\nFoutmelding of omschrijving probleem:\nSinds wanneer speelt dit:\nWerkt dit voor meerdere gebruikers (Ja/Nee):"],
        ['IT Storing / Incident melden', 'Overige aanvraag', 'IT Storing melden', "Omschrijving van de storing:\nWelke systemen zijn getroffen:\nAantal getroffen personen:\nSpoedeisend (Ja/Nee):"],
        ['Beveiligingsincident melden', 'Overige aanvraag', 'Melding mogelijk beveiligingsincident', "Omschrijving van het incident:\nWanneer heeft dit plaatsgevonden:\nBetrokken systemen / accounts:\nIs er mogelijk gevoelige data betrokken (Ja/Nee):\nReeds ondernomen stappen:"],
        ['Incidenten Microsoft Access clientadministratie', 'Applicatie', 'Storing of foutmelding in Microsoft Access - Clientadministratie', "Omschrijving van het incident:\nExacte foutmelding (indien van toepassing):\nWat probeerde u te doen:\nSinds wanneer speelt dit:\nGebeurt dit bij meerdere gebruikers (Ja/Nee):"],
        ['Incidenten Microsoft Access MWLA', 'Applicatie', 'Storing of foutmelding in Microsoft Access - MWLA', "Omschrijving van het incident:\nExacte foutmelding (indien van toepassing):\nWat probeerde u te doen:\nSinds wanneer speelt dit:\nGebeurt dit bij meerdere gebruikers (Ja/Nee):"],
        ['Incidenten Microsoft Access Pasuitgifte', 'Applicatie', 'Storing of foutmelding in Microsoft Access - Pasuitgifte', "Omschrijving van het incident:\nExacte foutmelding (indien van toepassing):\nWat probeerde u te doen:\nSinds wanneer speelt dit:\nGebeurt dit bij meerdere gebruikers (Ja/Nee):"],
        ['Incidenten Microsoft Access Kleding', 'Applicatie', 'Storing of foutmelding in Microsoft Access - Kleding', "Omschrijving van het incident:\nExacte foutmelding (indien van toepassing):\nWat probeerde u te doen:\nSinds wanneer speelt dit:\nGebeeurt dit bij meerdere gebruikers (Ja/Nee):"]
    ];
    $driver = db_driver();
    $sql = $driver === 'mysql'
        ? "INSERT IGNORE INTO ticket_templates(name,category,subject,body) VALUES(?,?,?,?)"
        : "INSERT OR IGNORE INTO ticket_templates(name,category,subject,body) VALUES(?,?,?,?)";
    $stmt = $pdo->prepare($sql);
    foreach ($templates as $t) {
        $stmt->execute($t);
    }
}

function seed_reactions_if_empty(PDO $pdo): void {
    $reactions = [
        ['Ticket ontvangen', "Uw aanvraag is goed ontvangen door onze IT Service Desk en is in behandeling genomen."],
        ['Meer informatie nodig', "Om uw aanvraag verder te behandelen hebben wij aanvullende informatie nodig. Wilt u reageren op dit bericht?"],
        ['Opgelost & Afgerond', "Het incident / de aanvraag is succesvol verwerkt. Mocht u nog vragen hebben, dan kunt u reageren via deze ticket-link."],
        ['Ticket in behandeling genomen', "Uw ticket is in behandeling genomen door een medewerker van de IT Service Desk. Wij doen ons best om uw melding zo snel mogelijk af te handelen."],
        ['Ticket tijdelijk on hold', "Uw ticket is tijdelijk on hold geplaatst. Dit kan zijn omdat wij wachten op een externe partij, aanvullende informatie of een geschikt moment om werkzaamheden uit te voeren. Zodra er een update is, laten wij u dat weten."],
        ['Ticket heropend', "Uw ticket is heropend. Wij nemen uw melding opnieuw in behandeling."],
        ['Ticket gesloten wegens geen reactie', "Wij hebben van u geen reactie meer ontvangen op onze vorige vraag. Dit ticket wordt daarom gesloten. Speelt het probleem nog, open dan gerust een nieuw ticket of reageer op deze melding."],
        ['Dubbele melding', "Deze melding lijkt overeen te komen met een reeds bestaand ticket. Wij handelen uw verzoek af via het eerder aangemaakte ticket en sluiten deze melding als duplicaat."],
        ['Doorgezet naar specialist', "Uw melding vraagt gespecialiseerde kennis en is doorgezet naar de juiste collega/afdeling. Zij nemen het verder met u op."],
        ['Wachten op derde partij / leverancier', "Voor de afhandeling van deze melding zijn wij afhankelijk van een externe leverancier. Zodra wij een update ontvangen, informeren wij u direct."],
        ['Telefonisch contact gevraagd', "Wij willen u graag telefonisch te woord staan om deze melding goed af te kunnen handelen. Kunt u aangeven wanneer u bereikbaar bent, of ons bellen op het bekende Service Desk-nummer?"],
        ['Prioriteit aangepast', "De prioriteit van uw melding is aangepast op basis van de impact en urgentie. Wij behandelen uw ticket volgens de bijbehorende afhandeltermijn."],
        ['Storing bekend / wordt onderzocht', "Wij zijn bekend met deze storing en ons team onderzoekt de oorzaak. Zodra er een oplossing of update is, informeren wij u via dit ticket."],
        ['Ticket aangemaakt onder juiste categorie', "Uw ticket is geclassificeerd onder de juiste categorie. Hierdoor kunnen wij uw melding sneller en gerichter afhandelen."],
        ['Ticket toegewezen aan behandelaar', "Uw ticket is toegewezen aan een specifieke behandelaar binnen de IT Service Desk. Deze collega zal uw melding verder afhandelen en is uw aanspreekpunt."],
        ['Verwachte afhandeltijd', "Wij streven ernaar uw ticket binnen de gebruikelijke afhandeltermijn te behandelen. Mocht dit niet lukken, dan nemen wij tijdig contact met u op."],
        ['Statusupdate', "De status van uw ticket is bijgewerkt. Kijk in het ticket voor de meest recente informatie."],
        ['Herinnering openstaand ticket', "Wij willen u vriendelijk herinneren aan ons eerdere bericht in dit ticket. Zonder uw reactie kunnen wij uw melding helaas niet verder behandelen."],
        ['Ticket gearchiveerd', "Dit ticket is gearchiveerd. Mocht u later nog vragen hebben, dan kunt u een nieuw ticket aanmaken onder vermelding van het oude ticketnummer."],
        ['Excuus voor het ongemak', "Onze excuses voor het ongemak. Wij begrijpen dat dit vervelend is en doen ons best om dit zo snel mogelijk op te lossen."],
        ['Bedankt voor uw geduld', "Bedankt voor uw geduld. Wij waarderen het dat u de tijd neemt om met ons samen te werken aan een oplossing."],
        ['Feedback gevraagd', "Wij stellen uw feedback zeer op prijs. Wilt u ons laten weten of u tevreden bent met de afhandeling van dit ticket?"],
        ['Ticket wordt afgesloten', "Wij gaan ervan uit dat uw melding hiermee is opgelost. Dit ticket wordt over 3 werkdagen automatisch gesloten, tenzij u nog reageert."],
        ['Ticketnummer doorgeven', "Bewaar uw ticketnummer goed. Hiermee kunt u de status van uw melding op elk moment opzoeken en erop reageren."],
        ['Wachtwoord gereset', "Uw wachtwoord is opnieuw ingesteld. U ontvangt de tijdelijke inloggegevens via een apart, beveiligd kanaal. Wij adviseren u dringend om direct na het inloggen een nieuw, persoonlijk wachtwoord in te stellen."],
        ['Softtoken opnieuw ingericht', "Uw softtoken (MFA) is opnieuw ingericht op uw apparaat. Test a.u.b. of u succesvol kunt inloggen en laat het ons weten als dit niet lukt."],
        ['Software geinstalleerd', "De aangevraagde software is geinstalleerd op uw werkplek. Herstart uw apparaat indien daarom gevraagd wordt en controleer of alles naar wens werkt."]
    ];
    $driver = db_driver();
    $sql = $driver === 'mysql'
        ? "INSERT IGNORE INTO ticket_reactions(name,body) VALUES(?,?)"
        : "INSERT OR IGNORE INTO ticket_reactions(name,body) VALUES(?,?)";
    $stmt = $pdo->prepare($sql);
    foreach ($reactions as $r) {
        $stmt->execute($r);
    }
}

function e(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Hulpfunctie: toon altijd zowel functionele naam als computernaam (hostname).
 * Valt terug op asset_tag als beide leeg zijn.
 */
function asset_display(array $asset): string {
    $fn = trim((string)($asset['functional_name'] ?? ''));
    $hn = trim((string)($asset['hostname'] ?? ''));
    if ($fn !== '' && $hn !== '') {
        return $fn . ' (' . $hn . ')';
    }
    if ($fn !== '') return $fn;
    if ($hn !== '') return $hn;
    return (string)($asset['asset_tag'] ?? 'Onbekend');
}

function rot47(string $text): string {
    $result = '';
    $len = strlen($text);
    for ($i = 0; $i < $len; $i++) {
        $ord = ord($text[$i]);
        if ($ord >= 33 && $ord <= 126) {
            $result .= chr(33 + (($ord + 14) % 94));
        } else {
            $result .= $text[$i];
        }
    }
    return $result;
}

function decode_ticket_row(mixed $row): mixed {
    if (!is_array($row)) return $row;
    if (array_key_exists('requester_name', $row) && $row['requester_name'] !== null) {
        $row['requester_name'] = rot47((string)$row['requester_name']);
    }
    if (array_key_exists('requester_email', $row) && $row['requester_email'] !== null) {
        $row['requester_email'] = rot47((string)$row['requester_email']);
    }
    return $row;
}

function decode_ticket_rows(array $rows): array {
    return array_map('decode_ticket_row', $rows);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        throw new RuntimeException('Ongeldige beveiligingstoken. Vernieuw de pagina.');
    }
}

function redirect(string $url = 'index.php'): never {
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type'=>$type, 'message'=>$message];
}

function is_admin_authenticated(): bool {
    global $CONFIG;
    if (empty($_SESSION['is_admin_authenticated'])) {
        return false;
    }
    $lifetime = (int)($CONFIG['security']['session_lifetime'] ?? 86400);
    $authAt = (int)($_SESSION['admin_authenticated_at'] ?? 0);
    if ($authAt > 0 && (time() - $authAt) > $lifetime) {
        unset(
            $_SESSION['is_admin_authenticated'],
            $_SESSION['admin_authenticated_at'],
            $_SESSION['admin_name'],
            $_SESSION['admin_is_fallback']
        );
        return false;
    }
    return true;
}

function require_admin_auth(): void {
    if (!is_admin_authenticated()) {
        throw new RuntimeException('Geen toegang. U moet eerst inloggen met uw beheerder Softtoken.');
    }
}

function generate_ticket_number(PDO $pdo): string {
    $maxAttempts = 200;
    for ($i = 0; $i < $maxAttempts; $i++) {
        $number = 'VBA-' . str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT 1 FROM tickets WHERE ticket_number = ?");
        $stmt->execute([$number]);
        if (!$stmt->fetchColumn()) {
            return $number;
        }
    }
    throw new RuntimeException('Kon geen uniek 4-cijferig ticketnummer genereren. Er zijn te veel tickets in gebruik voor dit formaat.');
}

function normalize_ticket_number(string $input): string {
    $input = trim($input);
    if ($input === '') return '';
    if (preg_match('/^\d{1,4}$/', $input)) {
        return 'VBA-' . str_pad($input, 4, '0', STR_PAD_LEFT);
    }
    if (preg_match('/^(?:vba|inc)-(\d{1,4})$/i', $input, $m)) {
        return 'VBA-' . str_pad($m[1], 4, '0', STR_PAD_LEFT);
    }
    return $input;
}

function app_base_url(): string {
    global $CONFIG;
    $configured = trim((string)($CONFIG['app_base_url'] ?? ''));
    if ($configured !== '') {
        return rtrim($configured, '/');
    }
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php')), '/');
    return $protocol . '://' . $host . $scriptDir;
}

function ticket_url(string $token): string {
    return app_base_url() . '/index.php?view=ticket&token=' . $token;
}

/**
 * Audit log. ticket_id mag NULL zijn voor systeem-events (bijv. bulk rename).
 */
function audit(?int $ticketId, string $actorName, string $action, string $details=''): void {
    $s = db()->prepare("INSERT INTO ticket_history(ticket_id,actor_name,action,details) VALUES(?,?,?,?)");
    $s->execute([$ticketId, rot47($actorName), $action, $details]);
}

function count_low_disk_alerts(): int {
    try {
        $pdo = db();
        return (int)$pdo->query("SELECT COUNT(*) FROM asset_volumes WHERE is_low = 1")->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function count_pending_updates(): int {
    try {
        $pdo = db();
        return (int)$pdo->query("SELECT COUNT(*) FROM asset_pending_updates")->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function count_unique_software(): int {
    try {
        $pdo = db();
        return (int)$pdo->query("SELECT COUNT(*) FROM (SELECT DISTINCT name, version FROM asset_software) AS t")->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * === COMPLIANCE HELPERS ===
 */
function evaluate_compliance(array $comp, array $asset, array $cfg): array {
    $issues = [];

    if (!empty($cfg['require_bitlocker_system'])) {
        $bl    = strtolower(trim((string)($comp['bitlocker_system_protection'] ?? '')));
        $blSrc = (string)($comp['bitlocker_source'] ?? '');

        $blOk = in_array($bl, ['on','1','fullyencrypted','encrypted','beveiligd','aan'], true);
        $blOff = in_array($bl, ['off','0','fullydecrypted','decrypted','unencrypted','uit','niet versleuteld'], true);

        if (!$blOk) {
            if ($blOff) {
                $issues[] = 'Systeemschijf niet BitLocker-versleuteld (' . ($comp['bitlocker_system_protection'] ?: 'onbekend') . ')';
            } else {
                $issues[] = 'BitLocker-status onbekend - agent kon status niet uitlezen'
                    . ($blSrc ? ' (bron: ' . $blSrc . ')' : '')
                    . ' - draait de agent als administrator?';
            }
        }
    }

    $maxLock = (int)($cfg['max_screen_lock_minutes'] ?? 10);
    $lock    = (int)($comp['screen_lock_timeout_minutes'] ?? 0);
    $lockSec = (int)($comp['screen_lock_timeout_seconds'] ?? 0);
    $lockSrc = (string)($comp['screen_lock_source'] ?? '');

    if ($maxLock > 0) {
        if ($lockSec > 0) {
            $maxLockSec = $maxLock * 60;
            if ($lockSec > $maxLockSec) {
                $issues[] = "Schermvergrendeling te laat ({$lockSec} sec, max {$maxLockSec} sec"
                    . ($lockSrc ? ", bron: {$lockSrc}" : '') . ')';
            }
        } elseif ($lock === 0) {
            $issues[] = 'Automatische schermvergrendeling niet ingesteld';
        } elseif ($lock > $maxLock) {
            $issues[] = "Schermvergrendeling te laat ({$lock} min, max {$maxLock} min)";
        }
    }

    $maxAdmins = (int)($cfg['max_local_admins'] ?? 2);
    $admins = (int)($comp['local_admins_count'] ?? 0);
    if ($maxAdmins > 0 && $admins > $maxAdmins) {
        $issues[] = "Te veel leden in lokale Administrators groep ({$admins}, max {$maxAdmins})";
    }

    if (!empty($cfg['forbid_daily_user_admin']) && (int)($comp['daily_user_is_admin'] ?? 0) === 1) {
        $issues[] = 'Dagelijkse gebruiker heeft lokale administratorrechten';
    }

    if (!empty($cfg['require_guest_disabled']) && (int)($comp['guest_account_enabled'] ?? 0) === 1) {
        $issues[] = 'Gastaccount is ingeschakeld';
    }

    $minPw  = (int)($cfg['min_password_length'] ?? 12);
    $pw     = (int)($comp['min_password_length'] ?? 0);
    $pwSrc  = (string)($comp['password_policy_source'] ?? '');

    if ($minPw > 0) {
        if ($pw === 0 && ($pwSrc === 'requires_admin' || $pwSrc === 'none' || $pwSrc === '')) {
            $issues[] = 'Wachtwoordbeleid onbekend - agent kon het niet uitlezen'
                . ($pwSrc ? ' (bron: ' . $pwSrc . ')' : '')
                . ' - draait de agent als administrator?';
        } elseif ($pw < $minPw) {
            $issues[] = "Wachtwoordlengte te kort ({$pw}, min {$minPw})";
        }
    }

    if (!empty($cfg['require_password_complexity'])) {
        if ((int)($comp['password_complexity'] ?? 0) !== 1) {
            if ($pwSrc === 'requires_admin' || $pwSrc === 'none' || $pwSrc === '') {
                $issues[] = 'Wachtwoordcomplexiteit onbekend - agent kon het beleid niet uitlezen';
            } else {
                $issues[] = 'Wachtwoordcomplexiteit niet vereist';
            }
        }
    }

    if ((int)($comp['antivirus_enabled'] ?? 0) !== 1) {
        $avSrc = (string)($comp['antivirus_source'] ?? '');
        if ($avSrc === 'requires_admin') {
            $issues[] = 'Antivirus-status onbekend - agent kon Defender niet uitlezen';
        } else {
            $issues[] = 'Antivirus niet ingeschakeld';
        }
    }

    if (!empty($cfg['require_realtime_protection']) && (int)($comp['realtime_protection_enabled'] ?? 0) !== 1) {
        $issues[] = 'Real-time protection niet ingeschakeld';
    }

    $maxDays = (int)($cfg['max_days_since_last_update'] ?? 30);
    $lastDate = trim((string)($comp['last_update_date'] ?? ''));
    if ($maxDays > 0) {
        if ($lastDate === '') {
            $issues[] = 'Geen recente Windows update geregistreerd';
        } else {
            $ts = strtotime($lastDate);
            if ($ts === false) {
                $issues[] = 'Datum laatste update onbekend';
            } else {
                $days = (int)floor((time() - $ts) / 86400);
                if ($days > $maxDays) {
                    $issues[] = "Laatste update te oud ({$days} dagen, max {$maxDays})";
                }
            }
        }
    }

    if (!empty($cfg['forbid_pending_reboot']) && (int)($comp['pending_reboot'] ?? 0) === 1) {
        $issues[] = 'Reboot noodzakelijk na update';
    }

    if (!empty($cfg['require_firewall_all_profiles'])) {
        foreach (['domain' => 'Domain', 'private' => 'Private', 'public' => 'Public'] as $key => $label) {
            if ((int)($comp["firewall_{$key}"] ?? 0) !== 1) {
                $issues[] = "Windows Firewall profiel {$label} staat uit";
            }
        }
    }

    $status = 'ok';
    if (count($issues) > 0) {
        $criticalKeywords = ['BitLocker', 'Antivirus', 'Real-time', 'administratorrechten', 'Gastaccount'];
        foreach ($issues as $i) {
            foreach ($criticalKeywords as $kw) {
                if (stripos($i, $kw) !== false) {
                    return ['status' => 'fail', 'issues' => $issues];
                }
            }
        }
        $status = 'warn';
    }
    return ['status' => $status, 'issues' => $issues];
}

function count_compliance_issues(): int {
    global $CONFIG;
    try {
        $pdo = db();
        $cfg = $CONFIG['compliance'] ?? [];
        $rows = $pdo->query("
            SELECT c.*, a.id AS asset_id
            FROM asset_compliance c
            JOIN assets a ON a.id = c.asset_id
        ")->fetchAll();
        $n = 0;
        foreach ($rows as $r) {
            $res = evaluate_compliance($r, $r, $cfg);
            if ($res['status'] !== 'ok') $n++;
        }
        return $n;
    } catch (Throwable $e) {
        return 0;
    }
}

function screen_lock_source_label(string $src): string {
    return match ($src) {
        'machine_policy'    => 'Machine Policy (HKLM InactivityTimeoutSecs)',
        'screensaver_user'  => 'Schermbeveiliging ingelogde gebruiker (HKCU via HKEY_USERS)',
        'screensaver_agent' => 'Schermbeveiliging agent-context (HKCU)',
        'none'              => 'Niet ingesteld',
        default             => $src !== '' ? $src : 'Onbekend',
    };
}

function format_screen_lock(int $seconds, int $minutes): string {
    if ($seconds > 0) {
        $minsExact = $seconds / 60;
        $minsLabel = (floor($minsExact) == $minsExact)
            ? (int)$minsExact . ' min'
            : number_format($minsExact, 1, ',', '.') . ' min';
        return $seconds . ' sec (' . $minsLabel . ')';
    }
    if ($minutes > 0) {
        return $minutes . ' min';
    }
    return 'Niet ingesteld';
}

/**
 * --- SMTP MAILER ---
 */
function smtp_send(array $mailConfig, string $toEmail, string $subject, string $body, ?string $htmlBody = null): bool {
    $host       = $mailConfig['host'] ?? '';
    $port       = (int)($mailConfig['port'] ?? 587);
    $encryption = strtolower((string)($mailConfig['encryption'] ?? 'tls'));
    $useAuth    = !empty($mailConfig['smtp_auth']);
    $username   = $mailConfig['username'] ?? '';
    $password   = $mailConfig['password'] ?? '';
    $fromEmail  = $mailConfig['from_email'] ?? $username;
    $fromName   = $mailConfig['from_name'] ?? 'IT Service Desk';

    if ($host === '' || $fromEmail === '') {
        error_log('SMTP: host of from_email ontbreekt in config.php.');
        return false;
    }

    $transportPrefix = ($encryption === 'ssl') ? 'ssl://' : '';
    $timeout = 15;

    $errno = 0; $errstr = '';
    $socket = @stream_socket_client($transportPrefix . $host . ':' . $port, $errno, $errstr, $timeout);
    if (!$socket) {
        error_log("SMTP: kan geen verbinding maken met $host:$port ($errno: $errstr)");
        return false;
    }
    stream_set_timeout($socket, $timeout);

    $read = function () use ($socket): string {
        $data = '';
        while (($line = fgets($socket, 515)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return $data;
    };
    $write = function (string $cmd) use ($socket): void {
        fwrite($socket, $cmd . "\r\n");
    };
    $expect = function (string $cmd, string $expectedCode) use ($read, $write, $socket): bool {
        if ($cmd !== '') $write($cmd);
        $resp = $read();
        if (substr($resp, 0, 3) !== $expectedCode) {
            error_log("SMTP fout op '$cmd': $resp");
            fclose($socket);
            return false;
        }
        return true;
    };

    $banner = $read();
    if (substr($banner, 0, 3) !== '220') { fclose($socket); return false; }

    $ehloHost = $_SERVER['SERVER_NAME'] ?? 'localhost';
    if (!$expect("EHLO $ehloHost", '250')) return false;

    if ($encryption === 'tls') {
        if (!$expect('STARTTLS', '220')) return false;
        if (!@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            error_log('SMTP: STARTTLS handshake mislukt.');
            fclose($socket);
            return false;
        }
        if (!$expect("EHLO $ehloHost", '250')) return false;
    }

    if ($useAuth && $username !== '') {
        if (!$expect('AUTH LOGIN', '334')) return false;
        if (!$expect(base64_encode($username), '334')) return false;
        if (!$expect(base64_encode($password), '235')) return false;
    }

    if (!$expect("MAIL FROM:<$fromEmail>", '250')) return false;
    if (!$expect("RCPT TO:<$toEmail>", '250')) return false;
    if (!$expect('DATA', '354')) return false;

    $headers = [];
    $headers[] = 'MIME-Version: 1.0';
    $boundary = null;
    if ($htmlBody !== null && $htmlBody !== '') {
        $boundary = 'itsm-' . bin2hex(random_bytes(12));
        $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
    } else {
        $headers[] = 'Content-Type: text/plain; charset=utf-8';
    }
    $headers[] = 'From: ' . $fromName . ' <' . $fromEmail . '>';
    $headers[] = 'Reply-To: ' . ($mailConfig['reply_to'] ?? $fromEmail);
    $headers[] = 'Subject: ' . $subject;
    $headers[] = 'Date: ' . date('r');
    $headers[] = 'X-Mailer: ITSM-ControlCenter-PHP/' . phpversion();

    if ($boundary !== null) {
        $mimeBody  = "Dit bericht bevat opmaak. Gebruik een e-mailclient die HTML ondersteunt.\r\n\r\n";
        $mimeBody .= "--$boundary\r\n";
        $mimeBody .= "Content-Type: text/plain; charset=utf-8\r\n";
        $mimeBody .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
        $mimeBody .= $body . "\r\n\r\n";
        $mimeBody .= "--$boundary\r\n";
        $mimeBody .= "Content-Type: text/html; charset=utf-8\r\n";
        $mimeBody .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
        $mimeBody .= $htmlBody . "\r\n\r\n";
        $mimeBody .= "--$boundary--";
    } else {
        $mimeBody = $body;
    }

    $escapedBody = preg_replace('/^\./m', '..', $mimeBody);
    $data = implode("\r\n", $headers) . "\r\n\r\n" . $escapedBody . "\r\n.";

    if (!$expect($data, '250')) return false;

    $write('QUIT');
    fclose($socket);
    return true;
}

function mail_html_wrap(string $innerHtml): string {
    $logo = e(ORG_LOGO_URL_ABS);
    $org  = e(ORG_NAME);
    $hasLogo = preg_match('~^https?://~i', ORG_LOGO_URL_ABS) === 1;

    $header = $hasLogo
        ? '<img src="' . $logo . '" alt="' . $org . '" width="200" style="display:block;border:0;max-width:200px;height:auto;">'
        : '<span style="font:700 18px Arial,sans-serif;color:#10243e;">' . $org . '</span>';

    return '<!doctype html><html lang="nl"><body style="margin:0;padding:0;background:#f3f5f8;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f5f8;padding:24px 0;">'
        . '<tr><td align="center">'
        . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:600px;max-width:100%;background:#ffffff;border:1px solid #dce2e8;border-radius:10px;overflow:hidden;">'
        . '<tr><td style="padding:22px 28px;border-bottom:1px solid #dce2e8;">' . $header . '</td></tr>'
        . '<tr><td style="height:3px;background:#ff5f00;line-height:3px;font-size:0;">&nbsp;</td></tr>'
        . '<tr><td style="padding:26px 28px;font:14px/1.6 Arial,Helvetica,sans-serif;color:#17202a;">' . $innerHtml . '</td></tr>'
        . '<tr><td style="padding:16px 28px;background:#10243e;font:12px/1.5 Arial,Helvetica,sans-serif;color:#b9c6d4;">'
        . $org . ' &middot; IT Service Desk<br>Deze e-mail is automatisch verstuurd; u kunt reageren via uw ticket.'
        . '</td></tr>'
        . '</table></td></tr></table></body></html>';
}

function send_ticket_email(string $toEmail, string $subject, string $messageBody, ?string $htmlBody = null): bool {
    global $CONFIG;

    if (empty($toEmail) || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $mailConfig = $CONFIG['mail'] ?? [];
    $driver = $mailConfig['driver'] ?? 'smtp';

    if ($driver === 'native') {
        $fromEmail = $mailConfig['from_email'] ?? 'helpdesk@company.local';
        $fromName  = $mailConfig['from_name'] ?? 'IT Helpdesk';
        $headers = [];
        $headers[] = 'MIME-Version: 1.0';
        if ($htmlBody !== null && $htmlBody !== '') {
            $headers[] = 'Content-type: text/html; charset=utf-8';
            $messageBody = $htmlBody;
        } else {
            $headers[] = 'Content-type: text/plain; charset=utf-8';
        }
        $headers[] = "From: $fromName <$fromEmail>";
        $headers[] = 'Reply-To: ' . ($mailConfig['reply_to'] ?? $fromEmail);
        $headers[] = 'X-Mailer: PHP/' . phpversion();
        return @mail($toEmail, $subject, $messageBody, implode("\r\n", $headers));
    }

    try {
        $sent = smtp_send($mailConfig, $toEmail, $subject, $messageBody, $htmlBody);
        error_log($sent ? "SMTP: mail verzonden naar $toEmail" : "SMTP: verzenden naar $toEmail is mislukt (zie voorgaande SMTP-fout).");
        return $sent;
    } catch (Throwable $e) {
        error_log('SMTP exception: ' . $e->getMessage());
        return false;
    }
}

// --- AFHANDELING POST ACTIES ---
$pdo = db();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

/**
 * --- ASSET AGENT CHECK-IN ---
 */
if (($_GET['view'] ?? '') === 'agent-checkin' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $providedKey = $_SERVER['HTTP_X_AGENT_KEY'] ?? '';
    $expectedKey = $CONFIG['security']['agent_api_key'] ?? '';

    if ($expectedKey === '' || !hash_equals($expectedKey, $providedKey)) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Ongeldige of ontbrekende X-Agent-Key.']);
        exit;
    }

    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Ongeldige JSON payload.']);
        exit;
    }

    $assetTag = trim((string)($data['asset_tag'] ?? $data['hostname'] ?? ''));
    if ($assetTag === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'asset_tag (of hostname) is verplicht.']);
        exit;
    }

    $allowedFields = [
        'hostname','functional_name','username','manufacturer','model','serial_number','bios_version',
        'windows_version','windows_build','cpu','ram_mb','ip_address','mac_address',
        'disk_summary','defender_status','tpm_status','bitlocker_status','location','department','notes'
    ];
    $fields = [];
    foreach ($allowedFields as $f) {
        if (array_key_exists($f, $data)) {
            $fields[$f] = $f === 'ram_mb' ? (int)$data[$f] : (string)$data[$f];
        }
    }

    $existing = $pdo->prepare("SELECT id FROM assets WHERE asset_tag = ?");
    $existing->execute([$assetTag]);
    $existingId = $existing->fetchColumn();

    if ($existingId) {
        if ($fields) {
            $setSql = implode(', ', array_map(fn($f) => "$f = :$f", array_keys($fields)));
            $stmt = $pdo->prepare("UPDATE assets SET $setSql, last_seen = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE asset_tag = :asset_tag");
            $fields['asset_tag'] = $assetTag;
            $stmt->execute($fields);
        } else {
            $pdo->prepare("UPDATE assets SET last_seen = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE asset_tag = ?")->execute([$assetTag]);
        }
        $assetId = (int)$existingId;
        $responseAction = 'updated';
    } else {
        $fields['asset_tag'] = $assetTag;
        $cols = array_keys($fields);
        $placeholders = array_map(fn($c) => ":$c", $cols);
        $sql = "INSERT INTO assets(" . implode(',', $cols) . ", last_seen) VALUES(" . implode(',', $placeholders) . ", CURRENT_TIMESTAMP)";
        $pdo->prepare($sql)->execute($fields);
        $assetId = (int)$pdo->lastInsertId();
        $responseAction = 'created';
    }

    /* === SOFTWARE INGESTION === */
    $softwareCount = null;
    if (isset($data['software']) && is_array($data['software'])) {
        $pdo->prepare("DELETE FROM asset_software WHERE asset_id = ?")->execute([$assetId]);
        $insSoft = $pdo->prepare("INSERT INTO asset_software(asset_id,name,version,publisher,install_date) VALUES(?,?,?,?,?)");
        $softwareCount = 0;
        foreach ($data['software'] as $sw) {
            if (!is_array($sw)) continue;
            $name = trim((string)($sw['name'] ?? ''));
            if ($name === '') continue;
            $insSoft->execute([
                $assetId,
                mb_substr($name, 0, 255),
                mb_substr(trim((string)($sw['version'] ?? '')), 0, 100),
                mb_substr(trim((string)($sw['publisher'] ?? '')), 0, 255),
                mb_substr(trim((string)($sw['install_date'] ?? '')), 0, 20),
            ]);
            $softwareCount++;
        }
    }

    /* === VOLUMES INGESTION === */
    $volumeCount = null;
    $lowDiskCount = null;
    if (isset($data['volumes']) && is_array($data['volumes'])) {
        $pdo->prepare("DELETE FROM asset_volumes WHERE asset_id = ?")->execute([$assetId]);
        $insVol = $pdo->prepare("INSERT INTO asset_volumes(asset_id,drive_letter,label,file_system,size_gb,free_gb,free_percent,is_low) VALUES(?,?,?,?,?,?,?,?)");
        $volumeCount = 0;
        $lowDiskCount = 0;
        foreach ($data['volumes'] as $v) {
            if (!is_array($v)) continue;
            $drive = trim((string)($v['drive_letter'] ?? ''));
            if ($drive === '') continue;

            $freeGb = (float)($v['free_gb'] ?? 0);
            $isLow = ($freeGb < LOW_DISK_THRESHOLD_GB) ? 1 : 0;

            $insVol->execute([
                $assetId,
                mb_substr($drive, 0, 10),
                mb_substr(trim((string)($v['label'] ?? '')), 0, 190),
                mb_substr(trim((string)($v['file_system'] ?? '')), 0, 20),
                (float)($v['size_gb'] ?? 0),
                $freeGb,
                (float)($v['free_percent'] ?? 0),
                $isLow,
            ]);
            $volumeCount++;
            if ($isLow) $lowDiskCount++;
        }
    }

    /* === PENDING UPDATES INGESTION === */
    $updateCount = null;
    if (isset($data['pending_updates']) && is_array($data['pending_updates'])) {
        $pdo->prepare("DELETE FROM asset_pending_updates WHERE asset_id = ?")->execute([$assetId]);
        $insUpd = $pdo->prepare("INSERT INTO asset_pending_updates(asset_id,title,kb,severity,size_mb,category,source) VALUES(?,?,?,?,?,?,?)");
        $updateCount = 0;
        foreach ($data['pending_updates'] as $u) {
            if (!is_array($u)) continue;
            $title = trim((string)($u['title'] ?? ''));
            if ($title === '') continue;
            $insUpd->execute([
                $assetId,
                mb_substr($title, 0, 500),
                mb_substr(trim((string)($u['kb'] ?? '')), 0, 255),
                mb_substr(trim((string)($u['severity'] ?? '')), 0, 50),
                (float)($u['size_mb'] ?? 0),
                mb_substr(trim((string)($u['category'] ?? '')), 0, 255),
                mb_substr(trim((string)($u['source'] ?? '')), 0, 50),
            ]);
            $updateCount++;
        }
    }

    /* === COMPLIANCE INGESTION === */
    $complianceStored = false;
    if (isset($data['compliance']) && is_array($data['compliance'])) {
        $c = $data['compliance'];

        $adminsList = '';
        if (isset($c['local_admins_list']) && is_array($c['local_admins_list'])) {
            $adminsList = implode(', ', array_map('strval', $c['local_admins_list']));
        } elseif (isset($c['local_admins_list'])) {
            $adminsList = (string)$c['local_admins_list'];
        }

        $compRow = [
            'asset_id'                     => $assetId,
            'bitlocker_system_protection'  => mb_substr(trim((string)($c['bitlocker_system_protection'] ?? '')), 0, 50),
            'bitlocker_source'             => mb_substr(trim((string)($c['bitlocker_source'] ?? '')), 0, 50),
            'screen_lock_timeout_minutes'  => (int)($c['screen_lock_timeout_minutes'] ?? 0),
            'screen_lock_timeout_seconds'  => (int)($c['screen_lock_timeout_seconds'] ?? 0),
            'screen_lock_source'           => mb_substr(trim((string)($c['screen_lock_source'] ?? '')), 0, 50),
            'local_admins_count'           => (int)($c['local_admins_count'] ?? 0),
            'local_admins_list'            => $adminsList,
            'local_admins_source'          => mb_substr(trim((string)($c['local_admins_source'] ?? '')), 0, 50),
            'daily_user_is_admin'          => !empty($c['daily_user_is_admin']) ? 1 : 0,
            'guest_account_enabled'        => !empty($c['guest_account_enabled']) ? 1 : 0,
            'guest_account_source'         => mb_substr(trim((string)($c['guest_account_source'] ?? '')), 0, 50),
            'min_password_length'          => (int)($c['min_password_length'] ?? 0),
            'password_complexity'          => !empty($c['password_complexity']) ? 1 : 0,
            'password_policy_source'       => mb_substr(trim((string)($c['password_policy_source'] ?? '')), 0, 50),
            'antivirus_enabled'            => !empty($c['antivirus_enabled']) ? 1 : 0,
            'realtime_protection_enabled'  => !empty($c['realtime_protection_enabled']) ? 1 : 0,
            'antivirus_source'             => mb_substr(trim((string)($c['antivirus_source'] ?? '')), 0, 50),
            'last_update_date'             => mb_substr(trim((string)($c['last_update_date'] ?? '')), 0, 20),
            'last_update_kb'               => mb_substr(trim((string)($c['last_update_kb'] ?? '')), 0, 255),
            'pending_reboot'               => !empty($c['pending_reboot']) ? 1 : 0,
            'firewall_domain'              => !empty($c['firewall_domain']) ? 1 : 0,
            'firewall_private'             => !empty($c['firewall_private']) ? 1 : 0,
            'firewall_public'              => !empty($c['firewall_public']) ? 1 : 0,
            'agent_is_admin'               => !empty($c['agent_is_admin']) ? 1 : 0,
        ];

        $existingComp = $pdo->prepare("SELECT id FROM asset_compliance WHERE asset_id = ?");
        $existingComp->execute([$assetId]);
        $existingCompId = $existingComp->fetchColumn();

        if ($existingCompId) {
            $updateData = $compRow;
            unset($updateData['asset_id']);

            $setSql = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($updateData)));
            $stmt = $pdo->prepare("UPDATE asset_compliance SET $setSql, updated_at = CURRENT_TIMESTAMP WHERE asset_id = :asset_id");
            $updateData['asset_id'] = $assetId;
            $stmt->execute($updateData);
        } else {
            $cols = array_keys($compRow);
            $placeholders = array_map(fn($k) => ":$k", $cols);
            $sql = "INSERT INTO asset_compliance(" . implode(',', $cols) . ") VALUES(" . implode(',', $placeholders) . ")";
            $pdo->prepare($sql)->execute($compRow);
        }

        $complianceStored = true;
    }
    /* END COMPLIANCE INGESTION */

    /* === SECURITY POLICY INGESTION (independent of compliance) === */
    if (isset($data['security_policy']) && is_array($data['security_policy'])) {
        $sp = $data['security_policy'];
        $spRow = [
            'asset_id'                     => $assetId,
            'min_password_length'          => (int)($sp['min_password_length'] ?? 0),
            'password_complexity'          => !empty($sp['password_complexity']) ? 1 : 0,
            'screen_lock_timeout_minutes'  => (int)($sp['screen_lock_timeout_minutes'] ?? 0),
            'guest_account_enabled'        => !empty($sp['guest_account_enabled']) ? 1 : 0,
        ];

        $existingSp = $pdo->prepare("SELECT id FROM asset_security_policy WHERE asset_id = ?");
        $existingSp->execute([$assetId]);
        $existingSpId = $existingSp->fetchColumn();

        if ($existingSpId) {
            $updateSp = $spRow;
            unset($updateSp['asset_id']);
            $setSql = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($updateSp)));
            $stmt = $pdo->prepare("UPDATE asset_security_policy SET $setSql, updated_at = CURRENT_TIMESTAMP WHERE asset_id = :asset_id");
            $updateSp['asset_id'] = $assetId;
            $stmt->execute($updateSp);
        } else {
            $cols = array_keys($spRow);
            $placeholders = array_map(fn($k) => ":$k", $cols);
            $sql = "INSERT INTO asset_security_policy(" . implode(',', $cols) . ") VALUES(" . implode(',', $placeholders) . ")";
            $pdo->prepare($sql)->execute($spRow);
        }
    }
    /* END SECURITY POLICY INGESTION */

    /* === BUILD RESPONSE === */
    $response = ['ok' => true, 'action' => $responseAction, 'asset_tag' => $assetTag];
    if ($softwareCount !== null) {
        $response['software_count'] = $softwareCount;
    }
    if ($volumeCount !== null) {
        $response['volume_count']   = $volumeCount;
        $response['low_disk_count'] = $lowDiskCount;
    }
    if ($updateCount !== null) {
        $response['pending_updates_count'] = $updateCount;
    }
    if ($complianceStored) {
        $response['compliance_stored'] = true;
    }

    echo json_encode($response);
    exit;
}

/**
 * --- ASSET SCRIPT DOWNLOAD ---
 */
if (($_GET['view'] ?? '') === 'agent-script') {
    if (!is_admin_authenticated()) {
        redirect('index.php?view=admin-login');
    }
    $scriptPath = __DIR__ . DIRECTORY_SEPARATOR . 'asset.ps1';
    if (is_file($scriptPath)) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="asset.ps1"');
        readfile($scriptPath);
        exit;
    }
    http_response_code(404);
    echo 'asset.ps1 niet gevonden.';
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_csrf();
        $postAction = $_POST['action'] ?? '';

        if ($postAction === 'admin_softtoken_login') {
            $tokenInput = trim((string)($_POST['softtoken'] ?? ''));
            $timeStep   = (int)($CONFIG['security']['totp_time_step'] ?? 30);
            $admins     = $CONFIG['security']['totp_admins'] ?? [];
            $fallback   = (string)($CONFIG['security']['totp_secret'] ?? '');

            $identified = totp_identify_admin($tokenInput, $admins, $timeStep);

            $isFallback = false;
            if ($identified === null && $fallback !== '' && totp_verify($tokenInput, $fallback, $timeStep)) {
                $identified = 'Beheerder';
                $isFallback = true;
            }

            if ($identified !== null) {
                $_SESSION['is_admin_authenticated']  = true;
                $_SESSION['admin_authenticated_at']  = time();
                $_SESSION['admin_name']              = $identified;
                $_SESSION['admin_is_fallback']       = $isFallback;
                flash('success', 'Succesvol geauthenticeerd als ' . $identified . ' (Softtoken).');
                redirect('index.php?view=dashboard');
            } else {
                throw new RuntimeException('Ongeldige of verlopen Softtoken code. Toegang geweigerd.');
            }
        }

        if ($postAction === 'admin_logout') {
            unset(
                $_SESSION['is_admin_authenticated'],
                $_SESSION['admin_authenticated_at'],
                $_SESSION['admin_name'],
                $_SESSION['admin_is_fallback']
            );
            flash('success', 'U bent uitgelogd als beheerder.');
            redirect('index.php?view=new-ticket');
        }

        if ($postAction === 'create_public_ticket') {
            $name = trim((string)($_POST['requester_name'] ?? ''));
            $email = trim((string)($_POST['requester_email'] ?? ''));
            $title = trim((string)($_POST['title'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $category = trim((string)($_POST['category'] ?? 'Overige aanvraag'));
            $priority = trim((string)($_POST['priority'] ?? 'Normaal'));
            $assetId = (int)($_POST['asset_id'] ?? 0) ?: null;

            if ($name === '' || $email === '' || $title === '' || $description === '') {
                throw new RuntimeException('Vul a.u.b. alle verplichte velden in.');
            }

            $token = bin2hex(random_bytes(16));
            $num = generate_ticket_number($pdo);

            $s = $pdo->prepare("INSERT INTO tickets(ticket_number,access_token,requester_name,requester_email,asset_id,title,description,category,priority) VALUES(?,?,?,?,?,?,?,?,?)");
            $s->execute([$num, $token, rot47($name), rot47($email), $assetId, $title, $description, $category, $priority]);
            $id = (int)$pdo->lastInsertId();

            audit($id, $name, 'Ticket aangemaakt via Publiek Portaal');

            $ticketUrl = ticket_url($token);

            $mailContent = "Beste $name,\n\nUw ticket is succesvol geregistreerd onder nummer $num.\n\n";
            $mailContent .= "Onderwerp: $title\nCategorie: $category\n\n";
            $mailContent .= "U kunt uw ticket en de status bekijken via de link in deze e-mail.\n\nIT Service Desk";

            $mailHtml  = '<p>Beste ' . e($name) . ',</p>';
            $mailHtml .= '<p>Uw ticket is succesvol geregistreerd onder nummer <strong>' . e($num) . '</strong>.</p>';
            $mailHtml .= '<p>Onderwerp: ' . e($title) . '<br>Categorie: ' . e($category) . '</p>';
            $mailHtml .= '<p>U kunt <a href="' . e($ticketUrl) . '" style="color:#2674c9;">uw ticket en de status bekijken</a>.</p>';
            $mailHtml .= '<p>Met vriendelijke groet,<br>IT Service Desk ' . e(ORG_NAME) . '</p>';

            send_ticket_email($email, "Ticket Ontvangen: [$num] $title", $mailContent, mail_html_wrap($mailHtml));

            flash('success', "Uw ticket ($num) is succesvol aangemaakt!");
            redirect('index.php?view=ticket&token=' . $token);
        }

        if ($postAction === 'reply_ticket') {
            $ticketId = (int)$_POST['ticket_id'];
            $body = trim((string)$_POST['body']);
            $token = trim((string)($_POST['token'] ?? ''));
            $asAdmin = !empty($_POST['is_admin_reply']);

            if ($body === '') throw new RuntimeException('Reactie mag niet leeg zijn.');

            if ($asAdmin) {
                require_admin_auth();
            }

            $s = $pdo->prepare("SELECT * FROM tickets WHERE id=?");
            $s->execute([$ticketId]);
            $ticket = decode_ticket_row($s->fetch());
            if (!$ticket) throw new RuntimeException('Ticket niet gevonden.');

            $senderName = $asAdmin ? admin_first_name() : $ticket['requester_name'];
            $internal = ($asAdmin && !empty($_POST['is_internal'])) ? 1 : 0;

            $pdo->prepare("INSERT INTO ticket_replies(ticket_id,sender_name,user_id,body,is_internal) VALUES(?,?,?,?,?)")
                ->execute([$ticketId, $senderName, $asAdmin ? 1 : null, $body, $internal]);

            $pdo->prepare("UPDATE tickets SET updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$ticketId]);
            audit($ticketId, $senderName, $internal ? 'Interne notitie toegevoegd' : 'Reactie geplaatst', $body);

            if ($asAdmin && !$internal && !empty($ticket['requester_email'])) {
                $adminFirstName = admin_first_name();
                $mailMsg = "Beste " . $ticket['requester_name'] . ",\n\nEr is een reactie geplaatst op uw ticket [" . $ticket['ticket_number'] . "] \"" . $ticket['title'] . "\":\n\n" . $body . "\n\nMet vriendelijke groet,\n$adminFirstName - IT Service Desk";

                $replyUrl  = ticket_url((string)$ticket['access_token']);
                $mailHtml  = '<p>Beste ' . e($ticket['requester_name']) . ',</p>';
                $mailHtml .= '<p>Er is een reactie geplaatst op uw ticket [' . e($ticket['ticket_number']) . '] "' . e($ticket['title']) . '":</p>';
                $mailHtml .= '<blockquote style="margin:0 0 1em; padding-left:12px; border-left:3px solid #ccc;">' . nl2br(e($body)) . '</blockquote>';
                $mailHtml .= '<p>U kunt <a href="' . e($replyUrl) . '" style="color:#2674c9;">uw ticket en de status bekijken</a>.</p>';
                $mailHtml .= '<p>Met vriendelijke groet,<br>' . e($adminFirstName) . ' - IT Service Desk ' . e(ORG_NAME) . '</p>';

                send_ticket_email($ticket['requester_email'], "Update op ticket [" . $ticket['ticket_number'] . "]", $mailMsg, mail_html_wrap($mailHtml));
            }

            flash('success', 'Reactie geplaatst.');
            redirect('index.php?view=ticket&' . ($token ? "token=$token" : "id=$ticketId"));
        }

        if ($postAction === 'admin_update_ticket') {
            require_admin_auth();
            $ticketId = (int)$_POST['ticket_id'];
            $status = trim((string)$_POST['status']);
            $priority = trim((string)$_POST['priority']);

            $pdo->prepare("UPDATE tickets SET status=?,priority=?,updated_at=CURRENT_TIMESTAMP,closed_at=? WHERE id=?")
                ->execute([$status, $priority, in_array($status,['Gesloten','Opgelost'],true) ? date('Y-m-d H:i:s') : null, $ticketId]);

            audit($ticketId, admin_first_name(), 'Status gewijzigd', "Status: $status; Prioriteit: $priority");
            flash('success', 'Ticket status bijgewerkt.');
            redirect('index.php?view=ticket&id=' . $ticketId);
        }

        if ($postAction === 'save_template') {
            require_admin_auth();
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)$_POST['name']);
            $category = trim((string)$_POST['category']);
            $subject = trim((string)$_POST['subject']);
            $body = trim((string)$_POST['body']);

            if ($id) {
                $pdo->prepare("UPDATE ticket_templates SET name=?,category=?,subject=?,body=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
                    ->execute([$name, $category, $subject, $body, !empty($_POST['active'])?1:0, $id]);
            } else {
                $pdo->prepare("INSERT INTO ticket_templates(name,category,subject,body,active) VALUES(?,?,?,?,?)")
                    ->execute([$name, $category, $subject, $body, !empty($_POST['active'])?1:0]);
            }
            flash('success', 'Aanvraagtemplate opgeslagen.');
            redirect('index.php?view=templates');
        }

        if ($postAction === 'delete_template') {
            require_admin_auth();
            $delId = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM ticket_templates WHERE id=?");
            $stmt->execute([$delId]);
            if ($stmt->rowCount() > 0) {
                flash('success', 'Template verwijderd.');
            } else {
                flash('error', 'Template niet gevonden of al verwijderd.');
            }
            redirect('index.php?view=templates');
        }

        if ($postAction === 'save_reaction') {
            require_admin_auth();
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)$_POST['name']);
            $body = trim((string)$_POST['body']);

            if ($id) {
                $pdo->prepare("UPDATE ticket_reactions SET name=?,body=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
                    ->execute([$name, $body, !empty($_POST['active'])?1:0, $id]);
            } else {
                $pdo->prepare("INSERT INTO ticket_reactions(name,body,active) VALUES(?,?,?)")
                    ->execute([$name, $body, !empty($_POST['active'])?1:0]);
            }
            flash('success', 'Standaardreactie opgeslagen.');
            redirect('index.php?view=reactions');
        }

        if ($postAction === 'delete_reaction') {
            require_admin_auth();
            $delId = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM ticket_reactions WHERE id=?");
            $stmt->execute([$delId]);
            if ($stmt->rowCount() > 0) {
                flash('success', 'Standaardreactie verwijderd.');
            } else {
                flash('error', 'Standaardreactie niet gevonden of al verwijderd.');
            }
            redirect('index.php?view=reactions');
        }

        /* === BULK RENAME ASSETS === */
        if ($postAction === 'save_bulk_rename') {
            require_admin_auth();

            $renames = $_POST['rename'] ?? [];
            if (!is_array($renames)) {
                throw new RuntimeException('Ongeldige bulk rename data.');
            }

            $updated = 0;
            $updStmt = $pdo->prepare("UPDATE assets SET hostname=?, functional_name=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $selStmt = $pdo->prepare("SELECT asset_tag, hostname, functional_name FROM assets WHERE id=?");

            foreach ($renames as $assetId => $vals) {
                $assetId = (int)$assetId;
                if ($assetId <= 0) continue;
                if (!is_array($vals)) continue;

                $newHost = trim((string)($vals['hostname'] ?? ''));
                $newFunc = trim((string)($vals['functional_name'] ?? ''));

                if ($newHost === '' && $newFunc === '') continue;

                // Limiteer lengtes
                $newHost = mb_substr($newHost, 0, 190);
                $newFunc = mb_substr($newFunc, 0, 190);

                $selStmt->execute([$assetId]);
                $old = $selStmt->fetch();
                if (!$old) continue;

                $updStmt->execute([$newHost, $newFunc, $assetId]);

                if ($updStmt->rowCount() > 0) {
                    $updated++;
                    $details = sprintf(
                        'Asset %s: hostname "%s" -> "%s"; functionele naam "%s" -> "%s"',
                        (string)$old['asset_tag'],
                        (string)$old['hostname'],
                        $newHost,
                        (string)$old['functional_name'],
                        $newFunc
                    );
                    // ticket_id = NULL voor systeem-events (geen FK-fout meer)
                    audit(null, admin_full_name(), 'Bulk rename', $details);
                }
            }

            flash('success', "Bulk rename voltooid. {$updated} asset(s) bijgewerkt.");
            redirect('index.php?view=bulk-rename');
        }
    }
} catch (Throwable $ex) {
    flash('error', $ex->getMessage());
    redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
}

$view = $_GET['view'] ?? 'new-ticket';

if (in_array($view, ['dashboard', 'tickets', 'templates', 'reactions', 'assets', 'asset-software', 'alerts', 'windows-updates', 'all-software', 'software-clients', 'compliance', 'compliance-asset', 'bulk-rename'], true) && !is_admin_authenticated()) {
    $view = 'admin-login';
}

function nav_active(string $name, string $view): string {
    return $name === $view ? 'active' : '';
}

function render_header(string $title): void {
?>
<!doctype html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=e($title)?> - <?=e(ORG_NAME)?> IT Service Desk</title>
<link rel="icon" href="<?=e(ORG_LOGO_URL)?>">
<link rel="apple-touch-icon" href="<?=e(ORG_LOGO_URL)?>">
<style>
:root{
    --navy:#10243e;--navy2:#173653;--accent:#ff5f00;--blue:#2674c9;
    --bg:#f3f5f8;--card:#fff;--text:#17202a;--muted:#697586;--border:#dce2e8;
    --green:#16834b;--red:#c73737;--yellow:#b87900;--shadow:0 8px 24px rgba(16,36,62,.08)
}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{font-family:Inter,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--text)}
a{color:inherit;text-decoration:none}.layout{min-height:100vh;display:flex}
.sidebar{width:250px;background:var(--navy);color:#fff;position:fixed;inset:0 auto 0 0;overflow:auto}
.brand{padding:18px 20px 20px;border-bottom:1px solid rgba(255,255,255,.1)}
.brand strong{display:block;font-size:16px}.brand small{color:#b9c6d4}
.brand .logo{display:block;background:#fff;border-radius:8px;padding:10px 12px;margin:0 0 14px;text-align:center}
.brand .logo img{display:block;width:100%;max-width:180px;height:auto;margin:0 auto}
.loginlogo{text-align:center;margin:0 0 18px}
.loginlogo img{max-width:220px;width:100%;height:auto}
.brandfoot{padding:14px 20px 22px;font-size:11px;color:#7f95aa;line-height:1.5}
.nav{padding:12px}.nav a{display:flex;gap:11px;align-items:center;padding:11px 12px;margin:3px 0;border-radius:8px;color:#dce6ef;font-size:14px}
.nav a:hover,.nav a.active{background:var(--navy2);color:#fff;border-left:3px solid var(--accent);padding-left:9px}
.nav .section{font-size:10px;text-transform:uppercase;letter-spacing:1.2px;color:#7f95aa;padding:17px 12px 6px}
.nav .badge-count{margin-left:auto;background:var(--red);color:#fff;border-radius:999px;padding:1px 7px;font-size:10px;font-weight:700}
.main{margin-left:250px;width:calc(100% - 250px);min-width:0}.topbar{height:68px;background:#fff;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:5}
.topbar h1{font-size:19px;margin:0}.userbox{font-size:13px;color:var(--muted)}.content{padding:28px;max-width:1500px;margin:auto}.flash{padding:12px 15px;border-radius:8px;margin-bottom:20px;border:1px solid}
.flash.success{background:#eaf7f0;color:#12653b;border-color:#b9e3ca}.flash.error{background:#fff0f0;color:#9e2727;border-color:#efc2c2}
.grid{display:grid;gap:18px}.grid4{grid-template-columns:repeat(4,minmax(0,1fr))}.grid3{grid-template-columns:repeat(3,minmax(0,1fr))}.grid2{grid-template-columns:repeat(2,minmax(0,1fr))}
.card{background:var(--card);border:1px solid var(--border);border-radius:10px;box-shadow:var(--shadow);padding:20px}.card h2,.card h3{margin:0 0 14px}.stat{font-size:28px;font-weight:700}.muted{color:var(--muted);font-size:13px}.accentline{height:3px;background:var(--accent);border-radius:4px;margin:-20px -20px 18px}
table{width:100%;border-collapse:collapse;font-size:13px}th{background:var(--navy);color:#fff;text-align:left;padding:11px 10px}td{padding:11px 10px;border-bottom:1px solid var(--border);vertical-align:top}tr:hover td{background:#fafbfd}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:7px;padding:9px 13px;font-size:13px;font-weight:600;cursor:pointer;background:var(--blue);color:#fff}.btn:hover{filter:brightness(.95)}
.btn.orange{background:var(--accent)}.btn.dark{background:var(--navy)}.btn.light{background:#eef2f6;color:#26384a}.btn.red{background:var(--red)}.btn.green{background:var(--green)}
.actions{display:flex;gap:8px;flex-wrap:wrap}.toolbar{display:flex;align-items:center;gap:10px;margin-bottom:18px;flex-wrap:wrap}
label{display:block;font-size:12px;font-weight:700;margin:0 0 6px;color:#425466}input,select,textarea{width:100%;border:1px solid #cfd7df;border-radius:7px;padding:10px 11px;background:#fff;color:#17202a;font:inherit;font-size:13px}
textarea{min-height:130px;resize:vertical}.field{margin-bottom:15px}.formgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.full{grid-column:1/-1}
.badge{display:inline-block;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:700;background:#edf1f5}.badge.green{background:#e7f6ee;color:#11653b}.badge.orange{background:#fff0e6;color:#a33d00}.badge.red{background:#ffe9e9;color:#a52020}.badge.blue{background:#e8f1fb;color:#1f5f9e}
pre.code{background:#111b27;color:#dce7f2;border-radius:8px;padding:15px;overflow:auto;font-size:12px}
.reply{border:1px solid var(--border);border-radius:8px;margin:12px 0;padding:15px;background:#fff}.reply.internal{background:#fff9e8;border-color:#ead39b}.replyhead{display:flex;justify-content:space-between;font-size:12px;margin-bottom:10px}.replybody{white-space:pre-wrap;line-height:1.55;font-size:13px}
.empty{padding:35px;text-align:center;color:var(--muted)}
.filterbar{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px}
.filterbar a.filter-btn{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;background:#eef2f6;color:#26384a;font-size:13px;font-weight:600;border:1px solid transparent;transition:all .15s ease}
.filterbar a.filter-btn:hover{background:#e2e8ef}
.filterbar a.filter-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}
.filterbar .count{display:inline-block;background:rgba(0,0,0,.08);color:inherit;border-radius:999px;padding:1px 8px;font-size:11px;font-weight:700}
.filterbar a.filter-btn.active .count{background:rgba(255,255,255,.25)}
.filterbar .range-summary{margin-left:auto;font-size:12px;color:var(--muted);align-self:center}
.searchbar{display:flex;gap:8px;align-items:center;margin:0 0 18px;flex-wrap:wrap}
.searchbar input{max-width:400px}
.compliance-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:999px;font-size:11px;font-weight:700}
.compliance-badge.ok{background:#e7f6ee;color:#11653b}
.compliance-badge.warn{background:#fff6e0;color:#8a5b00}
.compliance-badge.fail{background:#ffe9e9;color:#a52020}
.compliance-badge.none{background:#edf1f5;color:#5c6b7a}
.compliance-issues{font-size:12px;color:#a52020;line-height:1.5;margin-top:5px}
.compliance-grid{display:flex;flex-direction:column;margin-top:10px}
.compliance-item{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap;padding:10px 4px 10px 12px;border-bottom:1px solid var(--border);border-left:3px solid transparent;background:none}
.compliance-item:last-child{border-bottom:0}
.compliance-item .ci-label{flex:0 0 220px;font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.6px;font-weight:700}
.compliance-item .ci-value{font-size:14px;font-weight:700;color:#17202a}
.compliance-item .ci-meta{font-size:11px;color:var(--muted);word-break:break-word;flex:1 1 100%}
.compliance-item.ok{border-left-color:#5fb98a}
.compliance-item.fail{border-left-color:#e07a7a}
.compliance-item.unknown{border-left-color:#e0c268}
.bulk-row{display:grid;grid-template-columns:180px 1fr 1fr 120px;gap:10px;align-items:center;padding:10px;border-bottom:1px solid var(--border)}
.bulk-row:last-child{border-bottom:0}
.bulk-row .bulk-label{font-size:12px;font-weight:700;color:#425466}
.bulk-row .bulk-current{font-size:11px;color:var(--muted)}
.bulk-header{background:#eef2f6;font-weight:700;font-size:11px;color:#425466;text-transform:uppercase;letter-spacing:.6px}
@media(max-width:900px){.sidebar{position:relative;width:100%;height:auto}.layout{display:block}.main{margin:0;width:100%}.grid4,.grid3,.grid2,.formgrid{grid-template-columns:1fr}.bulk-row{grid-template-columns:1fr;gap:6px}}
</style>
</head>
<body>
<div class="layout">
<?php
}

function render_sidebar(string $view): void {
    $lowDiskCount = is_admin_authenticated() ? count_low_disk_alerts() : 0;
    $pendingCount = is_admin_authenticated() ? count_pending_updates() : 0;
    $uniqueSoftware = is_admin_authenticated() ? count_unique_software() : 0;
    $complianceIssues = is_admin_authenticated() ? count_compliance_issues() : 0;
?>
<aside class="sidebar">
    <div class="brand">
        <a class="logo" href="index.php?view=new-ticket" title="<?=e(ORG_NAME)?> - IT Service Desk">
            <img src="<?=e(ORG_LOGO_URL)?>" alt="<?=e(ORG_NAME)?>">
        </a>
        <strong>IT Service Desk</strong>
        <small><?=e(ORG_NAME)?></small>
    </div>
    <nav class="nav">
        <div class="section">Publiek (Zonder Inloggen)</div>
        <a class="<?=nav_active('new-ticket',$view)?>" href="index.php?view=new-ticket">Nieuw Ticket Inschieten</a>
        <a class="<?=nav_active('lookup',$view)?>" href="index.php?view=lookup">Ticket Opzoeken</a>

        <div class="section">IT Service Desk Beheer</div>
        <?php if(is_admin_authenticated()): ?>
            <a class="<?=nav_active('dashboard',$view)?>" href="index.php?view=dashboard">Dashboard Overview</a>
            <a class="<?=nav_active('tickets',$view)?>" href="index.php?view=tickets">Alle Tickets Beheren</a>
            <a class="<?=nav_active('templates',$view)?>" href="index.php?view=templates">Aanvraag Templates</a>
            <a class="<?=nav_active('reactions',$view)?>" href="index.php?view=reactions">Standaard Reacties</a>
            <a class="<?=nav_active('assets',$view)?>" href="index.php?view=assets">IT Asset Inventaris</a>
            <a class="<?=nav_active('bulk-rename',$view)?>" href="index.php?view=bulk-rename">Bulk PC Herbenoemen</a>
            <a class="<?=nav_active('all-software',$view)?>" href="index.php?view=all-software">
                Alle Software
                <?php if ($uniqueSoftware > 0): ?>
                    <span class="badge-count" style="background:var(--blue);"><?=$uniqueSoftware?></span>
                <?php endif; ?>
            </a>
            <a class="<?=nav_active('compliance',$view)?>" href="index.php?view=compliance">
                Compliance (GDPR/AVG/BIO)
                <?php if ($complianceIssues > 0): ?>
                    <span class="badge-count" style="background:var(--red);"><?=$complianceIssues?></span>
                <?php endif; ?>
            </a>
            <a class="<?=nav_active('alerts',$view)?>" href="index.php?view=alerts">
                Schijfruimte Meldingen
                <?php if ($lowDiskCount > 0): ?>
                    <span class="badge-count"><?=$lowDiskCount?></span>
                <?php endif; ?>
            </a>
            <a class="<?=nav_active('windows-updates',$view)?>" href="index.php?view=windows-updates">
                Windows Updates
                <?php if ($pendingCount > 0): ?>
                    <span class="badge-count" style="background:var(--yellow);"><?=$pendingCount?></span>
                <?php endif; ?>
            </a>
        <?php else: ?>
            <a class="<?=nav_active('admin-login',$view)?>" href="index.php?view=admin-login">Beheerder Inloggen (MFA)</a>
        <?php endif; ?>
    </nav>
    <div class="brandfoot">
        <?=e(ORG_NAME)?><br>
        Interne IT-ondersteuning
    </div>
</aside>
<?php
}

function render_topbar(string $title): void {
    $adminName = is_admin_authenticated() ? admin_first_name() : '';
    $isFallback = !empty($_SESSION['admin_is_fallback']);
?>
<header class="topbar">
    <h1><?=e($title)?></h1>
    <div class="userbox">
        <?php if(is_admin_authenticated()): ?>
            <span class="badge green">
                Ingelogd als: <strong><?=e($adminName)?></strong>
                <?php if($isFallback): ?>(generieke code)<?php endif; ?>
                &mdash; Softtoken actief
            </span>
            <form method="post" style="display:inline; margin-left:10px;">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <input type="hidden" name="action" value="admin_logout">
                <button class="btn red" style="padding:4px 8px; font-size:11px;">Uitloggen</button>
            </form>
        <?php else: ?>
            <span class="badge orange">Gast Modus</span>
        <?php endif; ?>
    </div>
</header>
<?php
}

function render_footer(): void {
?>
</main></div></div>
<script>
function applyTemplate(el){
    const o=el.options[el.selectedIndex];
    if(!o) return;
    document.getElementById('ticketTitle').value=o.dataset.subject||o.text;
    document.getElementById('ticketCategory').value=o.dataset.category||'Overige aanvraag';
    document.getElementById('ticketDescription').value=o.dataset.body||'';
}
function applyReaction(el){
    const o=el.options[el.selectedIndex];
    if(o && o.dataset.body){
        const box=document.getElementById('replyBody');
        box.value=(box.value ? box.value+"\n\n" : "")+o.dataset.body;
    }
}
function confirmDelete(form,msg){if(confirm(msg||'Weet u het zeker?')) form.submit(); return false;}
</script>
</body></html>
<?php
}

$titleMap = [
    'new-ticket' => 'Nieuwe Melding of Aanvraag Inschieten',
    'lookup' => 'Ticket Bekijken',
    'admin-login' => 'Beheerder Authenticatie',
    'dashboard' => 'IT Helpdesk Dashboard',
    'tickets' => 'Ticket Overzicht',
    'ticket' => 'Ticket Details & Reacties',
    'templates' => 'Aanvraag Sjablonen Beheren',
    'reactions' => 'Standaard Antwoorden / Reacties',
    'assets' => 'IT Assets & Hardware',
    'asset-software' => 'Geinstalleerde Software',
    'alerts' => 'Schijfruimte Meldingen',
    'windows-updates' => 'Windows Update Meldingen',
    'all-software' => 'Alle Software (alle clients)',
    'software-clients' => 'Clients met deze software',
    'compliance' => 'Compliance (GDPR/AVG/BIO)',
    'compliance-asset' => 'Compliance Details per Asset',
    'bulk-rename' => 'Bulk PC Herbenoemen (Functionele + Computer Naam)',
];

if ($view === 'lookup') {
    $lookupNumber = trim((string)($_GET['num'] ?? ''));
    if ($lookupNumber !== '') {
        $normalized = normalize_ticket_number($lookupNumber);
        $s = $pdo->prepare("SELECT access_token FROM tickets WHERE UPPER(ticket_number) = UPPER(?)");
        $s->execute([$normalized]);
        $foundToken = $s->fetchColumn();
        if ($foundToken) {
            redirect('index.php?view=ticket&token=' . $foundToken);
        }
    }
}

render_header($titleMap[$view] ?? 'ITSM');
render_sidebar($view);
?>
<div class="main">
<?php render_topbar($titleMap[$view] ?? 'ITSM'); ?>
<main class="content">
<?php if($flash): ?><div class="flash <?=$flash['type']?>"><?=e($flash['message'])?></div><?php endif; ?>

<?php
// VIEW: BEHEERDER LOG-IN (SOFTTOKEN)
if ($view === 'admin-login'):
?>
<div class="card" style="max-width:450px; margin:40px auto;">
    <div class="accentline"></div>
    <div class="loginlogo">
        <img src="<?=e(ORG_LOGO_URL)?>" alt="<?=e(ORG_NAME)?>">
    </div>
    <h2>Beheerder Authenticatie</h2>
    <p class="muted">Voer de 6-cijferige Softtoken pincode in om toegang te krijgen tot de beheerderfuncties en te kunnen reageren als IT Administrator.</p>
    <form method="post">
        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
        <input type="hidden" name="action" value="admin_softtoken_login">

        <div class="field">
            <label>Softtoken PIN Code *</label>
            <input type="password" name="softtoken" required inputmode="numeric" pattern="\d{6}" maxlength="6" placeholder="6-cijferige code uit uw Authenticator app" autofocus style="font-size:18px; letter-spacing:3px; text-align:center;">
        </div>
        <button class="btn orange" style="width:100%;">Valideer & Inloggen</button>
    </form>
</div>

<?php
// VIEW: NIEUW TICKET INSCHIETEN
elseif ($view === 'new-ticket'):
    $templates = $pdo->query("SELECT * FROM ticket_templates WHERE active=1 ORDER BY name")->fetchAll();
    $assets = $pdo->query("SELECT id, asset_tag, hostname, functional_name FROM assets ORDER BY COALESCE(NULLIF(functional_name,''), hostname)")->fetchAll();
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Meld een IT-storing of doe een aanvraag</h2>
    <p class="muted">U kunt hier direct een ticket insturen zonder in te loggen.</p>

    <div class="field">
        <label>Kies optioneel een type aanvraag / sjabloon:</label>
        <select onchange="applyTemplate(this)">
            <option value="">- Maak een keuze uit veelvoorkomende aanvragen -</option>
            <?php foreach($templates as $t): ?>
                <option data-subject="<?=e($t['subject'])?>" data-category="<?=e($t['category'])?>" data-body="<?=e($t['body'])?>">
                    <?=e($t['name'])?> (<?=e($t['category'])?>)
                </option>
            <?php endforeach;?>
        </select>
    </div>

    <form method="post">
        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
        <input type="hidden" name="action" value="create_public_ticket">

        <div class="formgrid">
            <div class="field">
                <label>Uw Volledige Naam *</label>
                <input name="requester_name" placeholder="bijv. Jan Jansen" required>
            </div>
            <div class="field">
                <label>Uw E-mailadres *</label>
                <input type="email" name="requester_email" placeholder="jan.jansen@bedrijf.nl" required>
            </div>
            <div class="field">
                <label>Onderwerp / Titel *</label>
                <input id="ticketTitle" name="title" required placeholder="Korte omschrijving">
            </div>
            <div class="field">
                <label>Categorie</label>
                <select id="ticketCategory" name="category">
                    <?php foreach(['MFA / Authenticatie','Software','Hardware','Account','Netwerk','Applicatie','Overige aanvraag'] as $cat): ?>
                        <option><?=e($cat)?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field">
                <label>Prioriteit</label>
                <select name="priority">
                    <option>Laag</option>
                    <option selected>Normaal</option>
                    <option>Hoog</option>
                    <option>Kritiek</option>
                </select>
            </div>
            <div class="field">
                <label>Betreft Asset / Computer (Optioneel)</label>
                <select name="asset_id">
                    <option value="">- Niet gekoppeld aan een specifiek apparaat -</option>
                    <?php foreach($assets as $a): ?>
                        <option value="<?=$a['id']?>">
                            <?=e($a['asset_tag'])?> - <?=e(asset_display($a))?>
                        </option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field full">
                <label>Gedetailleerde Omschrijving *</label>
                <textarea id="ticketDescription" name="description" required placeholder="Vul de details van uw aanvraag of probleem in..."></textarea>
            </div>
        </div>
        <button class="btn orange" style="font-size:14px; padding:12px 20px;">Verstuur Ticket naar IT Desk</button>
    </form>
</div>

<?php
// VIEW: TICKET ZOEKER
elseif ($view === 'lookup'):
    $lookupNumber = trim((string)($_GET['num'] ?? ''));
    $foundToken = null;
?>
<div class="card" style="max-width:600px; margin:auto;">
    <div class="accentline"></div>
    <h2>Ticket Bekijken</h2>
    <p class="muted">Voer het ticketnummer in dat u via de e-mail heeft ontvangen. U kunt zoeken met of zonder <code>VBA-</code> prefix en met willekeurige lettergrootte (bijv. <code>8127</code>, <code>vba-8127</code> of <code>VBA-8127</code>).</p>
    <form method="get">
        <input type="hidden" name="view" value="lookup">
        <div class="field">
            <label>Ticketnummer</label>
            <input name="num" placeholder="VBA-8127 (of 8127 / vba-8127)" value="<?=e($lookupNumber)?>" required>
        </div>
        <button class="btn orange">Zoeken & Openen</button>
    </form>
    <?php if ($lookupNumber !== '' && !$foundToken): ?>
        <div class="flash error" style="margin-top:15px;">Geen ticket gevonden met nummer <?=e($lookupNumber)?>.</div>
    <?php endif;?>
</div>

<?php
// VIEW: TICKET DETAILS & REACTIES
elseif ($view === 'ticket'):
    $id = (int)($_GET['id'] ?? 0);
    $token = trim((string)($_GET['token'] ?? ''));

    if ($token !== '') {
        $s = $pdo->prepare("SELECT t.*, a.asset_tag, a.hostname, a.functional_name FROM tickets t LEFT JOIN assets a ON a.id=t.asset_id WHERE t.access_token=?");
        $s->execute([$token]);
        $t = decode_ticket_row($s->fetch());
    } else {
        $s = $pdo->prepare("SELECT t.*, a.asset_tag, a.hostname, a.functional_name FROM tickets t LEFT JOIN assets a ON a.id=t.asset_id WHERE t.id=?");
        $s->execute([$id]);
        $t = decode_ticket_row($s->fetch());
    }

    if (!$t):
        echo '<div class="card">Ticket niet gevonden of ongeldige toegangstoken.</div>';
    else:
        $ticketId = (int)$t['id'];
        $s = $pdo->prepare("SELECT * FROM ticket_replies WHERE ticket_id=? ORDER BY created_at ASC");
        $s->execute([$ticketId]);
        $replies = $s->fetchAll();

        $reactions = $pdo->query("SELECT * FROM ticket_reactions WHERE active=1 ORDER BY name")->fetchAll();
?>
<div class="toolbar">
    <?php if(is_admin_authenticated()): ?>
        <a class="btn light" href="index.php?view=tickets">Terug naar Ticketoverzicht</a>
    <?php endif; ?>
</div>

<div class="grid grid2">
    <div>
        <div class="card">
            <div class="accentline"></div>
            <div style="font-size:22px; font-weight:700; margin-bottom:6px;"><?=e($t['title'])?></div>
            <div class="muted"><?=e($t['ticket_number'])?> - Categorie: <?=e($t['category'])?></div>
            <br>
            <div class="actions">
                <span class="badge blue"><?=e($t['status'])?></span>
                <span class="badge"><?=e($t['priority'])?></span>
                <?php if($t['asset_tag']):?>
                    <span class="badge green">Asset: <?=e(asset_display($t))?></span>
                <?php endif;?>
            </div>
            <hr style="border:0; border-top:1px solid var(--border); margin:18px 0;">
            <div style="font-size:12px; font-weight:700; color:var(--muted); margin-bottom:8px;">Oorspronkelijke melding door <?=e($t['requester_name'])?> op <?=e($t['created_at'])?>:</div>
            <div class="replybody" style="background:#f9fafb; padding:15px; border-radius:6px; border:1px solid var(--border);"><?=e($t['description'])?></div>
        </div>

        <h3 style="margin-top:20px;">Reacties & Communicatie</h3>
        <?php foreach($replies as $r): ?>
            <div class="reply <?=$r['is_internal']?'internal':''?>">
                <div class="replyhead">
                    <strong><?=e($r['sender_name'])?><?=$r['is_internal']?' - (INTERNE NOTITIE)':''?></strong>
                    <span><?=e($r['created_at'])?></span>
                </div>
                <div class="replybody"><?=e($r['body'])?></div>
            </div>
        <?php endforeach; if(!$replies): ?>
            <p class="muted">Er zijn nog geen reacties geplaatst op dit ticket.</p>
        <?php endif;?>

        <div class="card" style="margin-top:20px;">
            <h3>Reactie Plaatsen</h3>

            <?php if(is_admin_authenticated()): ?>
                <div class="field">
                    <label>Sneltekst / Standaardreactie invoegen:</label>
                    <select onchange="applyReaction(this)">
                        <option value="">- Kies een standaardreactie om in te voegen -</option>
                        <?php foreach($reactions as $rx): ?>
                            <option data-body="<?=e($rx['body'])?>"><?=e($rx['name'])?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <form method="post">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <input type="hidden" name="action" value="reply_ticket">
                <input type="hidden" name="ticket_id" value="<?=$ticketId?>">
                <input type="hidden" name="token" value="<?=e($t['access_token'])?>">

                <div class="field">
                    <textarea id="replyBody" name="body" required placeholder="Type hier uw reactie op het ticket..."></textarea>
                </div>

                <?php if(is_admin_authenticated()): ?>
                    <input type="hidden" name="is_admin_reply" value="1">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="badge green">U reageert als: <strong><?=e(admin_first_name())?></strong></span>
                        <label style="display:flex; gap:8px; align-items:center; font-weight:normal; margin:0;">
                            <input type="checkbox" name="is_internal" value="1" style="width:auto;"> Interne notitie (alleen voor beheerders)
                        </label>
                    </div>
                <?php else: ?>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="badge orange">U reageert als: Aanvrager (<?=e($t['requester_name'])?>)</span>
                        <a href="index.php?view=admin-login" style="font-size:12px; color:var(--blue);">Bent u de beheerder? Inloggen met Softtoken</a>
                    </div>
                <?php endif; ?>
                <br>
                <button class="btn orange">Verstuur Reactie</button>
            </form>
        </div>
    </div>

    <div>
        <?php if(is_admin_authenticated()): ?>
            <div class="card">
                <div class="accentline"></div>
                <h3>Ticket Beheren</h3>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                    <input type="hidden" name="action" value="admin_update_ticket">
                    <input type="hidden" name="ticket_id" value="<?=$ticketId?>">

                    <div class="field">
                        <label>Status</label>
                        <select name="status">
                            <?php foreach(['Nieuw','In behandeling','Wacht op gebruiker','Opgelost','Gesloten'] as $st): ?>
                                <option <?=$t['status']===$st?'selected':''?>><?=e($st)?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="field">
                        <label>Prioriteit</label>
                        <select name="priority">
                            <?php foreach(['Laag','Normaal','Hoog','Kritiek'] as $pr): ?>
                                <option <?=$t['priority']===$pr?'selected':''?>><?=e($pr)?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <button class="btn dark">Status Bijwerken</button>
                </form>
            </div>
        <?php endif; ?>

        <div class="card">
            <h3>Aanvrager Informatie</h3>
            <p><strong>Naam:</strong><br><?=e($t['requester_name'])?></p>
            <p><strong>E-mailadres:</strong><br><?=e($t['requester_email'])?></p>
            <p><strong>Aangemaakt op:</strong><br><?=e($t['created_at'])?></p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
// VIEW: DASHBOARD OVERVIEW (AFGESCHERMD)
elseif ($view === 'dashboard'):
    require_admin_auth();
    $open = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status NOT IN ('Gesloten','Opgelost')")->fetchColumn();
    $total = (int)$pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn();
    $templatesCount = (int)$pdo->query("SELECT COUNT(*) FROM ticket_templates WHERE active=1")->fetchColumn();
    $lowDiskCount = count_low_disk_alerts();
    $pendingCount = count_pending_updates();
    $uniqueSoftware = count_unique_software();
    $complianceIssues = count_compliance_issues();
    $assetsCount = (int)$pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();
    $recent = decode_ticket_rows($pdo->query("SELECT * FROM tickets ORDER BY updated_at DESC LIMIT 10")->fetchAll());
?>
<div class="grid grid4">
    <div class="card"><div class="muted">Openstaande Tickets</div><div class="stat"><?=$open?></div></div>
    <div class="card"><div class="muted">Geregistreerde Assets</div><div class="stat"><?=$assetsCount?></div></div>
    <div class="card">
        <div class="muted">Compliance Issues</div>
        <div class="stat" style="color:<?=$complianceIssues > 0 ? 'var(--red)' : 'var(--green)'?>;"><?=$complianceIssues?></div>
        <?php if ($complianceIssues > 0): ?>
            <a href="index.php?view=compliance" class="badge red">Bekijk compliance</a>
        <?php else: ?>
            <span class="badge green">Alles compliant</span>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="muted">Schijfruimte Meldingen</div>
        <div class="stat" style="color:<?=$lowDiskCount > 0 ? 'var(--red)' : 'var(--green)'?>;"><?=$lowDiskCount?></div>
        <?php if ($lowDiskCount > 0): ?>
            <a href="index.php?view=alerts" class="badge red">Bekijk meldingen</a>
        <?php else: ?>
            <span class="badge green">Alles in orde</span>
        <?php endif; ?>
    </div>
</div>
<br>
<div class="grid grid4">
    <div class="card">
        <div class="muted">Pending Windows Updates</div>
        <div class="stat" style="color:<?=$pendingCount > 0 ? 'var(--yellow)' : 'var(--green)'?>;"><?=$pendingCount?></div>
        <?php if ($pendingCount > 0): ?>
            <a href="index.php?view=windows-updates" class="badge orange">Bekijk meldingen</a>
        <?php else: ?>
            <span class="badge green">Up-to-date</span>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="muted">Unieke software-items</div>
        <div class="stat"><?=$uniqueSoftware?></div>
        <a href="index.php?view=all-software" class="badge blue">Bekijk alle software</a>
    </div>
    <div class="card">
        <div class="muted">Actieve Aanvraag Templates</div>
        <div class="stat"><?=$templatesCount?></div>
    </div>
    <div class="card">
        <div class="muted">Totaal Verwerkte Tickets</div>
        <div class="stat"><?=$total?></div>
    </div>
</div>
<br>
<div class="card">
    <h2>Recente Tickets</h2>
    <table>
        <tr><th>Ticket</th><th>Onderwerp</th><th>Aanvrager</th><th>Categorie</th><th>Status</th><th>Prioriteit</th><th>Datum</th></tr>
        <?php foreach($recent as $rt): ?>
            <tr>
                <td><a href="index.php?view=ticket&id=<?=$rt['id']?>"><strong><?=e($rt['ticket_number'])?></strong></a></td>
                <td><?=e($rt['title'])?></td>
                <td><?=e($rt['requester_name'])?></td>
                <td><?=e($rt['category'])?></td>
                <td><span class="badge <?=in_array($rt['status'],['Opgelost','Gesloten'])?'green':'orange'?>"><?=e($rt['status'])?></span></td>
                <td><?=e($rt['priority'])?></td>
                <td><?=e($rt['updated_at'])?></td>
            </tr>
        <?php endforeach; if(!$recent): ?>
            <tr><td colspan="7" class="empty">Er zijn nog geen tickets aangemaakt.</td></tr>
        <?php endif;?>
    </table>
</div>

<?php
// VIEW: ALLE TICKETS BEHEREN (AFGESCHERMD)
elseif ($view === 'tickets'):
    require_admin_auth();

    $range = (string)($_GET['range'] ?? 'all');
    $allowedRanges = ['all','today','yesterday','week','month'];
    if (!in_array($range, $allowedRanges, true)) {
        $range = 'all';
    }

    $today      = new DateTimeImmutable('today');
    $tomorrow   = $today->modify('+1 day');
    $yesterday  = $today->modify('-1 day');
    $weekStart  = $today->modify('-6 days');
    $monthStart = $today->modify('first day of this month');

    $where  = '';
    $params = [];

    switch ($range) {
        case 'today':
            $where = "WHERE t.created_at >= :start AND t.created_at < :end";
            $params = [
                ':start' => $today->format('Y-m-d 00:00:00'),
                ':end'   => $tomorrow->format('Y-m-d 00:00:00'),
            ];
            break;
        case 'yesterday':
            $where = "WHERE t.created_at >= :start AND t.created_at < :end";
            $params = [
                ':start' => $yesterday->format('Y-m-d 00:00:00'),
                ':end'   => $today->format('Y-m-d 00:00:00'),
            ];
            break;
        case 'week':
            $where = "WHERE t.created_at >= :start";
            $params = [':start' => $weekStart->format('Y-m-d 00:00:00')];
            break;
        case 'month':
            $where = "WHERE t.created_at >= :start";
            $params = [':start' => $monthStart->format('Y-m-d 00:00:00')];
            break;
        case 'all':
        default:
            $where = '';
            break;
    }

    $sql = "SELECT t.* FROM tickets t $where ORDER BY t.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = decode_ticket_rows($stmt->fetchAll());

    $counts = ['all' => 0, 'today' => 0, 'yesterday' => 0, 'week' => 0, 'month' => 0];
    $counts['all'] = (int)$pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn();

    $cStmt = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE created_at >= ? AND created_at < ?");
    $cStmt->execute([$today->format('Y-m-d 00:00:00'), $tomorrow->format('Y-m-d 00:00:00')]);
    $counts['today'] = (int)$cStmt->fetchColumn();

    $cStmt->execute([$yesterday->format('Y-m-d 00:00:00'), $today->format('Y-m-d 00:00:00')]);
    $counts['yesterday'] = (int)$cStmt->fetchColumn();

    $cStmt2 = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE created_at >= ?");
    $cStmt2->execute([$weekStart->format('Y-m-d 00:00:00')]);
    $counts['week'] = (int)$cStmt2->fetchColumn();

    $cStmt2->execute([$monthStart->format('Y-m-d 00:00:00')]);
    $counts['month'] = (int)$cStmt2->fetchColumn();

    $rangeLabels = [
        'all'       => 'Alles',
        'today'     => 'Vandaag',
        'yesterday' => 'Gisteren',
        'week'      => 'Afgelopen week',
        'month'     => 'Deze maand',
    ];

    $rangeDescriptions = [
        'all'       => 'Alle tickets in de database',
        'today'     => 'Aangemaakt op ' . $today->format('d-m-Y'),
        'yesterday' => 'Aangemaakt op ' . $yesterday->format('d-m-Y'),
        'week'      => 'Aangemaakt vanaf ' . $weekStart->format('d-m-Y') . ' t/m ' . $today->format('d-m-Y'),
        'month'     => 'Aangemaakt vanaf ' . $monthStart->format('d-m-Y'),
    ];
?>
<div class="card">
    <h2>Alle Tickets</h2>
    <p class="muted">Filter op aanmaakdatum. De telling tussen haakjes is het aantal tickets in die periode.</p>

    <div class="filterbar">
        <?php foreach ($rangeLabels as $key => $label): ?>
            <a class="filter-btn <?= $range === $key ? 'active' : '' ?>"
               href="index.php?view=tickets&range=<?=e($key)?>">
                <?=e($label)?>
                <span class="count"><?= (int)$counts[$key] ?></span>
            </a>
        <?php endforeach; ?>
        <span class="range-summary"><?=e($rangeDescriptions[$range])?></span>
    </div>

    <table>
        <tr>
            <th>Ticket</th>
            <th>Onderwerp</th>
            <th>Aanvrager</th>
            <th>E-mail</th>
            <th>Status</th>
            <th>Aangemaakt</th>
            <th>Bijgewerkt</th>
            <th>Actie</th>
        </tr>
        <?php foreach($rows as $t): ?>
            <tr>
                <td><strong><?=e($t['ticket_number'])?></strong></td>
                <td>
                    <?=e($t['title'])?>
                    <div class="muted" style="font-size:12px;"><?=e($t['category'])?></div>
                </td>
                <td><?=e($t['requester_name'])?></td>
                <td><?=e($t['requester_email'])?></td>
                <td>
                    <span class="badge <?=in_array($t['status'],['Opgelost','Gesloten'],true)?'green':'blue'?>">
                        <?=e($t['status'])?>
                    </span>
                </td>
                <td><?=e($t['created_at'])?></td>
                <td><?=e($t['updated_at'])?></td>
                <td><a class="btn light" href="index.php?view=ticket&id=<?=$t['id']?>">Openen & Beantwoorden</a></td>
            </tr>
        <?php endforeach; if(!$rows): ?>
            <tr><td colspan="8" class="empty">Geen tickets gevonden in deze periode.</td></tr>
        <?php endif;?>
    </table>
</div>

<?php
// VIEW: TEMPLATES BEHEREN (AFGESCHERMD)
elseif ($view === 'templates'):
    require_admin_auth();
    $editId = (int)($_GET['edit'] ?? 0);
    $edit = null;
    if ($editId) {
        $s = $pdo->prepare("SELECT * FROM ticket_templates WHERE id=?");
        $s->execute([$editId]);
        $edit = $s->fetch();
    }
    $templates = $pdo->query("SELECT * FROM ticket_templates ORDER BY name ASC")->fetchAll();
?>
<div class="grid grid2">
    <div class="card">
        <div class="accentline"></div>
        <h2><?=$edit ? 'Sjabloon Bewerken' : 'Nieuw Aanvraag Sjabloon Toevoegen'?></h2>
        <form method="post">
            <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
            <input type="hidden" name="action" value="save_template">
            <input type="hidden" name="id" value="<?=e($edit['id'] ?? 0)?>">

            <div class="field">
                <label>Sjabloon / Aanvraag Naam</label>
                <input name="name" required value="<?=e($edit['name'] ?? '')?>">
            </div>
            <div class="field">
                <label>Categorie</label>
                <input name="category" value="<?=e($edit['category'] ?? 'Overige aanvraag')?>">
            </div>
            <div class="field">
                <label>Standaard Onderwerp</label>
                <input name="subject" value="<?=e($edit['subject'] ?? '')?>">
            </div>
            <div class="field">
                <label>Formulier / Template Tekst</label>
                <textarea name="body"><?=e($edit['body'] ?? '')?></textarea>
            </div>
            <label style="display:flex; gap:8px; align-items:center;">
                <input type="checkbox" name="active" value="1" <?=(!$edit || $edit['active']) ? 'checked' : ''?> style="width:auto;"> Actief
            </label>
            <br>
            <button class="btn orange">Sjabloon Opslaan</button>
        </form>
    </div>

    <div class="card">
        <h2>Beschikbare Sjablonen</h2>
        <table>
            <tr><th>Naam</th><th>Categorie</th><th>Status</th><th>Acties</th></tr>
            <?php foreach($templates as $tpl): ?>
                <tr>
                    <td><strong><?=e($tpl['name'])?></strong></td>
                    <td><?=e($tpl['category'])?></td>
                    <td><?=$tpl['active'] ? '<span class="badge green">Actief</span>' : '<span class="badge">Inactief</span>'?></td>
                    <td>
                        <div class="actions">
                            <a class="btn light" href="index.php?view=templates&edit=<?=$tpl['id']?>">Bewerken</a>
                            <form method="post" style="display:inline;" onsubmit="return confirmDelete(this, 'Weet u zeker dat u het sjabloon \'<?=e(addslashes($tpl['name']))?>\' wilt verwijderen? Dit kan niet ongedaan worden gemaakt.');">
                                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                                <input type="hidden" name="action" value="delete_template">
                                <input type="hidden" name="id" value="<?=$tpl['id']?>">
                                <button type="submit" class="btn red" style="padding:9px 13px; font-size:13px;">Verwijderen</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach;?>
        </table>
    </div>
</div>

<?php
// VIEW: STANDAARD REACTIES BEHEREN (AFGESCHERMD)
elseif ($view === 'reactions'):
    require_admin_auth();
    $editId = (int)($_GET['edit'] ?? 0);
    $edit = null;
    if ($editId) {
        $s = $pdo->prepare("SELECT * FROM ticket_reactions WHERE id=?");
        $s->execute([$editId]);
        $edit = $s->fetch();
    }
    $reactions = $pdo->query("SELECT * FROM ticket_reactions ORDER BY name ASC")->fetchAll();
?>
<div class="grid grid2">
    <div class="card">
        <div class="accentline"></div>
        <h2><?=$edit ? 'Reactie Bewerken' : 'Nieuwe Standaardreactie'?></h2>
        <form method="post">
            <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
            <input type="hidden" name="action" value="save_reaction">
            <input type="hidden" name="id" value="<?=e($edit['id'] ?? 0)?>">

            <div class="field">
                <label>Titel van reactie</label>
                <input name="name" required value="<?=e($edit['name'] ?? '')?>">
            </div>
            <div class="field">
                <label>Standaard Tekst</label>
                <textarea name="body" required><?=e($edit['body'] ?? '')?></textarea>
            </div>
            <button class="btn orange">Reactie Opslaan</button>
        </form>
    </div>

    <div class="card">
        <h2>Standaard Reacties</h2>
        <table>
            <tr><th>Naam</th><th>Inhoud</th><th>Acties</th></tr>
            <?php foreach($reactions as $rx): ?>
                <tr>
                    <td><strong><?=e($rx['name'])?></strong></td>
                    <td class="muted"><?=e(substr($rx['body'], 0, 80))?>...</td>
                    <td>
                        <div class="actions">
                            <a class="btn light" href="index.php?view=reactions&edit=<?=$rx['id']?>">Bewerken</a>
                            <form method="post" style="display:inline;" onsubmit="return confirmDelete(this, 'Weet u zeker dat u de reactie \'<?=e(addslashes($rx['name']))?>\' wilt verwijderen? Dit kan niet ongedaan worden gemaakt.');">
                                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                                <input type="hidden" name="action" value="delete_reaction">
                                <input type="hidden" name="id" value="<?=$rx['id']?>">
                                <button type="submit" class="btn red" style="padding:9px 13px; font-size:13px;">Verwijderen</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach;?>
        </table>
    </div>
</div>

<?php
// VIEW: ASSETS OVERZICHT (AFGESCHERMD)
elseif ($view === 'assets'):
    require_admin_auth();
    $assets = $pdo->query("
        SELECT a.*,
               (SELECT COUNT(*) FROM asset_software s WHERE s.asset_id = a.id) AS software_count,
               (SELECT COUNT(*) FROM asset_volumes  v WHERE v.asset_id = a.id) AS volume_count,
               (SELECT COUNT(*) FROM asset_volumes  v WHERE v.asset_id = a.id AND v.is_low = 1) AS low_disk_count,
               (SELECT COUNT(*) FROM asset_pending_updates u WHERE u.asset_id = a.id) AS update_count
        FROM assets a ORDER BY COALESCE(NULLIF(a.functional_name, ''), a.hostname) ASC
    ")->fetchAll();
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Software Asset Inventarisatie Agent</h2>
    <p class="muted">Rol <code>asset.ps1</code> uit op Windows-clients (bijv. via GPO of Intune) om hardware-, software-, update- en compliance-gegevens automatisch te registreren en up-to-date te houden. Zowel de <strong>functionele naam</strong> als de <strong>computernaam</strong> worden getoond en beheerd.</p>
    <a class="btn orange" href="index.php?view=agent-script">Download asset.ps1</a>
    <a class="btn dark" href="index.php?view=bulk-rename" style="margin-left:8px;">Bulk PC Herbenoemen</a>
    <p class="muted small" style="margin-top:10px;">Het script stuurt gegevens naar <code>index.php?view=agent-checkin</code> met een <code>X-Agent-Key</code> header. Stel de sleutel in via <code>security.agent_api_key</code> in <code>config.php</code> en gebruik dezelfde waarde in het script.</p>
</div>

<div class="card">
    <h2>IT Asset Inventaris</h2>
    <table>
        <tr>
            <th>Functionele Naam</th>
            <th>Computernaam</th>
            <th>Asset Tag</th>
            <th>Fabrikant / Model</th>
            <th>CPU</th>
            <th>Serienummer</th>
            <th>IP Adres</th>
            <th>Schijven</th>
            <th>Software</th>
            <th>Updates</th>
            <th>Laatst gezien</th>
            <th>Actie</th>
        </tr>
        <?php foreach($assets as $ast): ?>
            <tr>
                <td><strong><?=e($ast['functional_name'] ?: '-')?></strong></td>
                <td><?=e($ast['hostname'] ?: '-')?></td>
                <td><?=e($ast['asset_tag'])?></td>
                <td><?=e($ast['manufacturer'])?> <?=e($ast['model'])?></td>
                <td title="<?=e($ast['cpu'])?>">
                    <?=e(mb_strimwidth((string)$ast['cpu'], 0, 40, '...'))?>
                </td>
                <td><?=e($ast['serial_number'])?></td>
                <td><?=e($ast['ip_address'])?></td>
                <td>
                    <span class="badge <?=$ast['volume_count'] > 0 ? 'blue' : ''?>"><?=(int)$ast['volume_count']?> volumes</span>
                    <?php if ((int)$ast['low_disk_count'] > 0): ?>
                        <span class="badge red" title="Volume(s) met minder dan <?=LOW_DISK_THRESHOLD_GB?> GB vrij"><?=(int)$ast['low_disk_count']?> laag</span>
                    <?php endif; ?>
                </td>
                <td><span class="badge <?=$ast['software_count'] > 0 ? 'blue' : ''?>"><?=(int)$ast['software_count']?> items</span></td>
                <td>
                    <?php if ((int)$ast['update_count'] > 0): ?>
                        <span class="badge orange" title="Pending Windows Updates"><?=(int)$ast['update_count']?> pending</span>
                    <?php else: ?>
                        <span class="badge green">Up-to-date</span>
                    <?php endif; ?>
                </td>
                <td><?=e($ast['last_seen'] ?? '-')?></td>
                <td><a class="btn light" href="index.php?view=asset-software&id=<?=$ast['id']?>">Bekijk details</a></td>
            </tr>
        <?php endforeach; if(!$assets): ?>
            <tr><td colspan="12" class="empty">Nog geen assets geregistreerd. Rol het agent-script uit om te starten.</td></tr>
        <?php endif;?>
    </table>
</div>

<?php
// VIEW: BULK PC HERBENOEMEN (AFGESCHERMD)
elseif ($view === 'bulk-rename'):
    require_admin_auth();

    $search = trim((string)($_GET['q'] ?? ''));
    $where  = '';
    $params = [];
    if ($search !== '') {
        $where = "WHERE asset_tag LIKE :q1 OR hostname LIKE :q2 OR functional_name LIKE :q3";
        $params[':q1'] = '%' . $search . '%';
        $params[':q2'] = '%' . $search . '%';
        $params[':q3'] = '%' . $search . '%';
    }

    $stmt = $pdo->prepare("
        SELECT id, asset_tag, hostname, functional_name, manufacturer, model, ip_address, last_seen
        FROM assets
        $where
        ORDER BY COALESCE(NULLIF(functional_name, ''), hostname) ASC
    ");
    $stmt->execute($params);
    $assets = $stmt->fetchAll();

    $totalAssets = (int)$pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();
    $withFunctional = (int)$pdo->query("SELECT COUNT(*) FROM assets WHERE functional_name <> ''")->fetchColumn();
    $withoutFunctional = $totalAssets - $withFunctional;
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Bulk PC Herbenoemen</h2>
    <p class="muted">
        Pas hier in bulk de <strong>computernaam</strong> (hostname) en de <strong>functionele naam</strong> aan voor meerdere assets tegelijk.
        De computernaam wordt door de agent gebruikt om de machine te hernoemen; de functionele naam is een herkenbare naam voor beheerders.
        Laat een veld leeg om de bestaande waarde te behouden.
    </p>

    <div class="grid grid3" style="margin-top:14px;">
        <div class="card" style="box-shadow:none;">
            <div class="muted">Totaal assets</div>
            <div class="stat"><?=$totalAssets?></div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Met functionele naam</div>
            <div class="stat" style="color:var(--green);"><?=$withFunctional?></div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Zonder functionele naam</div>
            <div class="stat" style="color:var(--yellow);"><?=$withoutFunctional?></div>
        </div>
    </div>

    <div class="searchbar" style="margin-top:20px;">
        <form method="get" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
            <input type="hidden" name="view" value="bulk-rename">
            <input type="text" name="q" placeholder="Zoek op asset tag, computernaam of functionele naam..." value="<?=e($search)?>">
            <button class="btn blue">Zoeken</button>
            <?php if ($search !== ''): ?>
                <a class="btn light" href="index.php?view=bulk-rename">Wis filter</a>
            <?php endif; ?>
        </form>
    </div>

    <form method="post">
        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
        <input type="hidden" name="action" value="save_bulk_rename">

        <div class="bulk-row bulk-header">
            <div>Asset</div>
            <div>Functionele naam</div>
            <div>Computernaam (hostname)</div>
            <div>Info</div>
        </div>

        <?php foreach ($assets as $a): ?>
            <div class="bulk-row">
                <div>
                    <div class="bulk-label"><?=e($a['asset_tag'])?></div>
                    <div class="bulk-current">
                        <?=e($a['manufacturer'])?> <?=e($a['model'])?><br>
                        IP: <?=e($a['ip_address'] ?: '-')?><br>
                        Laatst: <?=e($a['last_seen'] ?? '-')?>
                    </div>
                </div>
                <div>
                    <label style="display:none;">Functionele naam</label>
                    <input type="text"
                           name="rename[<?=(int)$a['id']?>][functional_name]"
                           value="<?=e($a['functional_name'])?>"
                           placeholder="bijv. Balie-01"
                           maxlength="190">
                </div>
                <div>
                    <label style="display:none;">Computernaam</label>
                    <input type="text"
                           name="rename[<?=(int)$a['id']?>][hostname]"
                           value="<?=e($a['hostname'])?>"
                           placeholder="bijv. VBA-PC-001"
                           maxlength="190">
                </div>
                <div>
                    <a class="btn light" href="index.php?view=asset-software&id=<?=(int)$a['id']?>">Details</a>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!$assets): ?>
            <div class="empty">Geen assets gevonden.</div>
        <?php else: ?>
            <div style="margin-top:18px; display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <button class="btn orange" style="font-size:14px; padding:12px 20px;">Wijzigingen Opslaan</button>
                <span class="muted">Laat een veld leeg om de bestaande waarde te behouden.</span>
            </div>
        <?php endif; ?>
    </form>
</div>

<?php
// VIEW: ASSET DETAILS - VOLUMES + SOFTWARE + UPDATES (AFGESCHERMD)
elseif ($view === 'asset-software'):
    require_admin_auth();
    $assetId = (int)($_GET['id'] ?? 0);
    $s = $pdo->prepare("SELECT * FROM assets WHERE id=?");
    $s->execute([$assetId]);
    $asset = $s->fetch();
    $software = [];
    $volumes = [];
    $pendingUpdates = [];
    if ($asset) {
        $ss = $pdo->prepare("SELECT * FROM asset_software WHERE asset_id=? ORDER BY name ASC");
        $ss->execute([$assetId]);
        $software = $ss->fetchAll();

        $vs = $pdo->prepare("SELECT * FROM asset_volumes WHERE asset_id=? ORDER BY drive_letter ASC");
        $vs->execute([$assetId]);
        $volumes = $vs->fetchAll();

        $us = $pdo->prepare("SELECT * FROM asset_pending_updates WHERE asset_id=? ORDER BY severity DESC, title ASC");
        $us->execute([$assetId]);
        $pendingUpdates = $us->fetchAll();
    }

    $volCount    = count($volumes);
    $lowVolCount = 0;
    $totalSizeGb = 0.0;
    $totalFreeGb = 0.0;
    foreach ($volumes as $v) {
        if ((int)$v['is_low'] === 1) $lowVolCount++;
        $totalSizeGb += (float)$v['size_gb'];
        $totalFreeGb += (float)$v['free_gb'];
    }
    $totalFreePct = $totalSizeGb > 0 ? round(($totalFreeGb / $totalSizeGb) * 100, 1) : 0;
    $updateCount = count($pendingUpdates);
?>
<div class="card">
    <div class="accentline"></div>
    <?php if (!$asset): ?>
        <h2>Asset niet gevonden</h2>
        <p class="muted">Dit asset bestaat niet (meer).</p>
    <?php else: ?>
        <h2>Asset Details - <?=e(asset_display($asset))?></h2>
        <p class="muted">
            <strong><?=e($asset['asset_tag'])?></strong>
            &middot; Functionele naam: <strong><?=e($asset['functional_name'] ?: '-')?></strong>
            &middot; Computernaam: <strong><?=e($asset['hostname'] ?: '-')?></strong>
            &middot; <?=e($asset['manufacturer'])?> <?=e($asset['model'])?>
            &middot; Laatst gezien: <?=e($asset['last_seen'] ?? '-')?>
        </p>
    <?php endif; ?>
    <a class="btn light" href="index.php?view=assets" style="margin-bottom:14px; display:inline-block;">&larr; Terug naar Assets</a>

    <?php if ($asset): ?>
        <h3 style="margin-top:10px;">Asset Status</h3>
        <div class="grid grid4" style="margin-bottom:24px;">
            <div class="card" style="box-shadow:none;">
                <div class="muted">Schijfvolumes</div>
                <div class="stat"><?=$volCount?></div>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Volumes met lage ruimte</div>
                <div class="stat" style="color:<?=$lowVolCount > 0 ? 'var(--red)' : 'var(--green)'?>;"><?=$lowVolCount?></div>
                <?php if ($lowVolCount > 0): ?>
                    <span class="badge red">Actie vereist: &lt; <?=LOW_DISK_THRESHOLD_GB?> GB vrij</span>
                <?php else: ?>
                    <span class="badge green">Voldoende ruimte</span>
                <?php endif; ?>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Pending Windows Updates</div>
                <div class="stat" style="color:<?=$updateCount > 0 ? 'var(--yellow)' : 'var(--green)'?>;"><?=$updateCount?></div>
                <?php if ($updateCount > 0): ?>
                    <span class="badge orange">Actie vereist</span>
                <?php else: ?>
                    <span class="badge green">Up-to-date</span>
                <?php endif; ?>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Totale vrije ruimte</div>
                <div class="stat"><?=e(number_format($totalFreeGb, 1, ',', '.'))?> GB</div>
                <div class="muted"><?=e(number_format($totalFreePct, 1, ',', '.'))?>% van <?=e(number_format($totalSizeGb, 1, ',', '.'))?> GB</div>
            </div>
        </div>

        <?php if ($lowVolCount > 0 || $updateCount > 0): ?>
            <div class="flash error" style="margin-bottom:20px;">
                <strong>Waarschuwing:</strong>
                <?php if ($lowVolCount > 0): ?>
                    <?=$lowVolCount?> volume(s) met minder dan <?=LOW_DISK_THRESHOLD_GB?> GB vrije ruimte.
                <?php endif; ?>
                <?php if ($lowVolCount > 0 && $updateCount > 0): ?> &middot; <?php endif; ?>
                <?php if ($updateCount > 0): ?>
                    <?=$updateCount?> pending Windows Update(s).
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <h3>Pending Windows Updates</h3>
        <?php if (!$pendingUpdates): ?>
            <p class="muted">Geen pending Windows Updates gevonden. Dit systeem is up-to-date.</p>
        <?php else: ?>
            <table style="margin-bottom:24px;">
                <tr><th>Titel</th><th>KB</th><th>Ernst</th><th>Grootte</th><th>Categorie</th><th>Bron</th></tr>
                <?php foreach ($pendingUpdates as $u): ?>
                    <tr>
                        <td><strong><?=e($u['title'])?></strong></td>
                        <td><?=e($u['kb'] ?: '-')?></td>
                        <td>
                            <?php if ($u['severity']): ?>
                                <span class="badge <?=stripos($u['severity'], 'Critical') !== false ? 'red' : 'orange'?>">
                                    <?=e($u['severity'])?>
                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?= $u['size_mb'] > 0 ? e(number_format((float)$u['size_mb'], 2, ',', '.')) . ' MB' : '-' ?></td>
                        <td><?=e($u['category'] ?: '-')?></td>
                        <td class="muted"><?=e($u['source'] ?: '-')?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <h3>Schijfvolumes</h3>
        <?php if (!$volumes): ?>
            <p class="muted">Geen volumegegevens ontvangen.</p>
        <?php else: ?>
            <table style="margin-bottom:24px;">
                <tr><th>Station</th><th>Label</th><th>Bestandssysteem</th><th>Grootte</th><th>Vrij</th><th>% vrij</th><th>Status</th></tr>
                <?php foreach ($volumes as $v): ?>
                    <tr>
                        <td><strong><?=e($v['drive_letter'])?></strong></td>
                        <td><?=e($v['label'] ?: '-')?></td>
                        <td><?=e($v['file_system'] ?: '-')?></td>
                        <td><?=e(number_format((float)$v['size_gb'], 2, ',', '.'))?> GB</td>
                        <td><?=e(number_format((float)$v['free_gb'], 2, ',', '.'))?> GB</td>
                        <td><?=e(number_format((float)$v['free_percent'], 1, ',', '.'))?>%</td>
                        <td>
                            <?php if ((int)$v['is_low'] === 1): ?>
                                <span class="badge red">Minder dan <?=LOW_DISK_THRESHOLD_GB?> GB vrij</span>
                            <?php else: ?>
                                <span class="badge green">OK</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <h3>Geinstalleerde Software</h3>
        <table>
            <tr><th>Naam</th><th>Versie</th><th>Uitgever</th><th>Installatiedatum</th></tr>
            <?php foreach($software as $sw): ?>
                <tr>
                    <td><strong><?=e($sw['name'])?></strong></td>
                    <td><?=e($sw['version'])?></td>
                    <td><?=e($sw['publisher'])?></td>
                    <td><?=e($sw['install_date'])?></td>
                </tr>
            <?php endforeach; if(!$software): ?>
                <tr><td colspan="4" class="empty">Geen software geregistreerd voor dit asset.</td></tr>
            <?php endif;?>
        </table>
    <?php endif; ?>
</div>

<?php
// VIEW: SCHIJFRUIMTE MELDINGEN (AFGESCHERMD)
elseif ($view === 'alerts'):
    require_admin_auth();

    $lowVolumes = $pdo->query("
        SELECT v.*, a.asset_tag, a.hostname, a.functional_name, a.manufacturer, a.model, a.last_seen
        FROM asset_volumes v
        JOIN assets a ON a.id = v.asset_id
        WHERE v.is_low = 1
        ORDER BY v.free_gb ASC, a.hostname ASC
    ")->fetchAll();

    $byAsset = [];
    foreach ($lowVolumes as $v) {
        $key = (int)$v['asset_id'];
        if (!isset($byAsset[$key])) {
            $byAsset[$key] = [
                'asset_tag'       => $v['asset_tag'],
                'hostname'        => $v['hostname'],
                'functional_name' => $v['functional_name'] ?? '',
                'manufacturer'    => $v['manufacturer'],
                'model'           => $v['model'],
                'last_seen'       => $v['last_seen'],
                'asset_id'        => $key,
                'volumes'         => [],
            ];
        }
        $byAsset[$key]['volumes'][] = $v;
    }

    $totalAlerts = count($lowVolumes);
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Schijfruimte Meldingen</h2>
    <p class="muted">Overzicht van alle volumes met minder dan <strong><?=LOW_DISK_THRESHOLD_GB?> GB</strong> vrije ruimte, op basis van de laatste agent check-ins.</p>

    <?php if ($totalAlerts === 0): ?>
        <div class="flash success">Geen schijfruimte meldingen. Alle volumes hebben voldoende vrije ruimte.</div>
    <?php else: ?>
        <div class="grid grid3" style="margin-top:14px;">
            <div class="card" style="box-shadow:none;">
                <div class="muted">Totaal volumes met lage ruimte</div>
                <div class="stat" style="color:var(--red);"><?=$totalAlerts?></div>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Betrokken machines</div>
                <div class="stat"><?=count($byAsset)?></div>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Drempelwaarde</div>
                <div class="stat">&lt; <?=LOW_DISK_THRESHOLD_GB?> GB</div>
                <div class="muted">vrije ruimte per volume</div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($totalAlerts > 0): ?>
    <?php foreach ($byAsset as $asset): ?>
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
            <div>
                <h2 style="margin-bottom:4px;">&#9888; <?=e(asset_display($asset))?></h2>
                <p class="muted" style="margin:0;">
                    <strong><?=e($asset['asset_tag'])?></strong>
                    &middot; Functionele naam: <strong><?=e($asset['functional_name'] ?: '-')?></strong>
                    &middot; Computernaam: <strong><?=e($asset['hostname'] ?: '-')?></strong>
                    &middot; <?=e($asset['manufacturer'])?> <?=e($asset['model'])?>
                    &middot; Laatst gezien: <?=e($asset['last_seen'] ?? '-')?>
                </p>
            </div>
            <a class="btn light" href="index.php?view=asset-software&id=<?=(int)$asset['asset_id']?>">Bekijk asset details</a>
        </div>

        <table style="margin-top:16px;">
            <tr>
                <th>Station</th><th>Label</th><th>Bestandssysteem</th>
                <th>Grootte</th><th>Vrij</th><th>% vrij</th><th>Status</th>
            </tr>
            <?php foreach ($asset['volumes'] as $v): ?>
                <tr>
                    <td><strong><?=e($v['drive_letter'])?></strong></td>
                    <td><?=e($v['label'] ?: '-')?></td>
                    <td><?=e($v['file_system'] ?: '-')?></td>
                    <td><?=e(number_format((float)$v['size_gb'], 2, ',', '.'))?> GB</td>
                    <td style="color:var(--red); font-weight:700;"><?=e(number_format((float)$v['free_gb'], 2, ',', '.'))?> GB</td>
                    <td><?=e(number_format((float)$v['free_percent'], 1, ',', '.'))?>%</td>
                    <td><span class="badge red">Minder dan <?=LOW_DISK_THRESHOLD_GB?> GB vrij</span></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php
// VIEW: WINDOWS UPDATE MELDINGEN (AFGESCHERMD)
elseif ($view === 'windows-updates'):
    require_admin_auth();

    $pendingByAsset = $pdo->query("
        SELECT a.id AS asset_id, a.asset_tag, a.hostname, a.functional_name, a.manufacturer, a.model, a.last_seen,
               COUNT(u.id) AS update_count
        FROM assets a
        JOIN asset_pending_updates u ON u.asset_id = a.id
        GROUP BY a.id, a.asset_tag, a.hostname, a.functional_name, a.manufacturer, a.model, a.last_seen
        ORDER BY update_count DESC, a.hostname ASC
    ")->fetchAll();

    $pendingDetails = [];
    if (!empty($pendingByAsset)) {
        $ids = array_map(fn($r) => (int)$r['asset_id'], $pendingByAsset);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT * FROM asset_pending_updates WHERE asset_id IN ($placeholders) ORDER BY asset_id ASC, severity DESC, title ASC");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $u) {
            $pendingDetails[(int)$u['asset_id']][] = $u;
        }
    }

    $totalUpdates = 0;
    foreach ($pendingByAsset as $pa) {
        $totalUpdates += (int)$pa['update_count'];
    }
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Windows Update Meldingen</h2>
    <p class="muted">Overzicht van alle machines met nog niet geinstalleerde Windows Updates, op basis van de laatste agent check-ins.</p>

    <?php if ($totalUpdates === 0): ?>
        <div class="flash success">Geen pending Windows Updates. Alle machines zijn up-to-date.</div>
    <?php else: ?>
        <div class="grid grid3" style="margin-top:14px;">
            <div class="card" style="box-shadow:none;">
                <div class="muted">Totaal pending updates</div>
                <div class="stat" style="color:var(--yellow);"><?=$totalUpdates?></div>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Betrokken machines</div>
                <div class="stat"><?=count($pendingByAsset)?></div>
            </div>
            <div class="card" style="box-shadow:none;">
                <div class="muted">Gemiddeld per machine</div>
                <div class="stat"><?=count($pendingByAsset) > 0 ? e(number_format($totalUpdates / count($pendingByAsset), 1, ',', '.')) : '0'?></div>
                <div class="muted">updates per machine</div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($totalUpdates > 0): ?>
    <?php foreach ($pendingByAsset as $pa): ?>
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
            <div>
                <h2 style="margin-bottom:4px;">
                    &#9888; <?=e(asset_display($pa))?>
                    <span class="badge orange" style="margin-left:8px;"><?=(int)$pa['update_count']?> update(s)</span>
                </h2>
                <p class="muted" style="margin:0;">
                    <strong><?=e($pa['asset_tag'])?></strong>
                    &middot; Functionele naam: <strong><?=e($pa['functional_name'] ?: '-')?></strong>
                    &middot; Computernaam: <strong><?=e($pa['hostname'] ?: '-')?></strong>
                    &middot; <?=e($pa['manufacturer'])?> <?=e($pa['model'])?>
                    &middot; Laatst gezien: <?=e($pa['last_seen'] ?? '-')?>
                </p>
            </div>
            <a class="btn light" href="index.php?view=asset-software&id=<?=(int)$pa['asset_id']?>">Bekijk asset details</a>
        </div>

        <?php $details = $pendingDetails[(int)$pa['asset_id']] ?? []; ?>
        <?php if ($details): ?>
            <table style="margin-top:16px;">
                <tr><th>Titel</th><th>KB</th><th>Ernst</th><th>Grootte</th><th>Categorie</th><th>Bron</th></tr>
                <?php foreach ($details as $u): ?>
                    <tr>
                        <td><?=e($u['title'])?></td>
                        <td><?=e($u['kb'] ?: '-')?></td>
                        <td>
                            <?php if ($u['severity']): ?>
                                <span class="badge <?=stripos($u['severity'], 'Critical') !== false ? 'red' : 'orange'?>">
                                    <?=e($u['severity'])?>
                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?= $u['size_mb'] > 0 ? e(number_format((float)$u['size_mb'], 2, ',', '.')) . ' MB' : '-' ?></td>
                        <td><?=e($u['category'] ?: '-')?></td>
                        <td class="muted"><?=e($u['source'] ?: '-')?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php
// VIEW: ALLE SOFTWARE OVER ALLE CLIENTS (AFGESCHERMD)
elseif ($view === 'all-software'):
    require_admin_auth();

    $search = trim((string)($_GET['q'] ?? ''));
    $sort   = (string)($_GET['sort'] ?? 'clients_desc');
    $allowedSorts = ['clients_desc', 'clients_asc', 'name_asc', 'name_desc', 'publisher_asc'];
    if (!in_array($sort, $allowedSorts, true)) {
        $sort = 'clients_desc';
    }

    $where = '';
    $params = [];
    if ($search !== '') {
        $where = "WHERE s.name LIKE :q1 OR s.publisher LIKE :q2";
        $params[':q1'] = '%' . $search . '%';
        $params[':q2'] = '%' . $search . '%';
    }

    $orderSql = match ($sort) {
        'clients_asc'   => 'client_count ASC, name ASC',
        'name_asc'      => 'name ASC, version ASC',
        'name_desc'     => 'name DESC, version ASC',
        'publisher_asc' => 'publisher ASC, name ASC',
        default         => 'client_count DESC, name ASC',
    };

    $sql = "
        SELECT
            s.name,
            s.version,
            MAX(s.publisher) AS publisher,
            COUNT(DISTINCT s.asset_id) AS client_count,
            GROUP_CONCAT(DISTINCT a.hostname SEPARATOR ', ') AS hosts
        FROM asset_software s
        JOIN assets a ON a.id = s.asset_id
        $where
        GROUP BY s.name, s.version
        ORDER BY $orderSql
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $softwareList = $stmt->fetchAll();

    $totalUnique = count($softwareList);
    $totalInstalls = 0;
    foreach ($softwareList as $sw) {
        $totalInstalls += (int)$sw['client_count'];
    }
    $totalClients = (int)$pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();

    $sortLabels = [
        'clients_desc'  => 'Aantal clients (hoog-laag)',
        'clients_asc'   => 'Aantal clients (laag-hoog)',
        'name_asc'      => 'Naam (A-Z)',
        'name_desc'     => 'Naam (Z-A)',
        'publisher_asc' => 'Uitgever (A-Z)',
    ];
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Alle Software (alle clients)</h2>
    <p class="muted">Overzicht van alle unieke software-items over alle geregistreerde clients, gegroepeerd op naam en versie. Klik op een item om de clients te zien die het hebben.</p>

    <div class="grid grid3" style="margin-top:14px;">
        <div class="card" style="box-shadow:none;">
            <div class="muted">Unieke software-items</div>
            <div class="stat"><?=$totalUnique?></div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Totaal installaties</div>
            <div class="stat"><?=$totalInstalls?></div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Geregistreerde clients</div>
            <div class="stat"><?=$totalClients?></div>
        </div>
    </div>
</div>

<div class="card">
    <form method="get" class="searchbar">
        <input type="hidden" name="view" value="all-software">
        <input type="text" name="q" placeholder="Zoek op naam of uitgever..." value="<?=e($search)?>">
        <select name="sort" onchange="this.form.submit()" style="max-width:260px;">
            <?php foreach ($sortLabels as $key => $label): ?>
                <option value="<?=e($key)?>" <?=$sort === $key ? 'selected' : ''?>><?=e($label)?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn blue">Zoeken</button>
        <?php if ($search !== ''): ?>
            <a class="btn light" href="index.php?view=all-software">Wis filter</a>
        <?php endif; ?>
    </form>

    <table>
        <tr>
            <th>Software</th>
            <th>Versie</th>
            <th>Uitgever</th>
            <th>Aantal clients</th>
            <th>Actie</th>
        </tr>
        <?php foreach ($softwareList as $sw): ?>
            <tr>
                <td><strong><?=e($sw['name'])?></strong></td>
                <td><?=e($sw['version'] ?: '-')?></td>
                <td><?=e($sw['publisher'] ?: '-')?></td>
                <td>
                    <span class="badge <?=(int)$sw['client_count'] > 1 ? 'blue' : ''?>">
                        <?=(int)$sw['client_count']?> client(s)
                    </span>
                </td>
                <td>
                    <a class="btn light"
                       href="index.php?view=software-clients&name=<?=urlencode((string)$sw['name'])?>&version=<?=urlencode((string)$sw['version'])?>">
                        Bekijk clients
                    </a>
                </td>
            </tr>
        <?php endforeach; if(!$softwareList): ?>
            <tr><td colspan="5" class="empty">
                <?php if ($search !== ''): ?>
                    Geen software gevonden voor "<?=e($search)?>".
                <?php else: ?>
                    Nog geen software geregistreerd. Rol het agent-script uit om te starten.
                <?php endif; ?>
            </td></tr>
        <?php endif; ?>
    </table>
</div>

<?php
// VIEW: CLIENTS MET SPECIFIEKE SOFTWARE (AFGESCHERMD)
elseif ($view === 'software-clients'):
    require_admin_auth();

    $name    = trim((string)($_GET['name'] ?? ''));
    $version = trim((string)($_GET['version'] ?? ''));

    if ($name === '') {
        echo '<div class="card"><h2>Ongeldige aanvraag</h2><p class="muted">Geen softwarenaam opgegeven.</p><a class="btn light" href="index.php?view=all-software">Terug naar alle software</a></div>';
    } else {
        $stmt = $pdo->prepare("
            SELECT s.*, a.id AS asset_id, a.asset_tag, a.hostname, a.functional_name, a.manufacturer, a.model, a.last_seen, a.ip_address
            FROM asset_software s
            JOIN assets a ON a.id = s.asset_id
            WHERE s.name = ? AND s.version = ?
            ORDER BY a.hostname ASC
        ");
        $stmt->execute([$name, $version]);
        $clients = $stmt->fetchAll();
        $clientCount = count($clients);
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Clients met: <?=e($name)?></h2>
    <p class="muted">
        Versie: <strong><?=e($version ?: '-')?></strong>
        &middot; <strong><?=$clientCount?></strong> client(s) gevonden
    </p>
    <a class="btn light" href="index.php?view=all-software" style="margin-bottom:14px; display:inline-block;">&larr; Terug naar alle software</a>

    <?php if ($clientCount === 0): ?>
        <div class="flash error">Geen clients gevonden met deze software.</div>
    <?php else: ?>
        <table>
            <tr>
                <th>Functionele Naam</th>
                <th>Computernaam</th>
                <th>Asset Tag</th>
                <th>Fabrikant / Model</th>
                <th>IP Adres</th>
                <th>Installatiedatum</th>
                <th>Uitgever</th>
                <th>Laatst gezien</th>
                <th>Actie</th>
            </tr>
            <?php foreach ($clients as $c): ?>
                <tr>
                    <td><strong><?=e($c['functional_name'] ?: '-')?></strong></td>
                    <td><?=e($c['hostname'] ?: '-')?></td>
                    <td><?=e($c['asset_tag'])?></td>
                    <td><?=e($c['manufacturer'])?> <?=e($c['model'])?></td>
                    <td><?=e($c['ip_address'] ?: '-')?></td>
                    <td><?=e($c['install_date'] ?: '-')?></td>
                    <td><?=e($c['publisher'] ?: '-')?></td>
                    <td><?=e($c['last_seen'] ?? '-')?></td>
                    <td><a class="btn light" href="index.php?view=asset-software&id=<?=(int)$c['asset_id']?>">Bekijk asset</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>
<?php
    }
?>

<?php
// ============================================================
// VIEW - COMPLIANCE (GDPR/AVG/BIO) OVERZICHT
// ============================================================
elseif ($view === 'compliance'):
    require_admin_auth();

    $cfg = $CONFIG['compliance'] ?? [];

    $rows = $pdo->query("
        SELECT a.id AS asset_id, a.asset_tag, a.hostname, a.functional_name, a.manufacturer, a.model,
               a.ip_address, a.last_seen,
               c.*
        FROM assets a
        LEFT JOIN asset_compliance c ON c.asset_id = a.id
        ORDER BY COALESCE(NULLIF(a.functional_name, ''), a.hostname) ASC
    ")->fetchAll();

    $results = [];
    $statusCounts = ['ok' => 0, 'warn' => 0, 'fail' => 0, 'none' => 0];
    foreach ($rows as $r) {
        if ($r['id'] === null && empty($r['bitlocker_system_protection']) && (int)($r['local_admins_count'] ?? 0) === 0 && empty($r['last_update_date'])) {
            $status = 'none';
            $issues = ['Nog geen compliance-data ontvangen van deze client'];
        } else {
            $res = evaluate_compliance($r, $r, $cfg);
            $status = $res['status'];
            $issues = $res['issues'];
        }
        $statusCounts[$status]++;
        $results[] = [
            'asset'  => $r,
            'status' => $status,
            'issues' => $issues,
        ];
    }

    $statChecks = [
        'bitlocker'      => 0,
        'screen_lock'    => 0,
        'local_admins'   => 0,
        'guest'          => 0,
        'password_len'   => 0,
        'antivirus'      => 0,
        'realtime'       => 0,
        'latest_update'  => 0,
        'pending_reboot' => 0,
        'firewall'       => 0,
        'complexity'     => 0,
        'daily_admin'    => 0,
    ];
    $totalWithData = 0;
    foreach ($results as $res) {
        if ($res['status'] === 'none') continue;
        $totalWithData++;
        $c = $res['asset'];

        if (empty($cfg['require_bitlocker_system']) || in_array(strtolower(trim((string)$c['bitlocker_system_protection'])), ['on','fullyencrypted','encrypted','1'], true)) {
            $statChecks['bitlocker']++;
        }
        $maxLock = (int)($cfg['max_screen_lock_minutes'] ?? 10);
        $lock = (int)($c['screen_lock_timeout_minutes'] ?? 0);
        $lockSec = (int)($c['screen_lock_timeout_seconds'] ?? 0);
        if ($maxLock === 0
            || ($lockSec > 0 && $lockSec <= $maxLock * 60)
            || ($lockSec === 0 && $lock > 0 && $lock <= $maxLock)) {
            $statChecks['screen_lock']++;
        }
        $maxAdmins = (int)($cfg['max_local_admins'] ?? 2);
        if ($maxAdmins === 0 || (int)($c['local_admins_count'] ?? 0) <= $maxAdmins) {
            $statChecks['local_admins']++;
        }
        if (empty($cfg['require_guest_disabled']) || (int)($c['guest_account_enabled'] ?? 0) === 0) {
            $statChecks['guest']++;
        }
        $minPw = (int)($cfg['min_password_length'] ?? 12);
        if ($minPw === 0 || (int)($c['min_password_length'] ?? 0) >= $minPw) {
            $statChecks['password_len']++;
        }
        if ((int)($c['antivirus_enabled'] ?? 0) === 1) {
            $statChecks['antivirus']++;
        }
        if (empty($cfg['require_realtime_protection']) || (int)($c['realtime_protection_enabled'] ?? 0) === 1) {
            $statChecks['realtime']++;
        }
        $maxDays = (int)($cfg['max_days_since_last_update'] ?? 30);
        if ($maxDays === 0) {
            $statChecks['latest_update']++;
        } else {
            $d = trim((string)($c['last_update_date'] ?? ''));
            if ($d !== '' && strtotime($d) !== false) {
                $days = (int)floor((time() - strtotime($d)) / 86400);
                if ($days <= $maxDays) $statChecks['latest_update']++;
            }
        }
        if (empty($cfg['forbid_pending_reboot']) || (int)($c['pending_reboot'] ?? 0) === 0) {
            $statChecks['pending_reboot']++;
        }
        if (empty($cfg['require_firewall_all_profiles']) ||
            ((int)($c['firewall_domain'] ?? 0) === 1 && (int)($c['firewall_private'] ?? 0) === 1 && (int)($c['firewall_public'] ?? 0) === 1)) {
            $statChecks['firewall']++;
        }
        if (empty($cfg['require_password_complexity']) || (int)($c['password_complexity'] ?? 0) === 1) {
            $statChecks['complexity']++;
        }
        if (empty($cfg['forbid_daily_user_admin']) || (int)($c['daily_user_is_admin'] ?? 0) === 0) {
            $statChecks['daily_admin']++;
        }
    }

    $pct = fn(int $n): string => $totalWithData > 0 ? number_format(($n / $totalWithData) * 100, 1, ',', '.') . '%' : '0%';
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Compliance (GDPR/AVG/BIO)</h2>
    <p class="muted">
        Baseline-controle van alle geregistreerde Windows-clients op basis van de laatste agent check-in.
        Drempelwaarden zijn configureerbaar via <code>config.php &rarr; compliance</code>.
    </p>

    <div class="grid grid4" style="margin-top:14px;">
        <div class="card" style="box-shadow:none;">
            <div class="muted">Totaal clients</div>
            <div class="stat"><?=count($results)?></div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Compliant (OK)</div>
            <div class="stat" style="color:var(--green);"><?=$statusCounts['ok']?></div>
            <div class="muted"><?=$pct($statusCounts['ok'])?> van totaal</div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Waarschuwingen</div>
            <div class="stat" style="color:var(--yellow);"><?=$statusCounts['warn']?></div>
            <div class="muted"><?=$pct($statusCounts['warn'])?> van totaal</div>
        </div>
        <div class="card" style="box-shadow:none;">
            <div class="muted">Kritiek / Fail</div>
            <div class="stat" style="color:var(--red);"><?=$statusCounts['fail']?></div>
            <div class="muted"><?=$pct($statusCounts['fail'])?> van totaal</div>
        </div>
    </div>

    <h3 style="margin-top:24px;">Baseline Checks (aantal clients dat voldoet)</h3>
    <div class="compliance-grid">
        <?php
        $checkLabels = [
            'bitlocker'      => 'BitLocker systeemschijf versleuteld',
            'screen_lock'    => 'Automatische schermvergrendeling actief',
            'local_admins'   => 'Aantal leden lokale Administrators binnen limiet',
            'daily_admin'    => 'Dagelijkse gebruiker GEEN lokale admin',
            'guest'          => 'Gastaccount uitgeschakeld',
            'password_len'   => 'Minimale wachtwoordlengte voldoet',
            'complexity'     => 'Wachtwoordcomplexiteit vereist',
            'antivirus'      => 'Antivirus ingeschakeld',
            'realtime'       => 'Real-time protection ingeschakeld',
            'latest_update'  => 'Recente Windows update geinstalleerd',
            'pending_reboot' => 'Openstaande reboot na update',
            'firewall'       => 'Windows Firewall alle profielen aan',
        ];
        foreach ($checkLabels as $key => $label):
            $ok = $statChecks[$key];
            $isOk = $totalWithData > 0 && $ok === $totalWithData;
            $isBad = $totalWithData > 0 && $ok < $totalWithData;
        ?>
            <div class="compliance-item <?= $isOk ? 'ok' : ($isBad ? 'fail' : '') ?>">
                <div class="ci-label"><?=e($label)?></div>
                <div class="ci-value"><?=$ok?> / <?=$totalWithData?> (<?=$pct($ok)?>)</div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <h2>Compliance per Asset</h2>
    <p class="muted">Klik op een asset om de volledige compliance-details te bekijken.</p>
    <table>
        <tr>
            <th>Functionele Naam</th>
            <th>Computernaam</th>
            <th>Asset Tag</th>
            <th>Fabrikant / Model</th>
            <th>IP Adres</th>
            <th>Status</th>
            <th>Aantal issues</th>
            <th>Agent admin?</th>
            <th>Laatst gezien</th>
            <th>Actie</th>
        </tr>
        <?php foreach ($results as $res):
            $a = $res['asset'];
            $badgeClass = match ($res['status']) {
                'ok'   => 'ok',
                'warn' => 'warn',
                'fail' => 'fail',
                default => 'none',
            };
            $badgeLabel = match ($res['status']) {
                'ok'   => 'Compliant',
                'warn' => 'Waarschuwing',
                'fail' => 'Kritiek',
                default => 'Geen data',
            };
            $isAdmin = (int)($a['agent_is_admin'] ?? 0) === 1;
        ?>
            <tr>
                <td><strong><?=e($a['functional_name'] ?: '-')?></strong></td>
                <td><?=e($a['hostname'] ?: '-')?></td>
                <td><?=e($a['asset_tag'])?></td>
                <td><?=e($a['manufacturer'])?> <?=e($a['model'])?></td>
                <td><?=e($a['ip_address'] ?: '-')?></td>
                <td><span class="compliance-badge <?=$badgeClass?>"><?=$badgeLabel?></span></td>
                <td>
                    <?php if (count($res['issues']) > 0): ?>
                        <span class="badge red"><?=count($res['issues'])?></span>
                    <?php else: ?>
                        <span class="badge green">0</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($isAdmin): ?>
                        <span class="badge green">Ja</span>
                    <?php else: ?>
                        <span class="badge orange">Nee</span>
                    <?php endif; ?>
                </td>
                <td><?=e($a['last_seen'] ?? '-')?></td>
                <td>
                    <a class="btn light" href="index.php?view=compliance-asset&id=<?=(int)$a['asset_id']?>">Bekijk details</a>
                </td>
            </tr>
        <?php endforeach; if(!$results): ?>
            <tr><td colspan="10" class="empty">Nog geen assets geregistreerd. Rol het agent-script uit om te starten.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php
// ============================================================
// VIEW - COMPLIANCE DETAILS PER ASSET
// ============================================================
elseif ($view === 'compliance-asset'):
    require_admin_auth();

    $cfg = $CONFIG['compliance'] ?? [];
    $assetId = (int)($_GET['id'] ?? 0);

    $s = $pdo->prepare("
        SELECT a.*, c.*, c.id AS compliance_id
        FROM assets a
        LEFT JOIN asset_compliance c ON c.asset_id = a.id
        WHERE a.id = ?
    ");
    $s->execute([$assetId]);
    $row = $s->fetch();

    if (!$row) {
        echo '<div class="card"><h2>Asset niet gevonden</h2><p class="muted">Dit asset bestaat niet (meer).</p><a class="btn light" href="index.php?view=compliance">Terug naar compliance</a></div>';
    } else {
        $res = evaluate_compliance($row, $row, $cfg);
        $status = $res['status'];
        $issues = $res['issues'];

        $yesno = fn($v): string => ((int)$v === 1) ? 'Ja' : 'Nee';

        $bitlockerValue = trim((string)($row['bitlocker_system_protection'] ?? ''));
        $bitlockerLower = strtolower($bitlockerValue);
        $bitlockerOk    = in_array($bitlockerLower, ['on','fullyencrypted','encrypted','1'], true);
        $bitlockerUnknown = !$bitlockerOk && !in_array($bitlockerLower, ['off','0','fullydecrypted','decrypted','unencrypted'], true);

        $maxLock = (int)($cfg['max_screen_lock_minutes'] ?? 10);
        $lock    = (int)($row['screen_lock_timeout_minutes'] ?? 0);
        $lockSec = (int)($row['screen_lock_timeout_seconds'] ?? 0);
        $lockSrc = (string)($row['screen_lock_source'] ?? '');

        if ($maxLock === 0) {
            $lockOk = true;
        } elseif ($lockSec > 0) {
            $lockOk = ($lockSec <= $maxLock * 60);
        } else {
            $lockOk = ($lock > 0 && $lock <= $maxLock);
        }

        $lockSourceLabel = screen_lock_source_label($lockSrc);
        $lockDisplay     = format_screen_lock($lockSec, $lock);

        $maxAdmins = (int)($cfg['max_local_admins'] ?? 2);
        $admins = (int)($row['local_admins_count'] ?? 0);
        $adminsOk = $maxAdmins === 0 ? true : ($admins <= $maxAdmins);

        $minPw = (int)($cfg['min_password_length'] ?? 12);
        $pw = (int)($row['min_password_length'] ?? 0);
        $pwSrc = (string)($row['password_policy_source'] ?? '');
        $pwUnknown = ($pw === 0 && in_array($pwSrc, ['requires_admin', 'none', ''], true));
        $pwOk = $minPw === 0 ? true : ($pw >= $minPw);

        $maxDays = (int)($cfg['max_days_since_last_update'] ?? 30);
        $lastDate = trim((string)($row['last_update_date'] ?? ''));
        $lastDays = ($lastDate !== '' && strtotime($lastDate) !== false)
            ? (int)floor((time() - strtotime($lastDate)) / 86400)
            : -1;
        $lastOk = $maxDays === 0 ? true : ($lastDays >= 0 && $lastDays <= $maxDays);

        $guestOk = ((int)($row['guest_account_enabled'] ?? 0) === 0);
        $dailyAdminOk = ((int)($row['daily_user_is_admin'] ?? 0) === 0);
        $avOk = ((int)($row['antivirus_enabled'] ?? 0) === 1);
        $rtOk = ((int)($row['realtime_protection_enabled'] ?? 0) === 1);
        $rebootOk = ((int)($row['pending_reboot'] ?? 0) === 0);
        $fwDomainOk = ((int)($row['firewall_domain'] ?? 0) === 1);
        $fwPrivateOk = ((int)($row['firewall_private'] ?? 0) === 1);
        $fwPublicOk = ((int)($row['firewall_public'] ?? 0) === 1);
        $complexityOk = ((int)($row['password_complexity'] ?? 0) === 1);
        $complexityUnknown = !$complexityOk && in_array($pwSrc, ['requires_admin', 'none', ''], true);

        $agentIsAdmin = ((int)($row['agent_is_admin'] ?? 0) === 1);

        $badgeClass = match ($status) {
            'ok'   => 'ok',
            'warn' => 'warn',
            'fail' => 'fail',
            default => 'none',
        };
        $badgeLabel = match ($status) {
            'ok'   => 'Compliant',
            'warn' => 'Waarschuwing',
            'fail' => 'Kritiek',
            default => 'Geen data',
        };
?>
<div class="card">
    <div class="accentline"></div>
    <h2>Compliance Details - <?=e(asset_display($row))?></h2>
    <p class="muted">
        <strong><?=e($row['asset_tag'])?></strong>
        &middot; Functionele naam: <strong><?=e($row['functional_name'] ?: '-')?></strong>
        &middot; Computernaam: <strong><?=e($row['hostname'] ?: '-')?></strong>
        &middot; <?=e($row['manufacturer'])?> <?=e($row['model'])?>
        &middot; IP: <?=e($row['ip_address'] ?: '-')?>
        &middot; Laatst gezien: <?=e($row['last_seen'] ?? '-')?>
        &middot; <span class="compliance-badge <?=$badgeClass?>"><?=$badgeLabel?></span>
        &middot;
        <?php if ($agentIsAdmin): ?>
            <span class="badge green">Agent draait als admin</span>
        <?php else: ?>
            <span class="badge orange">Agent draait zonder admin</span>
        <?php endif; ?>
    </p>
    <a class="btn light" href="index.php?view=compliance" style="margin-bottom:14px; display:inline-block;">&larr; Terug naar compliance overzicht</a>

    <?php if (!$agentIsAdmin): ?>
        <div class="flash error" style="margin-bottom:20px; background:#fff6e0; color:#8a5b00; border-color:#ecd9a4;">
            <strong>Let op:</strong> de agent draait op deze client zonder administrator-rechten.
            Sommige checks (BitLocker, wachtwoordbeleid, complexiteit) kunnen daardoor niet worden uitgelezen.
        </div>
    <?php endif; ?>

    <?php if ($status === 'none'): ?>
        <div class="flash error">Nog geen compliance-data ontvangen van deze client. Laat het agent-script opnieuw uitvoeren.</div>
    <?php endif; ?>

    <?php if (count($issues) > 0): ?>
        <div class="flash error" style="margin-bottom:20px;">
            <strong>Compliance-issues (<?=count($issues)?>):</strong>
            <ul style="margin:8px 0 0 20px; padding:0;">
                <?php foreach ($issues as $i): ?>
                    <li><?=e($i)?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php elseif ($status === 'ok'): ?>
        <div class="flash success" style="margin-bottom:20px;">
            Deze client voldoet aan alle geconfigureerde compliance-eisen.
        </div>
    <?php endif; ?>

    <h3>Beveiligingsstatus</h3>
    <div class="compliance-grid">
        <div class="compliance-item <?= $bitlockerOk ? 'ok' : ($bitlockerUnknown ? 'unknown' : 'fail') ?>">
            <div class="ci-label">BitLocker systeemschijf</div>
            <div class="ci-value"><?=e($bitlockerValue ?: 'Onbekend')?></div>
            <div class="ci-meta">
                Vereist: versleuteld
                <?php if (!empty($row['bitlocker_source'])): ?>
                    &middot; bron: <?=e($row['bitlocker_source'])?>
                <?php endif; ?>
                <?php if ($bitlockerUnknown): ?>
                    <br><span style="color:#8a5b00;">Niet uitgelezen - draait de agent als admin?</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="compliance-item <?= $lockOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Automatische schermvergrendeling</div>
            <div class="ci-value"><?=e($lockDisplay)?></div>
            <div class="ci-meta">
                Max: <?=$maxLock?> min
                &middot; bron: <?=e($lockSourceLabel)?>
            </div>
        </div>

        <div class="compliance-item <?= $adminsOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Leden lokale Administrators</div>
            <div class="ci-value"><?=$admins?></div>
            <div class="ci-meta">
                Max: <?=$maxAdmins?>
                <?php if (!empty($row['local_admins_source'])): ?>
                    &middot; bron: <?=e($row['local_admins_source'])?>
                <?php endif; ?>
            </div>
        </div>
        <div class="compliance-item <?= $dailyAdminOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Dagelijkse gebruiker lokaal admin</div>
            <div class="ci-value"><?= $yesno($row['daily_user_is_admin'] ?? 0) ?></div>
            <div class="ci-meta">Vereist: Nee</div>
        </div>
        <div class="compliance-item <?= $guestOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Gastaccount ingeschakeld</div>
            <div class="ci-value"><?= $yesno($row['guest_account_enabled'] ?? 0) ?></div>
            <div class="ci-meta">
                Vereist: Nee
                <?php if (!empty($row['guest_account_source'])): ?>
                    &middot; bron: <?=e($row['guest_account_source'])?>
                <?php endif; ?>
            </div>
        </div>
        <div class="compliance-item <?= $pwUnknown ? 'unknown' : ($pwOk ? 'ok' : 'fail') ?>">
            <div class="ci-label">Minimale wachtwoordlengte</div>
            <div class="ci-value"><?=$pw?> tekens</div>
            <div class="ci-meta">
                Min: <?=$minPw?> tekens
                <?php if (!empty($pwSrc)): ?>
                    &middot; bron: <?=e($pwSrc)?>
                <?php endif; ?>
                <?php if ($pwUnknown): ?>
                    <br><span style="color:#8a5b00;">Niet uitgelezen - admin vereist</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="compliance-item <?= $complexityUnknown ? 'unknown' : ($complexityOk ? 'ok' : 'fail') ?>">
            <div class="ci-label">Wachtwoordcomplexiteit vereist</div>
            <div class="ci-value"><?= $yesno($row['password_complexity'] ?? 0) ?></div>
            <div class="ci-meta">
                Vereist: Ja
                <?php if ($complexityUnknown): ?>
                    <br><span style="color:#8a5b00;">Niet uitgelezen - admin vereist</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="compliance-item <?= $avOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Antivirus ingeschakeld</div>
            <div class="ci-value"><?= $yesno($row['antivirus_enabled'] ?? 0) ?></div>
            <div class="ci-meta">
                Vereist: Ja
                <?php if (!empty($row['antivirus_source'])): ?>
                    &middot; bron: <?=e($row['antivirus_source'])?>
                <?php endif; ?>
            </div>
        </div>
        <div class="compliance-item <?= $rtOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Real-time protection</div>
            <div class="ci-value"><?= $yesno($row['realtime_protection_enabled'] ?? 0) ?></div>
            <div class="ci-meta">Vereist: Ja</div>
        </div>
        <div class="compliance-item <?= $lastOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Laatste Windows update</div>
            <div class="ci-value"><?=e($lastDate ?: 'Onbekend')?></div>
            <div class="ci-meta">
                <?= $lastDays >= 0 ? e($lastDays . ' dagen geleden') : 'Onbekend' ?>
                <?php if (!empty($row['last_update_kb'])): ?>
                    &middot; <?=e($row['last_update_kb'])?>
                <?php endif; ?>
                <br>Max: <?=$maxDays?> dagen
            </div>
        </div>
        <div class="compliance-item <?= $rebootOk ? 'ok' : 'fail' ?>">
            <div class="ci-label">Pending reboot na update</div>
            <div class="ci-value"><?= $yesno($row['pending_reboot'] ?? 0) ?></div>
            <div class="ci-meta">Vereist: Nee</div>
        </div>
        <div class="compliance-item <?= ($fwDomainOk && $fwPrivateOk && $fwPublicOk) ? 'ok' : 'fail' ?>">
            <div class="ci-label">Windows Firewall</div>
            <div class="ci-value">
                Domain: <?= $fwDomainOk ? 'Aan' : 'Uit' ?><br>
                Private: <?= $fwPrivateOk ? 'Aan' : 'Uit' ?><br>
                Public: <?= $fwPublicOk ? 'Aan' : 'Uit' ?>
            </div>
            <div class="ci-meta">Vereist: alle drie Aan</div>
        </div>
    </div>

    <h3 style="margin-top:24px;">Leden lokale Administrators groep</h3>
    <?php if (!empty($row['local_admins_list'])): ?>
        <p class="muted" style="margin:0 0 8px;"><?=e($row['local_admins_list'])?></p>
    <?php else: ?>
        <p class="muted">Geen ledeninformatie ontvangen.</p>
    <?php endif; ?>

    <p class="muted" style="margin-top:20px; font-size:12px;">
        Laatst bijgewerkt: <?=e($row['updated_at'] ?? '-')?>
    </p>
</div>
<?php
    }
?>

<?php endif; ?>

</main>
<?php render_footer(); ?>