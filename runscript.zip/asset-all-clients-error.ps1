#run as administrator without have to deal with task scheduler.

$computers = @('pc1','pc2')
$errorLog  = 'C:\scripts\error.log'

# Read the script content ONCE
$scriptContent = Get-Content -Path 'C:\scripts\asset-all-clients.ps1' -Raw

# Make sure the log directory exists
$logDir = Split-Path -Path $errorLog -Parent
if (-not (Test-Path -Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

# Run on each machine. Because the script uses `exit`, wrap it so it
# doesn't kill the remote session.
$results = Invoke-Command -ComputerName $computers -ErrorAction Continue -ScriptBlock {
    param($scriptText)

    # Run the script in a child scope; capture exit code without exiting session
    try {
        $sb = [ScriptBlock]::Create($scriptText + "`n; `$global:LASTEXIT = 0")
        & $sb 2>&1 | ForEach-Object {
            # Tag stderr/error records so the caller can separate them
            if ($_ -is [System.Management.Automation.ErrorRecord]) {
                [PSCustomObject]@{
                    Type    = 'Error'
                    Message = $_.ToString()
                }
            } else {
                [PSCustomObject]@{
                    Type    = 'Output'
                    Message = $_.ToString()
                }
            }
        }
    } catch {
        [PSCustomObject]@{
            Type    = 'Error'
            Message = "ERROR: $($_.Exception.Message)"
        }
    }
} -ArgumentList $scriptContent -ThrottleLimit 2

# --- Write errors to error.log ---
$errors = $results | Where-Object { $_.Type -eq 'Error' }

if ($errors) {
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $errors | ForEach-Object {
        "[$timestamp] [$($_.PSComputerName)] $($_.Message)" |
            Out-File -FilePath $errorLog -Append -Encoding UTF8
    }
    Write-Host "Logged $($errors.Count) error(s) to $errorLog" -ForegroundColor Yellow
} else {
    Write-Host "No errors to log." -ForegroundColor Green
}

# Show results per machine (console view)
$results | Format-Table PSComputerName, Type, Message -AutoSize -Wrap