<#
.SYNOPSIS
    ITSM Control Center - Asset & Compliance Agent

.DESCRIPTION
    Verzamelt hardware-, software-, update- en compliance-informatie van een
    Windows-client en stuurt deze als JSON naar de ITSM backend.

    Draai dit script als SYSTEM of als lokaal administrator, anders kunnen
    bepaalde compliance-waarden (BitLocker, Secure Boot, wachtwoordbeleid)
    niet worden uitgelezen. De agent rapporteert zelf of hij admin was.

.PARAMETER ServerUrl
    Volledige URL naar de agent-checkin endpoint.

.PARAMETER AgentKey
    De waarde van security.agent_api_key uit config.php.

.EXAMPLE
    .\asset.ps1 -ServerUrl "http://192.168.2.8/itsupport/11/index.php?view=agent-checkin" -AgentKey "CHANGE-ME-AGENT-KEY-2026"
#>

[CmdletBinding()]
param(
    [string]$ServerUrl = 'http://192.168.2.8/itsupport/11/index.php?view=agent-checkin',
    [string]$AgentKey  = 'CHANGE-ME-AGENT-KEY-2026',
    [string]$FunctionalName = '',
    [switch]$WhatIf,
    [string]$LogFile = "$env:ProgramData\ITSM-Agent\asset-agent.log"
)

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

# ============================================================
# Logging
# ============================================================
function Write-AgentLog {
    param([string]$Message, [string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts] [$Level] $Message"
    Write-Verbose $line
    try {
        $dir = Split-Path -Parent $LogFile
        if ($dir -and -not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
    } catch { }
}

# ============================================================
# Admin / rol detectie
# ============================================================
function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

$isAdmin = Test-IsAdmin
Write-AgentLog "Agent gestart. Admin-context: $isAdmin"

# ============================================================
# Basis systeeminformatie
# ============================================================
function Get-AssetBaseInfo {
    $cs = $null
    try { $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop } catch {}

    $os = $null
    try { $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch {}

    $bios = $null
    try { $bios = Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop } catch {}

    $cpu = $null
    try { $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {}

    $hostname = $env:COMPUTERNAME
    $username = $env:USERNAME
    $domain   = $env:USERDOMAIN

    # Windows versie / editie / build
    $windowsVersion = ''
    $osEdition      = ''
    $windowsBuild   = ''

    if ($os) {
        $windowsVersion = "$($os.Caption)".Trim()          # bv. "Microsoft Windows 11 Pro"
        $osEdition      = "$($os.OperatingSystemSKU)"      # numerieke SKU (kan leeg zijn)
        $windowsBuild   = "$($os.BuildNumber)"             # bv. "22631"
    }

    # Extra editie-info uit het register (voor leesbare editie)
    try {
        $cv = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
        if ($cv.DisplayVersion) { $windowsVersion = "$($cv.ProductName) $($cv.DisplayVersion)" }
        if ($cv.EditionID)      { $osEdition      = "$($cv.EditionID)" }
        if ($cv.CurrentBuild)   { $windowsBuild   = "$($cv.CurrentBuild)" }
        if ($cv.UBR -ne $null -and $cv.CurrentBuild) {
            $windowsBuild = "$($cv.CurrentBuild).$($cv.UBR)"
        }
    } catch { }

    # IP-adres (eerste niet-loopback IPv4)
    $ipAddress = ''
    try {
        $ipAddress = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.PrefixOrigin -ne 'WellKnown' } |
            Select-Object -First 1 -ExpandProperty IPAddress)
    } catch {
        try {
            $ipAddress = (Get-WmiObject Win32_NetworkAdapterConfiguration -Filter 'IPEnabled = True' |
                Where-Object { $_.IPAddress } |
                Select-Object -First 1 -ExpandProperty IPAddress |
                Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' } |
                Select-Object -First 1)
        } catch {}
    }
    if (-not $ipAddress) { $ipAddress = '' }

    # MAC-adres (eerste fysieke adapter)
    $macAddress = ''
    try {
        $macAddress = (Get-NetAdapter -Physical -ErrorAction Stop |
            Where-Object { $_.Status -eq 'Up' } |
            Select-Object -First 1 -ExpandProperty MacAddress)
    } catch {}
    if (-not $macAddress) { $macAddress = '' }

    # RAM in MB
    $ramMb = 0
    if ($cs -and $cs.TotalPhysicalMemory) {
        $ramMb = [int]([math]::Round($cs.TotalPhysicalMemory / 1MB))
    }

    # Fabrikant / model / serienummer
    $manufacturer = if ($cs) { "$($cs.Manufacturer)".Trim() } else { '' }
    $model        = if ($cs) { "$($cs.Model)".Trim() }        else { '' }
    $serial       = if ($bios) { "$($bios.SerialNumber)".Trim() } else { '' }

    # BIOS-versie
    $biosVersion = ''
    if ($bios) { $biosVersion = "$($bios.SMBIOSBIOSVersion)".Trim() }

    # CPU
    $cpuName = ''
    if ($cpu) { $cpuName = "$($cpu.Name)".Trim() }

    # Asset tag / hostname
    $assetTag = $hostname

    # Functionele naam: parameter, of anders een eventuele systeem-eigenschap
    $fn = $FunctionalName
    if ([string]::IsNullOrWhiteSpace($fn)) {
        try {
            $regFn = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\ITSM-Agent' -Name 'FunctionalName' -ErrorAction Stop).FunctionalName
            if ($regFn) { $fn = "$regFn" }
        } catch {}
    }

    # Volledige gebruikersnaam
    $fullUser = ''
    if ($username) {
        $fullUser = if ($domain) { "$domain\$username" } else { $username }
    }

    return [ordered]@{
        asset_tag        = $assetTag
        hostname         = $hostname
        functional_name  = $fn
        username         = $fullUser
        manufacturer     = $manufacturer
        model            = $model
        serial_number    = $serial
        bios_version     = $biosVersion
        windows_version  = $windowsVersion
        os_edition       = $osEdition
        windows_build    = $windowsBuild
        cpu              = $cpuName
        ram_mb           = $ramMb
        ip_address       = $ipAddress
        mac_address      = $macAddress
    }
}

# ============================================================
# Schijfvolumes
# ============================================================
function Get-AssetVolumes {
    $volumes = @()
    try {
        $disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType = 3' -ErrorAction Stop
        foreach ($d in $disks) {
            $sizeGb = if ($d.Size) { [math]::Round($d.Size / 1GB, 2) } else { 0 }
            $freeGb = if ($d.FreeSpace) { [math]::Round($d.FreeSpace / 1GB, 2) } else { 0 }
            $freePct = if ($sizeGb -gt 0) { [math]::Round(($freeGb / $sizeGb) * 100, 1) } else { 0 }

            $volumes += [ordered]@{
                drive_letter = "$($d.DeviceID)"
                label        = "$($d.VolumeName)"
                file_system  = "$($d.FileSystem)"
                size_gb      = $sizeGb
                free_gb      = $freeGb
                free_percent = $freePct
            }
        }
    } catch {
        Write-AgentLog "Volumes uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }
    return $volumes
}

# ============================================================
# Geinstalleerde software (registry, 32 + 64 bit)
# ============================================================
function Get-AssetSoftware {
    $software = @()
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($p in $paths) {
        try {
            Get-ItemProperty -Path $p -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -and -not $_.SystemComponent } |
                ForEach-Object {
                    $software += [ordered]@{
                        name         = "$($_.DisplayName)".Trim()
                        version      = if ($_.DisplayVersion) { "$($_.DisplayVersion)" } else { '' }
                        publisher    = if ($_.Publisher) { "$($_.Publisher)" } else { '' }
                        install_date = if ($_.InstallDate) { "$($_.InstallDate)" } else { '' }
                    }
                }
        } catch {
            Write-AgentLog "Software uitlezen mislukt bij $p : $($_.Exception.Message)" 'WARN'
        }
    }
    # Deduplicate op naam+versie
    $software = $software | Sort-Object name, version -Unique
    return $software
}

# ============================================================
# Pending Windows Updates
# ============================================================
function Get-PendingUpdates {
    $updates = @()
    try {
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $result   = $searcher.Search("IsInstalled=0 and IsHidden=0")
        foreach ($u in $result.Updates) {
            $kb = ''
            if ($u.KBArticleIDs -and $u.KBArticleIDs.Count -gt 0) {
                $kb = ($u.KBArticleIDs | ForEach-Object { "KB$_" }) -join ', '
            }
            $category = ''
            if ($u.Categories -and $u.Categories.Count -gt 0) {
                $category = ($u.Categories | ForEach-Object { $_.Name }) -join ', '
            }
            $sev = ''
            if ($u.MsrcSeverity) { $sev = "$($u.MsrcSeverity)" }

            $sizeMb = 0
            if ($u.MaxDownloadSize) { $sizeMb = [math]::Round($u.MaxDownloadSize / 1MB, 2) }

            $updates += [ordered]@{
                title     = "$($u.Title)"
                kb        = $kb
                severity  = $sev
                size_mb   = $sizeMb
                category  = $category
                source    = 'WindowsUpdate'
            }
        }
    } catch {
        Write-AgentLog "Pending updates uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }
    return $updates
}

# ============================================================
# Compliance: BitLocker
# ============================================================
function Get-BitLockerInfo {
    $result = [ordered]@{
        bitlocker_system_protection = ''
        bitlocker_source            = ''
    }

    if (-not $isAdmin) {
        $result.bitlocker_source = 'requires_admin'
        return $result
    }

    try {
        $bl = Get-BitLockerVolume -MountPoint 'C:' -ErrorAction Stop
        $result.bitlocker_system_protection = "$($bl.ProtectionStatus)"
        $result.bitlocker_source            = 'Get-BitLockerVolume'
        return $result
    } catch {
        # Fallback via WMI
        try {
            $wmi = Get-CimInstance -Namespace 'root\cimv2\security\microsoftvolumeencryption' -ClassName 'Win32_EncryptableVolume' -ErrorAction Stop |
                Where-Object { $_.DriveLetter -eq 'C:' } | Select-Object -First 1
            if ($wmi) {
                $statusMap = @{
                    0 = 'Off'
                    1 = 'On'
                    2 = 'Unknown'
                }
                $result.bitlocker_system_protection = $statusMap[[int]$wmi.ProtectionStatus]
                $result.bitlocker_source            = 'Win32_EncryptableVolume'
            } else {
                $result.bitlocker_source = 'no_volume_found'
            }
        } catch {
            $result.bitlocker_source = 'read_failed'
            Write-AgentLog "BitLocker uitlezen mislukt: $($_.Exception.Message)" 'WARN'
        }
    }
    return $result
}

# ============================================================
# Compliance: Secure Boot
# ============================================================
function Get-SecureBootInfo {
    $result = [ordered]@{
        secure_boot_enabled = $false
        secure_boot_source  = ''
    }

    if (-not $isAdmin) {
        $result.secure_boot_source = 'requires_admin'
        return $result
    }

    try {
        $sb = Confirm-SecureBootUEFI -ErrorAction Stop
        $result.secure_boot_enabled = [bool]$sb
        $result.secure_boot_source  = 'Confirm-SecureBootUEFI'
        return $result
    } catch {
        # Niet-UEFI of cmdlet niet beschikbaar
        try {
            $fw = Get-CimInstance -Namespace 'root\cimv2\security\microsofttpm' -ClassName 'Win32_Tpm' -ErrorAction SilentlyContinue
            $result.secure_boot_source = 'unsupported_or_legacy_bios'
        } catch {
            $result.secure_boot_source = 'read_failed'
        }
        Write-AgentLog "Secure Boot uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }
    return $result
}

# ============================================================
# Compliance: schermvergrendeling
# ============================================================
function Get-ScreenLockInfo {
    $result = [ordered]@{
        screen_lock_timeout_minutes = 0
        screen_lock_timeout_seconds = 0
        screen_lock_source          = 'none'
    }

    # 1) Machine policy: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
    try {
        $v = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'InactivityTimeoutSecs' -ErrorAction Stop).InactivityTimeoutSecs
        if ($v -ne $null -and [int]$v -gt 0) {
            $result.screen_lock_timeout_seconds = [int]$v
            $result.screen_lock_timeout_minutes = [int][math]::Ceiling($v / 60)
            $result.screen_lock_source          = 'machine_policy'
            return $result
        }
    } catch { }

    # 2) HKCU van de interactieve gebruiker (via HKEY_USERS)
    try {
        $explorer = Get-CimInstance Win32_Process -Filter "Name = 'explorer.exe'" -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($explorer) {
            $owner = $explorer.GetOwner()
            $sid = $null
            if ($owner -and $owner.SID) {
                $sid = $owner.SID
            } else {
                try {
                    $user = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner -ErrorAction SilentlyContinue
                    if ($user -and $user.SID) { $sid = $user.SID }
                } catch {}
            }
            if ($sid) {
                $regPath = "Registry::HKEY_USERS\$sid\Control Panel\Desktop"
                $scr = (Get-ItemProperty -Path $regPath -Name 'ScreenSaveTimeOut' -ErrorAction Stop).ScreenSaveTimeOut
                $secure = (Get-ItemProperty -Path $regPath -Name 'ScreenSaverIsSecure' -ErrorAction SilentlyContinue).ScreenSaverIsSecure
                if ($scr -and [int]$scr -gt 0) {
                    $result.screen_lock_timeout_seconds = [int]$scr
                    $result.screen_lock_timeout_minutes = [int][math]::Ceiling($scr / 60)
                    $result.screen_lock_source          = 'screensaver_user'
                    return $result
                }
            }
        }
    } catch {
        Write-AgentLog "Schermvergrendeling via HKEY_USERS mislukt: $($_.Exception.Message)" 'VERBOSE'
    }

    # 3) Fallback: agent HKCU
    try {
        $scr = (Get-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'ScreenSaveTimeOut' -ErrorAction Stop).ScreenSaveTimeOut
        if ($scr -and [int]$scr -gt 0) {
            $result.screen_lock_timeout_seconds = [int]$scr
            $result.screen_lock_timeout_minutes = [int][math]::Ceiling($scr / 60)
            $result.screen_lock_source          = 'screensaver_agent'
        }
    } catch { }

    return $result
}

# ============================================================
# Compliance: lokale administrators
# ============================================================
function Get-LocalAdminsInfo {
    $result = [ordered]@{
        local_admins_count   = 0
        local_admins_list    = @()
        local_admins_source  = ''
        daily_user_is_admin  = $false
    }

    if (-not $isAdmin) {
        $result.local_admins_source = 'requires_admin'
        return $result
    }

    try {
        $groupName = if ($env:COMPUTERNAME -and (Get-LocalGroup -Name 'Administrators' -ErrorAction SilentlyContinue)) { 'Administrators' }
                     elseif (Get-LocalGroup -Name 'Administratoren' -ErrorAction SilentlyContinue) { 'Administratoren' }
                     else { 'Administrators' }

        $members = Get-LocalGroupMember -Group $groupName -ErrorAction Stop
        $names = @()
        foreach ($m in $members) {
            $names += "$($m.Name)"
        }
        $result.local_admins_count  = $names.Count
        $result.local_admins_list   = $names
        $result.local_admins_source = "Get-LocalGroupMember:$groupName"

        # Is de dagelijkse (interactieve) gebruiker lid van de admin-groep?
        try {
            $explorer = Get-CimInstance Win32_Process -Filter "Name = 'explorer.exe'" -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($explorer) {
                $user = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner -ErrorAction SilentlyContinue
                if ($user -and $user.User) {
                    $currentUser = if ($user.Domain) { "$($user.Domain)\$($user.User)" } else { "$($user.User)" }
                    foreach ($n in $names) {
                        if ($n -ieq $currentUser -or $n -imatch "\\$([regex]::Escape($user.User))$") {
                            $result.daily_user_is_admin = $true
                            break
                        }
                    }
                }
            }
        } catch { }
    } catch {
        $result.local_admins_source = 'read_failed'
        Write-AgentLog "Lokale admins uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }

    return $result
}

# ============================================================
# Compliance: gastaccount
# ============================================================
function Get-GuestAccountInfo {
    $result = [ordered]@{
        guest_account_enabled = $false
        guest_account_source  = ''
    }

    if (-not $isAdmin) {
        $result.guest_account_source = 'requires_admin'
        return $result
    }

    try {
        $guest = Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue
        if ($guest) {
            $result.guest_account_enabled = [bool]$guest.Enabled
            $result.guest_account_source  = 'Get-LocalUser'
        } else {
            $result.guest_account_source = 'no_guest_account'
        }
    } catch {
        $result.guest_account_source = 'read_failed'
    }

    return $result
}

# ============================================================
# Compliance: wachtwoordbeleid
# ============================================================
function Get-PasswordPolicyInfo {
    $result = [ordered]@{
        min_password_length    = 0
        password_complexity    = $false
        password_policy_source = ''
    }

    if (-not $isAdmin) {
        $result.password_policy_source = 'requires_admin'
        return $result
    }

    try {
        $out = net accounts 2>$null
        $minLen = 0
        $complexity = $false
        foreach ($line in $out) {
            if ($line -match 'Minimum password length:\s+(\d+)') {
                $minLen = [int]$Matches[1]
            }
            if ($line -match 'Password complexity') {
                $complexity = $true
            }
        }
        $result.min_password_length    = $minLen
        $result.password_complexity    = $complexity
        $result.password_policy_source = 'net_accounts'
    } catch {
        $result.password_policy_source = 'read_failed'
    }

    return $result
}

# ============================================================
# Compliance: antivirus / Defender
# ============================================================
function Get-AntivirusInfo {
    $result = [ordered]@{
        antivirus_enabled           = $false
        realtime_protection_enabled = $false
        antivirus_source            = ''
    }

    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $result.antivirus_enabled           = [bool]$mp.AntivirusEnabled
        $result.realtime_protection_enabled = [bool]$mp.RealTimeProtectionEnabled
        $result.antivirus_source            = 'Get-MpComputerStatus'
    } catch {
        $result.antivirus_source = if ($isAdmin) { 'read_failed' } else { 'requires_admin' }
    }

    return $result
}

# ============================================================
# Compliance: laatste Windows update + pending reboot
# ============================================================
function Get-UpdateInfo {
    $result = [ordered]@{
        last_update_date  = ''
        last_update_kb    = ''
        pending_reboot    = $false
    }

    try {
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $count    = $searcher.GetTotalHistoryCount()
        if ($count -gt 0) {
            $history = $searcher.QueryHistory(0, [math]::Min($count, 50))
            foreach ($h in $history) {
                if ($h.ResultCode -eq 2) { # Succeeded
                    $result.last_update_date = ([datetime]$h.Date).ToString('yyyy-MM-dd')
                    if ($h.Title -match 'KB\d+') {
                        $result.last_update_kb = $Matches[0]
                    }
                    break
                }
            }
        }
    } catch {
        Write-AgentLog "Update history uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }

    # Pending reboot detectie
    $rebootKeys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootInProgress'
    )
    foreach ($k in $rebootKeys) {
        if (Test-Path $k) { $result.pending_reboot = $true; break }
    }
    if (-not $result.pending_reboot) {
        try {
            $pfro = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations' -ErrorAction SilentlyContinue).PendingFileRenameOperations
            if ($pfro) { $result.pending_reboot = $true }
        } catch { }
    }

    return $result
}

# ============================================================
# Compliance: firewall
# ============================================================
function Get-FirewallInfo {
    $result = [ordered]@{
        firewall_domain  = $false
        firewall_private = $false
        firewall_public  = $false
    }

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            switch ($p.Name) {
                'Domain'  { $result.firewall_domain  = [bool]$p.Enabled }
                'Private' { $result.firewall_private = [bool]$p.Enabled }
                'Public'  { $result.firewall_public  = [bool]$p.Enabled }
            }
        }
    } catch {
        Write-AgentLog "Firewall uitlezen mislukt: $($_.Exception.Message)" 'WARN'
    }

    return $result
}

# ============================================================
# Payload opbouwen
# ============================================================
Write-AgentLog "Systeeminformatie verzamelen..."
$base = Get-AssetBaseInfo

Write-AgentLog "Volumes verzamelen..."
$volumes = Get-AssetVolumes

Write-AgentLog "Software verzamelen..."
$software = Get-AssetSoftware

Write-AgentLog "Pending updates verzamelen..."
$pendingUpdates = Get-PendingUpdates

Write-AgentLog "Compliance-gegevens verzamelen..."
$bitlocker   = Get-BitLockerInfo
$secureBoot  = Get-SecureBootInfo
$screenLock  = Get-ScreenLockInfo
$localAdmins = Get-LocalAdminsInfo
$guest       = Get-GuestAccountInfo
$pwPolicy    = Get-PasswordPolicyInfo
$av          = Get-AntivirusInfo
$updateInfo  = Get-UpdateInfo
$firewall    = Get-FirewallInfo

$compliance = [ordered]@{
    # BitLocker
    bitlocker_system_protection = $bitlocker.bitlocker_system_protection
    bitlocker_source            = $bitlocker.bitlocker_source

    # Secure Boot
    secure_boot_enabled         = $secureBoot.secure_boot_enabled
    secure_boot_source          = $secureBoot.secure_boot_source

    # Schermvergrendeling
    screen_lock_timeout_minutes = $screenLock.screen_lock_timeout_minutes
    screen_lock_timeout_seconds = $screenLock.screen_lock_timeout_seconds
    screen_lock_source          = $screenLock.screen_lock_source

    # Lokale admins
    local_admins_count          = $localAdmins.local_admins_count
    local_admins_list           = $localAdmins.local_admins_list
    local_admins_source         = $localAdmins.local_admins_source
    daily_user_is_admin         = $localAdmins.daily_user_is_admin

    # Gastaccount
    guest_account_enabled       = $guest.guest_account_enabled
    guest_account_source        = $guest.guest_account_source

    # Wachtwoordbeleid
    min_password_length         = $pwPolicy.min_password_length
    password_complexity         = $pwPolicy.password_complexity
    password_policy_source      = $pwPolicy.password_policy_source

    # Antivirus
    antivirus_enabled           = $av.antivirus_enabled
    realtime_protection_enabled = $av.realtime_protection_enabled
    antivirus_source            = $av.antivirus_source

    # Updates
    last_update_date            = $updateInfo.last_update_date
    last_update_kb              = $updateInfo.last_update_kb
    pending_reboot              = $updateInfo.pending_reboot

    # Firewall
    firewall_domain             = $firewall.firewall_domain
    firewall_private            = $firewall.firewall_private
    firewall_public             = $firewall.firewall_public

    # Agent status
    agent_is_admin              = $isAdmin
}

# Security policy (los van compliance, wordt ook opgeslagen)
$securityPolicy = [ordered]@{
    min_password_length         = $pwPolicy.min_password_length
    password_complexity         = $pwPolicy.password_complexity
    screen_lock_timeout_minutes = $screenLock.screen_lock_timeout_minutes
    guest_account_enabled       = $guest.guest_account_enabled
}

$payload = [ordered]@{
    asset_tag        = $base.asset_tag
    hostname         = $base.hostname
    functional_name  = $base.functional_name
    username         = $base.username
    manufacturer     = $base.manufacturer
    model            = $base.model
    serial_number    = $base.serial_number
    bios_version     = $base.bios_version
    windows_version  = $base.windows_version
    os_edition       = $base.os_edition
    windows_build    = $base.windows_build
    cpu              = $base.cpu
    ram_mb           = $base.ram_mb
    ip_address       = $base.ip_address
    mac_address      = $base.mac_address
    volumes          = $volumes
    software         = $software
    pending_updates  = $pendingUpdates
    compliance       = $compliance
    security_policy  = $securityPolicy
}

$json = $payload | ConvertTo-Json -Depth 8 -Compress

Write-AgentLog "Payload grootte: $([math]::Round($json.Length / 1KB, 2)) KB"

if ($WhatIf) {
    Write-Host "=== WHATIF: JSON payload ==="
    $payload | ConvertTo-Json -Depth 8
    Write-Host "=== Einde payload ==="
    return
}

# ============================================================
# Verzenden naar server
# ============================================================
$headers = @{
    'X-Agent-Key'  = $AgentKey
    'Content-Type' = 'application/json; charset=utf-8'
}

try {
    Write-AgentLog "Verzenden naar $ServerUrl ..."
    $response = Invoke-RestMethod -Uri $ServerUrl -Method Post -Headers $headers -Body $json -TimeoutSec 60 -ErrorAction Stop
    Write-AgentLog "Server respons: $($response | ConvertTo-Json -Compress)"
} catch {
    Write-AgentLog "Verzenden mislukt: $($_.Exception.Message)" 'ERROR'
    # Optioneel: lokaal opslaan voor retry
    try {
        $fallback = "$env:ProgramData\ITSM-Agent\failed-payload-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
        $dir = Split-Path -Parent $fallback
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Set-Content -Path $fallback -Value $json -Encoding UTF8
        Write-AgentLog "Payload opgeslagen voor retry: $fallback" 'WARN'
    } catch { }
    exit 1
}

exit 0