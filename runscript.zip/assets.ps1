<#
.SYNOPSIS
    ITSM Control Center - Asset Inventarisatie Agent (geen admin vereist)
    Inline configuratie versie - geen extern config-bestand nodig.

.DESCRIPTION
    Zelfde functionaliteit als het originele script, maar met de
    configuratie (ItsmBaseUrl en ApiKey) inline in het script zelf.
    Hierdoor is geen netwerk-share met config-bestand nodig.

.NOTES
    Vereist: Windows PowerShell 5.1+ of PowerShell 7+.
    Dit bestand bevat uitsluitend ASCII-tekens.

    WAARSCHUWING: De API-key staat in dit script. Zorg dat het script
    alleen op geautoriseerde systemen terechtkomt en dat de share
    waarop het staat goed beveiligd is.
#>

[CmdletBinding()]
param()

# =====================================================================
# INLINE CONFIGURATIE
# =====================================================================
$config = @'
{
  "ItsmBaseUrl": "http://192.168.1.218/itsupport/index.php",
  "ApiKey": "CHANGE-ME-AGENT-KEY-2026"
}
'@ | ConvertFrom-Json

$ItsmBaseUrl = $config.ItsmBaseUrl
$ApiKey      = $config.ApiKey

if (-not $ItsmBaseUrl -or -not $ApiKey) {
    Write-Error "ItsmBaseUrl en ApiKey zijn verplicht in de inline configuratie."
    exit 1
}

$minFreeGb = 30

# =====================================================================
# ALGEMENE HULPFUNCTIES
# =====================================================================

function Get-SafeValue {
    param($Value, [string]$Default = "")
    if ($null -eq $Value -or $Value -eq "") { return $Default }
    return [string]$Value
}

function Test-IsAdministrator {
    try {
        $identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

# =====================================================================
# SOFTWARE INVENTARISATIE (werkt zonder admin)
# =====================================================================

function Get-InstalledSoftware {
    $uninstallPaths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )

    $items = foreach ($path in $uninstallPaths) {
        Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
    }

    $software = $items |
        Where-Object {
            $_.DisplayName -and
            -not $_.SystemComponent -and
            $_.DisplayName -notmatch '^(Security Update|Update for|Hotfix)'
        } |
        ForEach-Object {
            $installDate = ""
            if ($_.InstallDate -match '^\d{8}$') {
                try {
                    $installDate = [datetime]::ParseExact($_.InstallDate, 'yyyyMMdd', $null).ToString('yyyy-MM-dd')
                } catch { $installDate = "" }
            }
            [pscustomobject]@{
                name         = $_.DisplayName.Trim()
                version      = Get-SafeValue $_.DisplayVersion
                publisher    = Get-SafeValue $_.Publisher
                install_date = $installDate
            }
        } |
        Sort-Object name, version -Unique

    return @($software)
}

# =====================================================================
# WINDOWS UPDATES (werkt zonder admin via COM API)
# =====================================================================

function Get-PendingWindowsUpdates {
    $updates = @()

    try {
        if (Get-Module -ListAvailable -Name PSWindowsUpdate -ErrorAction SilentlyContinue) {
            Import-Module PSWindowsUpdate -ErrorAction Stop
            $psUpdates = Get-WindowsUpdate -ErrorAction Stop
            foreach ($u in @($psUpdates)) {
                $updates += [pscustomobject]@{
                    title    = Get-SafeValue $u.Title
                    kb       = Get-SafeValue $u.KB
                    severity = Get-SafeValue $u.MsrSeverity
                    size_mb  = if ($u.Size) { [math]::Round($u.Size / 1MB, 2) } else { 0 }
                    category = Get-SafeValue $u.Category
                    source   = 'PSWindowsUpdate'
                }
            }
            if ($updates.Count -gt 0) { return @($updates) }
        }
    } catch { }

    try {
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $result   = $searcher.Search("IsInstalled=0 and IsHidden=0")

        foreach ($u in @($result.Updates)) {
            $kb = ''
            if ($u.KBArticleIDs -and $u.KBArticleIDs.Count -gt 0) {
                $kb = 'KB' + ($u.KBArticleIDs -join ', KB')
            }

            $severity = ''
            if ($u.MsrcSeverity) { $severity = [string]$u.MsrcSeverity }

            $category = ''
            if ($u.Categories -and $u.Categories.Count -gt 0) {
                $catNames = @()
                foreach ($c in $u.Categories) {
                    if ($c.Name) { $catNames += [string]$c.Name }
                }
                $category = ($catNames -join ', ')
            }

            $sizeMb = 0
            try {
                if ($u.MaxDownloadSize -gt 0) {
                    $sizeMb = [math]::Round($u.MaxDownloadSize / 1MB, 2)
                }
            } catch { }

            $updates += [pscustomobject]@{
                title    = Get-SafeValue $u.Title
                kb       = $kb
                severity = $severity
                size_mb  = $sizeMb
                category = $category
                source   = 'WindowsUpdateCOM'
            }
        }
    } catch {
        Write-Warning "Kon pending Windows Updates niet ophalen: $($_.Exception.Message)"
    }

    return @($updates)
}

# =====================================================================
# COMPLIANCE HULPFUNCTIES (zonder admin)
# =====================================================================

function Get-BitLockerSystemStatus {
    $sysDrive = $env:SystemDrive
    $result = [ordered]@{
        value  = 'Unknown'
        source = 'none'
    }

    try {
        $bl = Get-BitLockerVolume -MountPoint $sysDrive -ErrorAction Stop
        if ($bl -and $bl.ProtectionStatus) {
            $status = [string]$bl.ProtectionStatus
            if ($status -match '^(On|1)$')  {
                $result.value = 'On'; $result.source = 'cmdlet'; return $result
            }
            if ($status -match '^(Off|0)$') {
                $result.value = 'Off'; $result.source = 'cmdlet'; return $result
            }
            $result.value = $status; $result.source = 'cmdlet'; return $result
        }
    } catch { }

    try {
        $output = manage-bde -status $sysDrive 2>$null
        if (-not $output) {
            $result.source = 'requires_admin'
            return $result
        }

        $protStatus = ''
        $convStatus = ''
        foreach ($line in $output) {
            if ($line -match 'Protection Status\s*:\s*(.+)$' -or
                $line -match 'Beveiligingsstatus\s*:\s*(.+)$') {
                $protStatus = $matches[1].Trim()
            }
            if ($line -match 'Conversion Status\s*:\s*(.+)$' -or
                $line -match 'Conversiestatus\s*:\s*(.+)$') {
                $convStatus = $matches[1].Trim()
            }
        }

        if ($protStatus -match '(?i)\bon\b|aan')  { $result.value = 'On';  $result.source = 'manage_bde'; return $result }
        if ($protStatus -match '(?i)\boff\b|uit') { $result.value = 'Off'; $result.source = 'manage_bde'; return $result }

        if ($convStatus -match '(?i)fully\s*encrypted|volledig\s*versleuteld') { $result.value = 'On';  $result.source = 'manage_bde'; return $result }
        if ($convStatus -match '(?i)fully\s*decrypted|volledig\s*ontsleuteld') { $result.value = 'Off'; $result.source = 'manage_bde'; return $result }

        $result.source = 'manage_bde'
    } catch {
        $result.source = 'not_supported'
    }

    return $result
}

function Get-InteractiveUserSid {
    try {
        $explorer = Get-CimInstance -ClassName Win32_Process -Filter "Name='explorer.exe'" -ErrorAction SilentlyContinue |
                    Select-Object -First 1
        if (-not $explorer) { return $null }

        $owner = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner -ErrorAction SilentlyContinue
        if (-not $owner -or -not $owner.User) { return $null }

        $account = New-Object System.Security.Principal.NTAccount($owner.Domain, $owner.User)
        $sid     = $account.Translate([System.Security.Principal.SecurityIdentifier])
        if ($sid) { return $sid.Value }
    } catch { }
    return $null
}

function Get-ScreenLockTimeout {
    $seconds = 0
    $source  = 'none'

    try {
        $policy = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction SilentlyContinue
        if ($policy -and $policy.InactivityTimeoutSecs -gt 0) {
            $seconds = [int]$policy.InactivityTimeoutSecs
            $source  = 'machine_policy'
        }
    } catch { }

    if ($seconds -le 0) {
        try {
            $userSid = Get-InteractiveUserSid
            if ($userSid) {
                $regPath = "Registry::HKEY_USERS\$userSid\Control Panel\Desktop"
                $desktop = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
                if ($desktop -and $desktop.ScreenSaveTimeOut) {
                    $seconds = [int]$desktop.ScreenSaveTimeOut
                    $source  = 'screensaver_user'
                }
            }
        } catch { }
    }

    if ($seconds -le 0) {
        try {
            $desktop = Get-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -ErrorAction SilentlyContinue
            if ($desktop -and $desktop.ScreenSaveTimeOut) {
                $seconds = [int]$desktop.ScreenSaveTimeOut
                $source  = 'screensaver_agent'
            }
        } catch { }
    }

    $minutes = 0
    if ($seconds -gt 0) {
        $minutes = [int][math]::Ceiling($seconds / 60)
    }

    return [ordered]@{
        minutes = $minutes
        seconds = $seconds
        source  = $source
    }
}

function Get-LocalAdministratorsInfo {
    $result = [ordered]@{
        count               = 0
        names               = @()
        daily_user_is_admin = $false
        source              = 'none'
    }

    $currentUser = Get-SafeValue ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)

    try {
        $group   = Get-LocalGroup -SID 'S-1-5-32-544' -ErrorAction Stop
        $members = @(Get-LocalGroupMember -Group $group -ErrorAction Stop)
        $result.count = $members.Count
        $result.names = @($members | ForEach-Object { $_.Name })
        if ($currentUser -ne '') {
            $result.daily_user_is_admin = [bool]($members | Where-Object { $_.Name -ieq $currentUser })
        }
        $result.source = 'cmdlet'
        return $result
    } catch { }

    try {
        $output = net localgroup Administrators 2>$null
        if (-not $output) {
            $result.source = 'requires_admin'
            return $result
        }

        $names = @()
        $capture = $false
        foreach ($line in $output) {
            if ($line -match '^-{3,}') { $capture = $true; continue }
            if ($capture -and $line.Trim() -ne '' -and
                $line -notmatch 'command completed' -and
                $line -notmatch 'opdracht is voltooid') {
                $names += $line.Trim()
            }
        }
        $result.count = $names.Count
        $result.names = $names
        if ($currentUser -ne '') {
            $result.daily_user_is_admin = [bool]($names | Where-Object { $_ -ieq $currentUser })
        }
        $result.source = 'net_localgroup'
    } catch {
        $result.source = 'requires_admin'
    }

    return $result
}

function Get-GuestAccountEnabled {
    $result = [ordered]@{
        value  = $false
        source = 'none'
    }

    try {
        $guest = Get-LocalUser -Name 'Guest' -ErrorAction Stop
        if ($guest) {
            $result.value  = [bool]$guest.Enabled
            $result.source = 'cmdlet'
            return $result
        }
    } catch { }

    try {
        $output = net user Guest 2>$null
        if (-not $output) {
            $result.source = 'requires_admin'
            return $result
        }

        foreach ($line in $output) {
            if ($line -match 'Account active\s+(Yes|No)' -or
                $line -match 'Account actief\s+(Yes|No|Ja|Nee)') {
                $result.value  = ($matches[1] -match '^(Yes|Ja)$')
                $result.source = 'net_user'
                return $result
            }
        }
        $result.source = 'net_user'
    } catch {
        $result.source = 'requires_admin'
    }

    return $result
}

function Get-PasswordPolicyInfo {
    $result = [ordered]@{
        min_password_length = 0
        password_complexity = $false
        source              = 'none'
    }

    try {
        $output = net accounts 2>$null
        if ($output) {
            foreach ($line in $output) {
                if ($line -match 'Minimum password length\s*:\s*(\d+)' -or
                    $line -match 'Minimale wachtwoordlengte\s*:\s*(\d+)' -or
                    $line -match 'Mindestkennwortlange\s*:\s*(\d+)' -or
                    $line -match 'Longueur minimale du mot de passe\s*:\s*(\d+)') {
                    $result.min_password_length = [int]$matches[1]
                    $result.source = 'net_accounts'
                }
            }
        }
    } catch { }

    try {
        $tmp = [System.IO.Path]::GetTempFileName()
        secedit /export /cfg $tmp /quiet 2>$null | Out-Null
        if (Test-Path $tmp) {
            $ini = Get-Content $tmp -Raw -ErrorAction SilentlyContinue
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue

            if ($ini -match 'PasswordComplexity\s*=\s*(\d+)') {
                $result.password_complexity = ([int]$matches[1] -eq 1)
                if ($result.source -eq 'none' -or $result.source -eq 'net_accounts') {
                    $result.source = 'secedit'
                }
            }
            if ($result.min_password_length -eq 0 -and $ini -match 'MinimumPasswordLength\s*=\s*(\d+)') {
                $result.min_password_length = [int]$matches[1]
                if ($result.source -eq 'none' -or $result.source -eq 'net_accounts') {
                    $result.source = 'secedit'
                }
            }
        }
    } catch {
        if ($result.source -eq 'none') {
            $result.source = 'requires_admin'
        } elseif ($result.source -eq 'net_accounts') {
            $result.source = 'net_accounts_partial'
        }
    }

    return $result
}

function Get-AntivirusStatus {
    $result = [ordered]@{
        antivirus_enabled           = $false
        realtime_protection_enabled = $false
        source                      = 'none'
    }

    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        if ($mp) {
            $result.antivirus_enabled           = [bool]$mp.AntivirusEnabled
            $result.realtime_protection_enabled = [bool]$mp.RealTimeProtectionEnabled
            $result.source = 'cmdlet'
            return $result
        }
    } catch { }

    try {
        $av = Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop
        if ($av) {
            $result.antivirus_enabled = $true
            foreach ($p in @($av)) {
                $state = [int]$p.productState
                if (($state -band 0x1000) -ne 0) {
                    $result.realtime_protection_enabled = $true
                }
            }
            $result.source = 'securitycenter2'
            return $result
        }
    } catch { }

    $result.source = 'requires_admin'
    return $result
}

function Get-LatestInstalledUpdate {
    $result = [ordered]@{
        last_update_date = ''
        last_update_kb   = ''
    }

    try {
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $search   = $searcher.Search("IsInstalled=1 and IsHidden=0")
        $latest   = $null
        foreach ($u in @($search.Updates)) {
            if ($u.LastDeploymentChangeTime) {
                if (-not $latest -or $u.LastDeploymentChangeTime -gt $latest.LastDeploymentChangeTime) {
                    $latest = $u
                }
            }
        }
        if ($latest) {
            $date = [datetime]$latest.LastDeploymentChangeTime
            $result.last_update_date = $date.ToString('yyyy-MM-dd')
            if ($latest.KBArticleIDs -and $latest.KBArticleIDs.Count -gt 0) {
                $result.last_update_kb = 'KB' + ($latest.KBArticleIDs -join ', KB')
            }
        }
    } catch { }

    if ($result.last_update_date -eq '') {
        try {
            $hf = Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn -Descending | Select-Object -First 1
            if ($hf -and $hf.InstalledOn) {
                $result.last_update_date = ([datetime]$hf.InstalledOn).ToString('yyyy-MM-dd')
                $result.last_update_kb   = Get-SafeValue $hf.HotFixID
            }
        } catch { }
    }

    return $result
}

function Get-PendingRebootStatus {
    $pending = $false
    try {
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') {
            $pending = $true
        }
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') {
            $pending = $true
        }
        $pfro = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($pfro -and $pfro.PendingFileRenameOperations) {
            $pending = $true
        }
    } catch { }
    return $pending
}

function Get-FirewallProfileStatus {
    $result = [ordered]@{
        domain  = $false
        private = $false
        public  = $false
    }

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            switch ($p.Name) {
                'Domain'  { $result.domain  = [bool]$p.Enabled }
                'Private' { $result.private = [bool]$p.Enabled }
                'Public'  { $result.public  = [bool]$p.Enabled }
            }
        }
        return $result
    } catch { }

    try {
        $output = netsh advfirewall show allprofiles state 2>$null
        $current = ''
        foreach ($line in $output) {
            if ($line -match 'Domain Profile')       { $current = 'domain' }
            elseif ($line -match 'Private Profile')  { $current = 'private' }
            elseif ($line -match 'Public Profile')   { $current = 'public' }
            if ($line -match 'State\s+(ON|OFF)') {
                $on = ($matches[1] -eq 'ON')
                switch ($current) {
                    'domain'  { $result.domain  = $on }
                    'private' { $result.private = $on }
                    'public'  { $result.public  = $on }
                }
            }
        }
    } catch { }

    return $result
}

# =====================================================================
# HOOFDVERZAMELING EN CHECK-IN
# =====================================================================

try {
    $isAdmin = Test-IsAdministrator
    if (-not $isAdmin) {
        Write-Verbose "Script draait zonder administrator-rechten. Sommige compliance-checks worden als 'requires_admin' gemarkeerd."
    }

    Write-Verbose "Hardware-gegevens verzamelen..."
    $cs    = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    $bios  = Get-CimInstance -ClassName Win32_BIOS -ErrorAction SilentlyContinue
    $os    = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    $cpu   = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    $disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue

    $hostname    = Get-SafeValue $env:COMPUTERNAME
    $currentUser = Get-SafeValue ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)

    $activeAdapter = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True" -ErrorAction SilentlyContinue |
        Where-Object { $_.DefaultIPGateway } | Select-Object -First 1
    $ipAddress  = if ($activeAdapter) { ($activeAdapter.IPAddress | Select-Object -First 1) } else { "" }
    $macAddress = if ($activeAdapter) { $activeAdapter.MACAddress } else { "" }

    $diskSummary = (@($disks) | ForEach-Object {
        $sizeGb = [math]::Round($_.Size / 1GB, 1)
        $freeGb = [math]::Round($_.FreeSpace / 1GB, 1)
        "$($_.DeviceID) ${sizeGb}GB (${freeGb}GB vrij)"
    }) -join "; "

    $volumeData = @(
        foreach ($d in @($disks)) {
            $sizeGb = if ($d.Size)      { [math]::Round($d.Size / 1GB, 2) }      else { 0 }
            $freeGb = if ($d.FreeSpace) { [math]::Round($d.FreeSpace / 1GB, 2) } else { 0 }
            [pscustomobject]@{
                drive_letter = [string]$d.DeviceID
                label        = if ($d.VolumeName) { [string]$d.VolumeName } else { '' }
                file_system  = if ($d.FileSystem) { [string]$d.FileSystem } else { '' }
                size_gb      = $sizeGb
                free_gb      = $freeGb
                free_percent = if ($sizeGb -gt 0) { [math]::Round(($freeGb / $sizeGb) * 100, 1) } else { 0 }
                is_low       = [bool]($freeGb -lt $minFreeGb)
            }
        }
    )
    $lowDiskCount = @($volumeData | Where-Object { $_.is_low }).Count

    $defenderStatus = "Onbekend"
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $defenderStatus = if ($mp.AntivirusEnabled -and $mp.RealTimeProtectionEnabled) { "Actief" } else { "Inactief" }
    } catch {
        try {
            $av = Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop
            if ($av) { $defenderStatus = "Actief (via WMI)" }
        } catch { }
    }

    $tpmStatus = "Onbekend"
    try {
        $tpm = Get-Tpm -ErrorAction Stop
        $tpmStatus = if ($tpm.TpmPresent -and $tpm.TpmReady) { "Aanwezig & Gereed" } elseif ($tpm.TpmPresent) { "Aanwezig (niet gereed)" } else { "Niet aanwezig" }
    } catch {
        $tpmStatus = "Onbekend (admin vereist)"
    }

    $bitlockerResult = Get-BitLockerSystemStatus
    $bitlockerStatus = $bitlockerResult.value

    Write-Verbose "Software verzamelen..."
    $installedSoftware = Get-InstalledSoftware

    Write-Verbose "Pending Windows Updates verzamelen..."
    $pendingUpdates      = Get-PendingWindowsUpdates
    $pendingUpdatesCount = @($pendingUpdates).Count

    Write-Verbose "Compliance-gegevens verzamelen..."
    $blStatus      = Get-BitLockerSystemStatus
    $screenLock    = Get-ScreenLockTimeout
    $localAdmins   = Get-LocalAdministratorsInfo
    $guest         = Get-GuestAccountEnabled
    $pwPolicy      = Get-PasswordPolicyInfo
    $avStatus      = Get-AntivirusStatus
    $latestUpdate  = Get-LatestInstalledUpdate
    $pendingReboot = Get-PendingRebootStatus
    $firewall      = Get-FirewallProfileStatus

    $compliance = [ordered]@{
        bitlocker_system_protection = [string]$blStatus.value
        bitlocker_source            = [string]$blStatus.source
        screen_lock_timeout_minutes = [int]$screenLock.minutes
        screen_lock_timeout_seconds = [int]$screenLock.seconds
        screen_lock_source          = [string]$screenLock.source
        local_admins_count          = [int]$localAdmins.count
        local_admins_list           = @($localAdmins.names)
        local_admins_source         = [string]$localAdmins.source
        daily_user_is_admin         = [bool]$localAdmins.daily_user_is_admin
        guest_account_enabled       = [bool]$guest.value
        guest_account_source        = [string]$guest.source
        min_password_length         = [int]$pwPolicy.min_password_length
        password_complexity         = [bool]$pwPolicy.password_complexity
        password_policy_source      = [string]$pwPolicy.source
        antivirus_enabled           = [bool]$avStatus.antivirus_enabled
        realtime_protection_enabled = [bool]$avStatus.realtime_protection_enabled
        antivirus_source            = [string]$avStatus.source
        last_update_date            = [string]$latestUpdate.last_update_date
        last_update_kb              = [string]$latestUpdate.last_update_kb
        pending_reboot              = [bool]$pendingReboot
        firewall_domain             = [bool]$firewall.domain
        firewall_private            = [bool]$firewall.private
        firewall_public             = [bool]$firewall.public
        agent_is_admin              = [bool]$isAdmin
    }

    $securityPolicy = [ordered]@{
        min_password_length         = [int]$pwPolicy.min_password_length
        password_complexity         = [bool]$pwPolicy.password_complexity
        screen_lock_timeout_minutes = [int]$screenLock.minutes
        guest_account_enabled       = [bool]$guest.value
    }

    $payload = [ordered]@{
        asset_tag             = $hostname
        hostname              = $hostname
        username              = $currentUser

        manufacturer          = Get-SafeValue $cs.Manufacturer
        model                 = Get-SafeValue $cs.Model
        serial_number         = Get-SafeValue $bios.SerialNumber
        bios_version          = Get-SafeValue ($bios.SMBIOSBIOSVersion)
        cpu                   = Get-SafeValue $cpu.Name
        ram_mb                = if ($cs.TotalPhysicalMemory) { [int]([math]::Round($cs.TotalPhysicalMemory / 1MB)) } else { 0 }

        windows_version       = Get-SafeValue $os.Caption
        windows_build         = Get-SafeValue $os.BuildNumber

        ip_address            = Get-SafeValue $ipAddress
        mac_address           = Get-SafeValue $macAddress

        disk_summary          = $diskSummary
        volumes               = $volumeData
        low_disk_count        = $lowDiskCount

        defender_status       = $defenderStatus
        tpm_status            = $tpmStatus
        bitlocker_status      = $bitlockerStatus

        software              = $installedSoftware
        pending_updates       = $pendingUpdates
        pending_updates_count = $pendingUpdatesCount

        compliance            = $compliance
        security_policy       = $securityPolicy
    }

    $json = $payload | ConvertTo-Json -Depth 10
    $checkinUrl = "$ItsmBaseUrl`?view=agent-checkin"

    Write-Verbose "Check-in versturen naar $checkinUrl ..."
    $response = Invoke-RestMethod -Uri $checkinUrl -Method Post `
        -Headers @{ "X-Agent-Key" = $ApiKey } `
        -ContentType "application/json; charset=utf-8" `
        -Body $json `
        -ErrorAction Stop

    $lowMsg = if ($lowDiskCount -gt 0) { " - LET OP: $lowDiskCount volume(s) onder ${minFreeGb}GB vrij!" } else { "" }
    $updMsg = if ($pendingUpdatesCount -gt 0) { " - $pendingUpdatesCount pending update(s)" } else { "" }
    $adminMsg = if (-not $isAdmin) { " - zonder admin-rechten (sommige checks = requires_admin)" } else { "" }
    Write-Output "Check-in geslaagd voor '$hostname' ($($installedSoftware.Count) software-items)$lowMsg$updMsg$adminMsg"
    if ($response) {
        Write-Output ("Server: " + ($response | ConvertTo-Json -Compress))
    }

    exit 0
}
catch {
    Write-Error "Asset check-in mislukt: $($_.Exception.Message)"
    exit 1
}