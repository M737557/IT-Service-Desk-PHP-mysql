<?php
declare(strict_types=1);

/*
 * ITSM Control Center - Centrale Configuratie
 *
 * STORAGE:
 *   'driver' => 'mysql'   -> MySQL / MariaDB (aanbevolen voor productie)
 *   'driver' => 'sqlite'  -> SQLite (eenvoudig, geen server nodig)
 */

return [
    // Algemene applicatie instellingen
    'app_name' => 'ITSM Control Center (MFA Protected)',
    'timezone' => 'Europe/Amsterdam',

    // Basis-URL die in e-mails wordt gebruikt voor ticketlinks (zonder trailing slash).
    // Laat leeg ('') om automatisch de host van het inkomende verzoek te gebruiken.
    'app_base_url' => 'http://192.168.2.8/itsupport/11',

    // Beveiliging & TOTP Softtoken voor beheerders (30 seconden valid)
    'security' => [
        'totp_secret'         => 'JBSWY3DPEHPK3PXP',
        'totp_time_step'      => 30,
        'session_lifetime'    => 86400,

        'totp_admins' => [
            'Peter'             => 'JBSWY3DPEHPK3PXP',
            'Mathijs'           => 'KRSXG5CTMVRXEZLU',
            'Jerry'             => 'MFRGGZDFMZTWQ2LK',
            'Leo'               => 'GEZDGNBVGY3TQOJQ',
        ],

        'agent_api_key'       => 'CHANGE-ME-AGENT-KEY-2026',
    ],

    // Database instellingen
    'db' => [
        // Kies: 'mysql' of 'sqlite'
        'driver' => 'mysql',

        // MySQL / MariaDB instellingen (gebruikt wanneer driver = 'mysql')
        'mysql' => [
            'host'     => '127.0.0.1',
            'port'     => 3306,
            'database' => 'itsm_control_center',
            'username' => 'root',
            'password' => 'ts6OnyOaIaiTNv_P',
            'charset'  => 'utf8mb4',
            // Optioneel: laat leeg voor TCP, of vul pad naar unix socket
            'socket'   => '',
        ],

        // SQLite instellingen (gebruikt wanneer driver = 'sqlite')
        'sqlite' => [
            'dir'  => __DIR__ . DIRECTORY_SEPARATOR . 'data',
            'file' => __DIR__ . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'database.sqlite',
        ],
    ],

    // Compliance / Security baseline (GDPR/AVG/BIO)
    'compliance' => [
        'min_password_length'          => 12,
        'max_local_admins'             => 2,
        'max_days_since_last_update'   => 30,
        'require_guest_disabled'       => true,
        'require_bitlocker_system'     => true,
        'require_realtime_protection'  => true,
        'max_screen_lock_minutes'      => 10,
        'require_firewall_all_profiles' => true,
        'require_password_complexity'  => true,
        'forbid_daily_user_admin'      => true,
        'forbid_pending_reboot'        => true,
    ],

    // Uitgebreide SMTP / Mailserver instellingen
    'mail' => [
        'driver'       => 'smtp',
        'host'         => 'mail.mijndomein.nl',
        'port'         => 587,
        'encryption'   => 'tls',
        'smtp_auth'    => true,
        'username'     => 'info@mijnavgregister.nl',
        'password'     => 'C2xL*8c9$^)IM)C',
        'from_email'   => 'info@mijnavgregister.nl',
        'from_name'    => 'IT Service Desk',
        'reply_to'     => 'info@mijnavgregister.nl',
    ],

    // Huisstijl / branding
    'branding' => [
        'org_name' => 'Voedselbank Almere',
        'logo_url' => 'https://www.voedselbankalmere.nl/pics_site/voedselbank-almere-2025.png',
    ],
];